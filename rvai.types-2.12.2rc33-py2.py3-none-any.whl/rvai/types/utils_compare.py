import rvai.types
from rvai.types.constants import CLASS_KEY
from rvai.types.inspect import fields


def add_eq_to_cls(cls):
    field_list = fields(cls)
    # Create _eq__ method.  There's no need for a __ne__ method,
    # since python will call __eq__ and negate it.
    flds = [f.name for f in field_list if f.compare]
    _set_new_attribute(cls, "__eq__", _cmp_fn(flds))


def _set_new_attribute(cls, name, value):
    # Never overwrites an existing attribute.  Returns True if the
    # attribute already exists.
    if name in cls.__dict__:
        return True
    setattr(cls, name, value)
    return False


def _cmp_fn(flds):
    # Create a comparison function.

    def compare_function(self, other):
        is_equal = True

        if other.__class__ is self.__class__:
            for fld in flds:
                if getattr(self, fld, None) != getattr(other, fld, None):
                    is_equal = False
                    break

            if (
                is_equal
                and self.__class__ is not rvai.types.types.class_.Class
            ):
                if getattr(self, CLASS_KEY, None) != getattr(
                    other, CLASS_KEY, None
                ):
                    is_equal = False
        else:
            is_equal = False

        return is_equal

    return compare_function
