from collections.abc import Mapping

from rvai.types.base_type import BaseType
from rvai.types.constants import CLASS_KEY
from rvai.types.types.string import String


def _assert_type(value):
    if not isinstance(value, BaseType):
        raise ValueError(
            f"Value `{value}` with type {type(value)} is not a valid value for rvai.types.Dict"
        )
    else:
        return value


class BaseDict(dict):
    def _transform_key(self, key):
        return String(key) if type(key) is not String else key

    def __eq__(self, other):
        eq = super().__eq__(other)
        if eq is NotImplemented or eq is False:
            return False
        else:
            same_class = getattr(self, CLASS_KEY, None) == getattr(
                other, CLASS_KEY, None
            )
            return eq and same_class

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(frozenset(self.items()))

    def __getitem__(self, key):
        return super().__getitem__(self._transform_key(key))

    def __setitem__(self, key, value):
        key = self._transform_key(key)
        value = _assert_type(value)
        super().__setitem__(key, value)

    def __delitem__(self, key):
        key = self._transform_key(key)
        super().__delitem__(key)

    def get(self, key, default=None):
        key = self._transform_key(key)
        return super().get(key, default)

    def pop(self, key, default=None):
        key = self._transform_key(key)
        return super().pop(key)

    def setdefault(self, key, default=None):
        key = self._transform_key(key)
        default = _assert_type(default)
        return super().setdefault(key, default)

    def update(self, *args, **kwargs):
        if len(args) > 1:
            raise TypeError(
                "update expected at most 1 arguments, got %d" % len(args)
            )
        if args:
            other = args[0]
            if isinstance(other, Mapping):
                for key in other:
                    self[key] = other[key]
            elif hasattr(other, "keys"):
                for key in other.keys():
                    self[key] = other[key]
            else:
                for key, value in other:
                    self[key] = value
        for key, value in kwargs.items():
            self[self._transform_key(key)] = value

    def __contains__(self, key):
        key = self._transform_key(key)
        return super().__contains__(key)

    def copy(self):
        return self.__class__(self)


class BaseList(list):
    def append(self, value):
        value = _assert_type(value)
        super().append(value)

    def copy(self):
        return self.__class__(self)

    def extend(self, iterable):
        iterable = list(map(_assert_type, iterable))
        super().extend(iterable)

    def insert(self, index, value):
        value = _assert_type(value)
        super().insert(index, value)

    def __add__(self, other):
        other = list(map(_assert_type, other))
        return type(self)(super().__add__(other))

    def __setitem__(self, index, value):
        value = _assert_type(value)
        super().__setitem__(index, value)

    def __iadd__(self, other):
        other = list(map(_assert_type, other))
        return type(self)(super().__iadd__(other))

    def __eq__(self, other):
        return type(self) == type(other) and list(self) == list(other)

    def __ne__(self, other):
        return not self == other
