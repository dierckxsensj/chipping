def as_int(obj, method: str, *args, **kwargs):
    return int(getattr(int, method)(obj.value, *args, **kwargs))


def as_float(obj, method: str, *args, **kwargs):
    return float(getattr(float, method)(obj.value, *args, **kwargs))


class BaseInteger:
    def __int__(self):
        return int(self.value)

    def __float__(self):
        return float(self.value)

    def __index__(self):
        return int(self.value)

    def __add__(self, *args, **kwargs):
        return as_int(self, "__add__", *args, **kwargs)

    def __radd__(self, *args, **kwargs):
        return as_int(self, "__radd__", *args, **kwargs)

    def __sub__(self, *args, **kwargs):
        return as_int(self, "__sub__", *args, **kwargs)

    def __rsub__(self, *args, **kwargs):
        return as_int(self, "__rsub__", *args, **kwargs)

    def __mul__(self, *args, **kwargs):
        return as_int(self, "__mul__", *args, **kwargs)

    def __rmul__(self, *args, **kwargs):
        return as_int(self, "__rmul__", *args, **kwargs)

    def __truediv__(self, *args, **kwargs):
        return as_int(self, "__truediv__", *args, **kwargs)

    def __rtruediv__(self, *args, **kwargs):
        return as_int(self, "__rtruediv__", *args, **kwargs)

    def __floordiv__(self, *args, **kwargs):
        return as_int(self, "__floordiv__", *args, **kwargs)

    def __rfloordiv__(self, *args, **kwargs):
        return as_int(self, "__rfloordiv__", *args, **kwargs)

    def __mod__(self, *args, **kwargs):
        return as_int(self, "__mod__", *args, **kwargs)

    def __rmod__(self, *args, **kwargs):
        return as_int(self, "__rmod__", *args, **kwargs)

    def __divmod__(self, *args, **kwargs):
        return as_int(self, "__divmod__", *args, **kwargs)

    def __rdivmod__(self, *args, **kwargs):
        return as_int(self, "__rdivmod__", *args, **kwargs)

    def __pow__(self, *args, **kwargs):
        return as_int(self, "__pow__", *args, **kwargs)

    def __rpow__(self, *args, **kwargs):
        return as_int(self, "__rpow__", *args, **kwargs)

    def __gt__(self, *args, **kwargs):
        return as_int(self, "__gt__", *args, **kwargs)

    def __lt__(self, *args, **kwargs):
        return as_int(self, "__lt__", *args, **kwargs)

    def __eq__(self, *args, **kwargs):
        return as_int(self, "__eq__", *args, **kwargs)

    def __ne__(self, *args, **kwargs):
        return as_int(self, "__ne__", *args, **kwargs)

    def __le__(self, *args, **kwargs):
        return as_int(self, "__le__", *args, **kwargs)

    def __ge__(self, *args, **kwargs):
        return as_int(self, "__ge__", *args, **kwargs)


class BaseFloat:
    def __int__(self):
        return int(self.value)

    def __float__(self):
        return float(self.value)

    def __index__(self):
        return int(self.value)

    def __add__(self, *args, **kwargs):
        return as_float(self, "__add__", *args, **kwargs)

    def __radd__(self, *args, **kwargs):
        return as_float(self, "__radd__", *args, **kwargs)

    def __sub__(self, *args, **kwargs):
        return as_float(self, "__sub__", *args, **kwargs)

    def __rsub__(self, *args, **kwargs):
        return as_float(self, "__rsub__", *args, **kwargs)

    def __mul__(self, *args, **kwargs):
        return as_float(self, "__mul__", *args, **kwargs)

    def __rmul__(self, *args, **kwargs):
        return as_float(self, "__rmul__", *args, **kwargs)

    def __truediv__(self, *args, **kwargs):
        return as_float(self, "__truediv__", *args, **kwargs)

    def __rtruediv__(self, *args, **kwargs):
        return as_float(self, "__rtruediv__", *args, **kwargs)

    def __floordiv__(self, *args, **kwargs):
        return as_float(self, "__floordiv__", *args, **kwargs)

    def __rfloordiv__(self, *args, **kwargs):
        return as_float(self, "__rfloordiv__", *args, **kwargs)

    def __mod__(self, *args, **kwargs):
        return as_float(self, "__mod__", *args, **kwargs)

    def __rmod__(self, *args, **kwargs):
        return as_float(self, "__rmod__", *args, **kwargs)

    def __divmod__(self, *args, **kwargs):
        return as_float(self, "__divmod__", *args, **kwargs)

    def __rdivmod__(self, *args, **kwargs):
        return as_float(self, "__rdivmod__", *args, **kwargs)

    def __pow__(self, *args, **kwargs):
        return as_float(self, "__pow__", *args, **kwargs)

    def __rpow__(self, *args, **kwargs):
        return as_float(self, "__rpow__", *args, **kwargs)

    def __gt__(self, *args, **kwargs):
        return as_float(self, "__gt__", *args, **kwargs)

    def __lt__(self, *args, **kwargs):
        return as_float(self, "__lt__", *args, **kwargs)

    def __eq__(self, *args, **kwargs):
        return as_float(self, "__eq__", *args, **kwargs)

    def __ne__(self, *args, **kwargs):
        return as_float(self, "__ne__", *args, **kwargs)

    def __le__(self, *args, **kwargs):
        return as_float(self, "__le__", *args, **kwargs)

    def __ge__(self, *args, **kwargs):
        return as_float(self, "__ge__", *args, **kwargs)
