import hashlib
import struct

import numpy as np

import rvai.types
from rvai.types.visit import create_context, visit_type_instance


def type_hash(obj, algorithm):
    context = create_context()
    h = getattr(hashlib, algorithm)()
    context.h = h
    context.update_hash = lambda obj: _update_hash(obj, context, None)

    visit_type_instance(
        obj,
        context,
        apply_function=_update_hash,
        override_method_name="_on_hash",
    )

    return h.digest()


def _update_hash(obj, context, data):

    if isinstance(obj, bytes):
        context.h.update(obj)

    elif isinstance(obj, str):
        context.h.update(obj.encode())

    elif isinstance(obj, float):
        context.h.update(struct.pack("f", obj))

    elif isinstance(obj, int):
        context.h.update(struct.pack("l", obj))

    elif isinstance(obj, rvai.types.BaseType):
        context.h.update(obj.type_name().encode())

    elif isinstance(obj, np.number):
        context.h.update(obj.tobytes())

    elif isinstance(obj, np.ndarray):
        context.h.update(bytes(obj))

    elif obj is None:
        context.h.update(b"0")

    else:
        raise ValueError(f"Don't know how to hash {obj}")

    return True
