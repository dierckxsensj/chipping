import logging
from contextlib import contextmanager
from dataclasses import is_dataclass
from types import MethodType, SimpleNamespace
from typing import TYPE_CHECKING, Any, Callable, Dict, Optional, Type

import rvai.types
from rvai.types.constants import (
    ALIAS_KEY,
    ATTRIBUTES_KEY,
    CLASS_KEY,
    DESCRIPTION_KEY,
    ENCODING_KEY,
    FULL_TYPE_KEY,
    NAME_KEY,
    TYPE_KEY,
)
from rvai.types.inspect import fields
from rvai.types.utils import _build_full_type, _get_full_type

if TYPE_CHECKING:
    from rvai.types.base_type import BaseType


logger = logging.getLogger(__name__)


logger = logging.getLogger(__name__)


class Context(SimpleNamespace):
    def __init__(self, config=None, **kwargs):
        self.config = {} if config is None else config
        super().__init__(**kwargs)

    def add_method(self, name, method):
        setattr(self, name, MethodType(method, self))


def create_context(
    *, config: Optional[Dict[str, Any]] = None, **kwargs
) -> Context:
    if config is None:
        config = {}
    return Context(config=config, **kwargs)


def update_chain(context, attribute=None):
    if not hasattr(context, "chain"):
        context.chain = []
    if attribute is not None:
        context.chain.append(attribute)
    return context


@contextmanager
def reset_chain(context):
    old_chain = context.chain.copy()
    yield context
    context.chain = old_chain


def visit_type(
    T: Type["BaseType"],
    context: Context,
    apply_function: Callable[[Type["BaseType"], SimpleNamespace, Any], Any],
    override_method_name: Optional[str] = None,
) -> Any:

    _raise_if_generic_not_parametrized(T)

    # check if the type T has a method called `override_method_name`
    # and use it instead of continuing the visit traversal
    if override_method_name is not None and hasattr(T, override_method_name):
        return getattr(T, override_method_name)(T, context)

    # visit method overriden: most likely by Generic classes (e.g. Dict, List)
    if hasattr(T, "visit_type"):
        visit = lambda T, context: visit_type(
            T, context, apply_function, override_method_name
        )

        return T.visit_type(context, apply_function, visit)  # type: ignore

    # visit members of the dataclass
    if is_dataclass(T):

        return apply_function(
            T,
            context,
            {
                field.name: visit_type(
                    field.type, context, apply_function, override_method_name
                )
                for field in fields(T)
            },
        )

    # primitive type T
    return apply_function(T, context, None)


def visit_type_instance(
    obj: "BaseType",
    context: Context,
    apply_function: Callable[["BaseType", Context, Any], Any],
    override_method_name: Optional[str] = None,
) -> Any:

    update_chain(context)

    # check if the type T has a method called `override_method_name`
    # and use it instead of continuing the visit traversal
    ret = None
    if override_method_name is not None and hasattr(obj, override_method_name):
        context.serialize = lambda x: visit_type_instance(
            x, context, apply_function, override_method_name
        )
        ret = getattr(obj, override_method_name)(context)

    if ret is None:
        # visit method overriden: most likely by Generic classes (e.g. Dict, List)
        if hasattr(obj, "visit_type_instance"):

            visit = lambda obj, context: visit_type_instance(
                obj, context, apply_function, override_method_name
            )
            ret = obj.visit_type_instance(  # type: ignore
                context, apply_function, visit
            )

        # visit members of the dataclass
        elif is_dataclass(obj):  # hasattr(obj, "__annotations__"):

            def visit_field(field, apply_function, context):
                with reset_chain(context):
                    ret = visit_type_instance(
                        getattr(obj, field.name),
                        update_chain(context, field.name),
                        apply_function,
                        override_method_name,
                    )
                return ret

            with reset_chain(context):
                ret = apply_function(
                    obj,
                    context,
                    {
                        f.name: visit_field(f, apply_function, context)
                        for f in fields(obj)
                    },
                )

        else:
            # primitive type T
            ret = apply_function(obj, context, None)

    if not isinstance(ret, dict):
        return ret

    extra_args = {}
    if hasattr(obj, ATTRIBUTES_KEY):
        attrs = getattr(obj, ATTRIBUTES_KEY)
        visited_attrs = visit_type_instance(
            attrs, context, apply_function, override_method_name
        )
        extra_args[ATTRIBUTES_KEY] = visited_attrs

    if hasattr(obj, CLASS_KEY):
        attrs = getattr(obj, CLASS_KEY)
        extra_args[CLASS_KEY] = visit_type_instance(
            attrs, context, apply_function, override_method_name
        )

    # TODO: Do not check the config here, but invert control between visit and
    # apply_function. Everything should go through the serialization backend.
    if context.config.get("include_full_type", False):
        full_type = _get_full_type(obj)
        if full_type is not None:
            extra_args[FULL_TYPE_KEY] = full_type

    if hasattr(obj, ALIAS_KEY):
        extra_args[ALIAS_KEY] = getattr(obj, ALIAS_KEY)

    return {**ret, **extra_args}


def visit_type_struct(
    obj: Dict,
    context: Context,
    apply_function: Callable[[Optional["BaseType"], Any, Context], Any],
    override_method_name: Optional[str] = None,
):
    attrs = None
    class_object = None
    alias_name: Optional[str] = None

    if isinstance(obj, dict):
        attrs = obj.get(ATTRIBUTES_KEY, None)
        class_object = obj.get(CLASS_KEY, None)
        obj = {
            k: v
            for k, v in obj.items()
            if k != ATTRIBUTES_KEY and k != CLASS_KEY
        }

        # check if it's a Type dict
        if obj.get(TYPE_KEY, None):
            data = {}
            alias_name = obj.pop(ALIAS_KEY, None)
            T = rvai.types.LUT[obj.get(TYPE_KEY)]

            ret = None

            # configure decode method for override methods
            context.deserialize = lambda x: visit_type_struct(
                x, context, apply_function, override_method_name
            )

            # first try override method defined on the type
            if (
                obj.get(TYPE_KEY)
                and override_method_name is not None
                and hasattr(T, override_method_name)
            ):
                encoding = obj.get(ENCODING_KEY, None)
                ret = getattr(T, override_method_name)(context, obj, encoding)

            # if it returns None fall back to default behavior
            if ret is None:
                for name, child_obj in obj.items():
                    if name in [
                        TYPE_KEY,
                        FULL_TYPE_KEY,
                        ALIAS_KEY,
                        NAME_KEY,
                        DESCRIPTION_KEY,
                    ]:
                        continue

                    data[name] = visit_type_struct(
                        child_obj,
                        context,
                        apply_function,
                        override_method_name,
                    )

                # if the full type is specified in the serialized type data
                # then we trust it to be correct
                try:
                    full_type = _build_full_type(obj.get(FULL_TYPE_KEY))
                except Exception:
                    # if the full type cannot be parsed, we try to deserialize
                    # the data anyway
                    full_type = None
                    logger.exception(f"Could not parse {FULL_TYPE_KEY}")

                if full_type is not None:
                    T = full_type
                # otherwise we try to parametrize the generic type by
                # configuring it on the data
                elif hasattr(T, "configure"):
                    try:
                        T = T.configure(data)
                    except Exception as e:
                        logger.debug(
                            f"Could not configure generic type on the serialized data: {str(e)}"
                        )
                ret = apply_function(T, data, context)

        # check if it's a normal dict
        else:
            ret = apply_function(
                None,
                {
                    visit_type_struct(
                        k, context, apply_function, override_method_name
                    ): visit_type_struct(
                        v, context, apply_function, override_method_name
                    )
                    for k, v in obj.items()
                },
                context,
            )

    # check if it's a sequence
    elif isinstance(obj, (list, tuple)):
        ret = apply_function(
            None,
            [
                visit_type_struct(
                    i, context, apply_function, override_method_name
                )
                for i in obj
            ],
            context,
        )

    # it's a primitive: return it
    else:
        ret = obj

    if not isinstance(ret, rvai.types.BaseType) or not isinstance(obj, dict):
        return ret

    if attrs is not None:
        ret_attrs = visit_type_struct(
            attrs, context, apply_function, override_method_name
        )
        ret.set_attributes(attributes=ret_attrs)

    if class_object is not None:
        ret_class_object = visit_type_struct(
            class_object, context, apply_function, override_method_name
        )
        ret.set_class(ret_class_object)

    # transform if alias is defined
    if alias_name is not None:
        alias_transform = rvai.types.globals._aliases.get(alias_name)
        if alias_transform is not None:
            ret = alias_transform[1](ret)

    return ret


def _raise_if_generic_not_parametrized(T):
    if (
        hasattr(T, "__parameters__")
        and len(T.__parameters__) > 0
        and getattr(T, "__args__", None) is None
    ):

        raise TypeError(
            f"Cannot fake unparametrized generic type {T.type_name()}"
        )
