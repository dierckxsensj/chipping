from typing import TYPE_CHECKING, Callable, Dict, Tuple

if TYPE_CHECKING:
    from rvai.types.base_type import BaseType  # isort: skip

# Global registries
_types: Dict[str, "BaseType"] = {}
_aliases: Dict[str, Tuple["BaseType", Callable[..., "BaseType"]]] = {}
