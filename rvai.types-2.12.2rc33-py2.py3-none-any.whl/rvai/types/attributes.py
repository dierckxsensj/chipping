import logging
from dataclasses import MISSING, Field
from inspect import Parameter, signature
from typing import (
    Any,
    Callable,
    Dict,
    Generic,
    List,
    Optional,
    Sequence,
    Tuple,
    Type,
    TypeVar,
    cast,
)

from rvai.types.base_type import BaseType
from rvai.types.constants import ALIAS_KEY, ATTRIBUTES_KEY
from rvai.types.globals import _aliases
from rvai.types.inspect import get_args, get_origin, is_optional_type
from rvai.types.types.attribute import Attribute

T = TypeVar("T", bound=BaseType)

logger = logging.getLogger(__name__)


def _has_init(T):
    return T.__init__ is not object.__init__


def _has_new(T):
    return T.__new__ not in (object.__new__, Generic.__new__)


def _get_base_type_args(base_type):

    if not _has_new(base_type):
        f = base_type.__init__
    else:
        f = base_type.__new__

    return [
        name
        for name, parameter in signature(f).parameters.items()
        if parameter.kind
        in (Parameter.POSITIONAL_OR_KEYWORD, Parameter.KEYWORD_ONLY)
        and name not in ("self", "cls")
    ]


def _get_field_metadata(attr_field) -> Dict[str, Optional[str]]:

    if isinstance(attr_field, Field):
        name = attr_field.metadata.get("name")
        description = attr_field.metadata.get("description")
        default = (
            attr_field.default
            if attr_field.default is not MISSING
            else attr_field.default_factory()  # type: ignore
            if attr_field.default_factory is not MISSING  # type: ignore
            else None
        )
    else:
        name = None
        description = None
        default = None

    return {"name": name, "description": description, "default": default}


def _extract_attributes(cls) -> List[Tuple[str, type, Any]]:

    annotations = cls.__annotations__
    attributes: List[Tuple[str, type, Any]] = []

    for attr_name, attr_type in annotations.items():

        attr_default = getattr(cls, attr_name, MISSING)

        if is_optional_type(attr_type):
            attr_type, *_ = get_args(attr_type)

        attr_root_type = get_origin(attr_type) or attr_type

        if not issubclass(attr_root_type, BaseType):
            raise ValueError(
                f"Attribute type should be a valid rvai.types.BaseType, got {attr_type}."
            )

        attributes.append((attr_name, attr_type, attr_default))

    return attributes


def _process_arguments(
    expected_args: Sequence[str],
    expected_attributes: List[Tuple[str, type, Any]],
    provided_args,
    provided_kwargs,
):

    attrs: Dict[str, Any] = {}
    args = list(provided_args)
    kwargs = dict(provided_kwargs)

    for attr_key, attr_type, attr_default in reversed(
        expected_attributes
    ):  # reversed so we can pop args

        if isinstance(attr_default, Field):
            attr_default = (
                attr_default.default
                if attr_default.default is not MISSING
                else attr_default.default_factory()  # type: ignore
            )

        attr_value = kwargs.pop(attr_key, attr_default)

        # if it's not in the kwargs, maybe it's in the args
        if attr_value == MISSING and len(args) > len(expected_args):
            attr_value = args.pop()

        if attr_value == MISSING:
            raise ValueError(
                f"Missing value for required attribute '{attr_key}'."
            )

        attrs[attr_key] = attr_value

    return args, kwargs, attrs


def _build_new_attributed_type(
    type_name: str,
    type_bases: tuple,
    base_type: Type[BaseType],
    attributes: List[Tuple[str, Type[BaseType], Any]],
) -> Tuple[type, Callable]:

    """Build a new type with a constructor based on the constructor of the
    base type (where the new type inherits from) and the new fields added
    by the `@with_attributes` decorated class.

    Example:

                          | @with_attributes
      decorated class --> | class Attributed(SomeExistingType <-- base_type):
                          |    my_attribute: String <-- new field

    The example above will create a new constructor that accepts all arguments
    the original `SomeExistingType` constructor has, but which additionally
    accepts a `my_attribute` argument.

    This method also returns a callable that can be used to reconstruct an
    alias object from a corresponding base type object with attributes.

    """

    expected_args = _get_base_type_args(base_type)

    attributes_metadata = {
        attr_name: {
            "type": attr_type,
            **_get_field_metadata(attr_default),  # type: ignore
        }
        for attr_name, attr_type, attr_default in attributes
    }

    def __init__(self, *args, **kwargs):

        args, kwargs, attrs = _process_arguments(
            expected_args=expected_args,
            expected_attributes=attributes,
            provided_args=args,
            provided_kwargs=kwargs,
        )

        try:
            base_type.__init__(self, *args, **kwargs)
        except:
            error_msg = (
                f"Could not initialize {base_type} with arguments "
                f"'{args}' and keyword arguments '{kwargs}'."
            )
            logger.exception(error_msg)
            raise TypeError(error_msg)

        self.set_attributes(
            {
                attr_key: Attribute[attributes_metadata[attr_key]["type"]](
                    value=attr_value,
                    name=attributes_metadata[attr_key]["name"],
                    description=attributes_metadata[attr_key]["description"],
                )
                for attr_key, attr_value in attrs.items()
            }
        )

    def __new__(cls, *args, **kwargs):

        args, kwargs, attrs = _process_arguments(
            expected_args=expected_args,
            expected_attributes=attributes,
            provided_args=args,
            provided_kwargs=kwargs,
        )

        try:
            instance = base_type.__new__(cls, *args, **kwargs)
        except:
            logger.exception(
                f"Could not create {base_type} with arguments "
                f"'{args}' and keyword arguments '{kwargs}'."
            )
            raise

        instance.set_attributes(
            {
                attr_key: Attribute[attributes_metadata[attr_key]["type"]](
                    value=attr_value,
                    name=attributes_metadata[attr_key]["name"],
                    description=attributes_metadata[attr_key]["description"],
                )
                for attr_key, attr_value in attrs.items()
            }
        )

        return instance

    def __repr__(self, *args, **kwargs):
        base_repr = base_type.__repr__(self)
        return base_repr.replace(base_type.type_name(), type_name, 1)

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self, *args, **kwargs):
        _, base_args, base_state = base_type.__reduce__(self)
        origin = getattr(base_type, "__origin__", base_type)
        return origin, base_args, base_state

    def _fake(cls, *args, **kwargs):

        fake_attributes = {
            attr_name: attr_type.fake(*args, **kwargs)
            for attr_name, attr_type, _ in attributes
        }

        fake_obj = base_type.fake(*args, **kwargs)
        fake_obj.set_attributes(**fake_attributes)

        return from_base_type(fake_obj)

    def _type_name(cls):
        return base_type.type_name()

    def _full_type_name(self):
        return base_type.full_type_name(self)

    def _getattr(self, attr):
        attrs = getattr(self, ATTRIBUTES_KEY, None)
        if attrs is None:
            raise AttributeError(
                f"{self.full_type_name()} has no attributes defined"
            )
        try:
            return attrs[attr].value
        except KeyError:
            return base_type.__getattr__(attr)

    if not issubclass(base_type, BaseType):
        raise ValueError(
            f"Can only create attributed class from an RVAI BaseType, got"
            f"'{type_name}' which is not an RVAI Type."
        )

    # override the __new__ method if the base class does it as well
    # e.g. NDArray, otherwise override the __init__
    constructors: Dict[str, Callable] = {}

    if _has_new(base_type) and _has_init(base_type):
        constructors["__new__"] = __new__
        constructors["__init__"] = __init__
    elif _has_new(base_type) and not _has_init(base_type):
        constructors["__new__"] = __new__
    elif not _has_new and _has_init(base_type):
        constructors["__init__"] = __init__
    else:
        constructors["__init__"] = __init__

    alias = type(
        type_name,
        type_bases,
        {
            ALIAS_KEY: type_name,
            "__attributes__": attributes_metadata,
            "__base_type__": base_type,
            "type_name": classmethod(_type_name),
            "full_type_name": _full_type_name,
            "fake": classmethod(_fake),
            "__repr__": __repr__,
            "__reduce__": __reduce__,
            "__getattr__": _getattr,
            **constructors,
        },  # type: ignore
    )

    from_base_type = _build_reconstructor(base_type, alias)

    return alias, from_base_type


def _build_reconstructor(
    base_type: Type[BaseType], alias: Callable
) -> Callable:
    def _reconstruct(obj):

        obj_args = obj.to_args()
        obj_class = obj.get_class()

        args = _get_base_type_args(base_type)

        try:
            arg_values = {arg_name: obj_args[arg_name] for arg_name in args}
        except KeyError as e:
            raise RuntimeError(
                f"The required argument `{e.args[0]}` does not exist in the "
                f"arguments returned from `{base_type.type_name()}.to_args()`. \n"
                f"The default BaseType or parent implementation is probably not correct. "
                f"Try overriding the method in the {base_type} type."
            )

        attribute_values = {
            key: attr for key, attr in obj.get_attributes().items()
        }

        obj_alias = alias(**arg_values, **attribute_values)

        if obj_class is not None:
            obj_alias.set_class(obj_class)

        return obj_alias

    return _reconstruct


def with_attributes(decorated_cls: Type[T]) -> Type[T]:

    # we keep the original name and bases of the decorated class
    type_bases = (
        decorated_cls.__orig_bases__  # type: ignore
        if hasattr(decorated_cls, "__orig_bases__")
        else decorated_cls.__bases__
    )
    type_name = decorated_cls.__name__

    # the first base (there should only be one!) is the rvai Type to which
    # extra attributes are being added
    base_type = type_bases[0]
    base_type.__name__

    # the annotations of the decorated class will determine the new
    # attributes being added to the constructor of the new type
    attributes = _extract_attributes(decorated_cls)

    # next, we build a new type based on:
    # - the base class of the new decorated class
    # - the annotations of the new decorated class

    alias, from_base_type = _build_new_attributed_type(
        type_name=type_name,
        type_bases=type_bases,
        base_type=base_type,
        attributes=attributes,
    )

    # finally, the global _aliases table is used to register a deserializing
    # callback that will be used to transform the base type to the newly
    # built alias type (with extra attribute fields)

    if type_name in _aliases and not type_name.startswith("_"):
        raise KeyError(f"Key {type_name} is already present in _aliases.")
    _aliases[type_name] = (cast(BaseType, alias), from_base_type)

    return alias
