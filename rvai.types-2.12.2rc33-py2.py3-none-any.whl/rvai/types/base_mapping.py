from rvai.types.base_mutable import BaseDict
from rvai.types.base_type import BaseType
from rvai.types.constants import CLASS_KEY
from rvai.types.types.integer import Integer
from rvai.types.types.string import String
from rvai.types.visit import create_context


class BaseMapping(BaseDict, BaseType):
    def __init__(self, entries=None, **kwargs):
        entries = kwargs or entries or {}
        dict.__init__(self, entries)

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self):
        T = type(self)
        args = (dict(self),)
        state = (self.get_class(), self.get_attributes())
        return (T, args, state)

    def __eq__(self, other):
        eq = super().__eq__(other)
        if eq is NotImplemented or eq is False:
            return False
        else:
            same_class = self.get_class() == getattr(other, CLASS_KEY, None)
            return eq and same_class

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return super().__hash__()

    def to_args(self):
        return {"entries": dict(self)}

    @classmethod
    def visit_type(cls, context, apply_function, visit_function):
        amount = context.config.get("VISIT_TYPE_DICT_AMOUNT", 10)
        return apply_function(
            cls,
            context,
            {
                "entries": {
                    # TODO: maybe sample from a collection of types instead of hardcoding Integer?
                    visit_function(String, context): visit_function(
                        Integer, context
                    )
                    for _ in range(amount)
                }
            },
        )

    def visit_type_instance(self, context, apply_function, visit_function):
        key_context = create_context(
            VISIT_TYPE_INSTANCE_DICT_KEY=True, **vars(context)
        )
        return apply_function(
            self,
            context,
            {
                "entries": {
                    visit_function(key, key_context): visit_function(
                        value, context
                    )
                    for key, value in self.items()
                }
            },
        )
