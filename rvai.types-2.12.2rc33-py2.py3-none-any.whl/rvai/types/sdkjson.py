from typing import Union

try:
    import orjson
except ImportError:
    import json
    from types import SimpleNamespace

    def dumps(obj, default=None) -> bytes:
        return json.dumps(obj, default=default).encode()

    def loads(bytes_or_str: Union[str, bytes]):
        if isinstance(bytes_or_str, bytes):
            return json.loads(bytes_or_str.decode())
        else:
            return json.loads(bytes_or_str)

    orjson = SimpleNamespace(dumps=dumps, loads=loads,)  # type: ignore
