import copy
import json as _json
import logging
import sys
from dataclasses import _process_class  # type: ignore
from inspect import isclass
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Optional,
    Tuple,
    Type,
    TypeVar,
    Union,
)

import rvai.types
from rvai.types.compat import describe, swagger
from rvai.types.constants import ATTRIBUTES_KEY, CLASS_KEY
from rvai.types.fuzzing.fake import fake
from rvai.types.globals import _types
from rvai.types.hashing import type_hash
from rvai.types.meta_type import BaseMetaType, GenericMetaType
from rvai.types.serialization import (
    artifacts,
    hdf5,
    json,
    json_struct,
    magic,
    msgpack,
    struct,
)
from rvai.types.serialization.artifacts import Metadata
from rvai.types.utils import _build_full_type, hybridmethod
from rvai.types.utils_compare import add_eq_to_cls
from rvai.types.validation import validate

if TYPE_CHECKING:
    from rvai.types import Class, Float  # isort:skip


logger = logging.getLogger(__name__)

T = TypeVar("T", bound="BaseType")


if TYPE_CHECKING:
    from dataclasses import dataclass as primitive, dataclass as record
else:

    def record(
        _cls: Optional[Any] = None,
        *,
        init: bool = True,
        repr: bool = True,
        eq: bool = True,
        order: bool = False,
        unsafe_hash: bool = True,
        frozen: bool = False,
    ):
        """
        Registers a class as being an RVAI Type by adding it to the global `_types` dict.
        Provides an __init__ function by making the wrapped class a dataclass. [1]

        [1] https://docs.python.org/3/library/dataclasses.html
        """

        def wrap(cls):
            # register Type class
            cls.__rvai_type__ = "record"
            typename = cls.__name__
            logger.debug(f"Registering {typename}")
            _types[typename] = cls

            cls = _process_class(
                cls=cls,
                init=init,
                repr=repr,
                eq=False,
                order=order,
                unsafe_hash=unsafe_hash,
                frozen=frozen,
            )

            # Separately add __eq__ function.
            # We overwrite this in order to take the class attribute into
            # account (see set_class and get_class).
            add_eq_to_cls(cls)

            return cls

        if _cls is None:
            return wrap
        return wrap(_cls)

    def primitive(cls):

        cls.__rvai_type__ = "primitive"
        typename = cls.__name__
        _types[typename] = cls
        logger.debug(f"Registering {typename}")

        has_marshall_method = hasattr(cls, "_on_marshall")
        has_hash_method = hasattr(cls, "_on_hash")
        has_visit_type_method = hasattr(cls, "visit_type")
        has_visit_type_instance_method = hasattr(cls, "visit_type_instance")

        if not (
            (has_marshall_method and has_hash_method)
            or (has_visit_type_method and has_visit_type_instance_method)
        ):
            raise ValueError(
                f"Invalid primitive type {cls.__name__}. A primitive type should "
                f"have at least:\n"
                f"\t* a hashing method and a marshalling method,\n"
                f"\t* type and instance visiting methods (for generic types).\n"
            )

        return cls


def _type_name(cls):
    return getattr(
        cls,
        "type_name",
        lambda: getattr(cls, "__name__", cls.__class__.__name__),
    )()


class GenericType(metaclass=GenericMetaType):
    pass


class BaseType(metaclass=BaseMetaType):
    """
    Provide basic functionality (e.g. serialization) for RVAI Types.
    """

    def __post_init__(self):
        validate(self)

    def __hash__(self):
        return hash(frozenset(vars(self).items()))

    def hash(self, algorithm="sha1"):
        return type_hash(self, algorithm)

    def vars(self):
        return {k: v for k, v in vars(self).items() if not k.startswith("$")}

    def to_args(self) -> Dict[str, Any]:
        return {k: v for k, v in vars(self).items() if not k.startswith("$")}

    @staticmethod
    def from_name(type_name):
        from rvai.types import LUT

        return LUT[type_name]

    @staticmethod
    def from_expression(type_expression) -> Optional["BaseType"]:
        return _build_full_type(expression=type_expression)

    @classmethod
    def type_name(cls):
        base_name = cls.__name__
        args = getattr(cls, "__args__", None)
        if args and len(args):
            return f"{base_name}[{', '.join(_type_name(T) for T in args)}]"
        return base_name

    def full_type(self):
        if hasattr(self, "__orig_class__"):
            return self.__orig_class__
        else:
            return type(self)

    def full_type_name(self):
        if hasattr(self, "__orig_class__"):
            return self.__orig_class__.type_name()
        else:
            return self.type_name()

    @classmethod
    def fake(cls: Type[T], seed=None, config=None) -> T:
        config = {} if config is None else config
        return fake(cls, seed=seed, config=config)

    def to_struct(self, config=None) -> dict:
        config = {} if config is None else config
        return struct.serialize(self, config=config)

    @classmethod
    def from_struct(cls: Type[T], data: dict) -> T:
        return struct.deserialize(data)

    def to_msgpack(self, **kwargs) -> bytes:
        return msgpack.serialize(self, **kwargs)

    @classmethod
    def from_msgpack(cls: Type[T], data, **kwargs) -> T:
        return msgpack.deserialize(data, unmarshall=cls.from_struct, **kwargs)

    def to_hdf5(self, **kwargs) -> bytes:
        return hdf5.serialize(self, **kwargs)

    @classmethod
    def from_hdf5(cls: Type[T], data) -> T:
        return hdf5.deserialize(data, unmarshall=cls.from_struct)

    def to_json(self, config=None) -> bytes:
        return json.serialize(self, config=config)

    @classmethod
    def from_json(cls: Type[T], data) -> T:
        return json.deserialize(data)

    def to_json_struct(self, **kwargs) -> dict:
        return json_struct.serialize(self, **kwargs)

    @classmethod
    def from_json_struct(cls: Type[T], data) -> T:
        return json_struct.deserialize(data)

    def print_json(
        self, indent=4, sort_keys=True, file=sys.stdout, flush=False
    ):
        print(
            _json.dumps(
                self.to_json_struct(), indent=indent, sort_keys=sort_keys
            ),
            file=file,
            flush=flush,
        )

    def to_artifacts(self, config=None, context=None) -> Tuple[Metadata, dict]:
        config = config if config is not None else {}
        return artifacts.serialize(self, config=config, context=None)

    def save_artifacts(self, path: Union[str, Path], config=None):
        artifacts.save_artifacts(self, path=path, config=config)

    @classmethod
    def load_artifacts(cls: Type[T], path: Union[str, Path]) -> T:
        return artifacts.load_artifacts(cls, path=path)

    @classmethod
    def from_artifacts(cls: Type[T], metadata, artifacts_) -> T:
        return artifacts.deserialize(metadata, artifacts_)

    def set_attributes(self, attributes=None, **kwargs):

        attrs = rvai.types.Dict(
            {**_ensure_attributes(attributes), **_ensure_attributes(kwargs)}
        )

        setattr(self, ATTRIBUTES_KEY, attrs)

    def get_attributes(self):
        attrs = getattr(self, ATTRIBUTES_KEY, None)
        if attrs is None:
            return None
        return {
            attr_key: attr.value  # unpack attribute value
            for attr_key, attr in attrs.items()
        }

    def set_class(
        self,
        class_object: "Class",
        score: Optional[Union["Float", float]] = None,
        **kwargs,
    ):
        from rvai.types.types.class_ import Class
        from rvai.types.types.float import Float

        new_class_object = Class(
            class_uuid=class_object.class_uuid, name=class_object.name,
        )

        if score is not None:
            kwargs["score"] = Float(score)

        existing_attributes = class_object.get_attributes()
        if existing_attributes is not None:
            existing_attributes.update(kwargs)
            new_class_object.set_attributes(**existing_attributes)
        else:
            new_class_object.set_attributes(**kwargs)

        setattr(
            self, CLASS_KEY, new_class_object,
        )

    def get_class(self):
        return getattr(self, CLASS_KEY, None)

    def serialize(self, format="MSGPACK", **kwargs) -> bytes:

        if format == "MSGPACK":
            return self.to_msgpack(**kwargs)
        elif format == "HDF5":
            return self.to_hdf5(**kwargs)
        elif format == "JSON":
            return self.to_json()
        else:
            raise ValueError(f"Unsupported serialization format {format}")

    @classmethod
    def deserialize(cls: Type[T], data: bytes, format=None, **kwargs) -> T:
        # try to detect format if not specified
        if format is None:
            if data.startswith(magic.HDF5_MAGIC_BYTES):
                format = "HDF5"
            elif data.startswith(magic.JSON_MAGIC_BYTES):
                format = "JSON"
            else:
                format = "MSGPACK"

        if format == "HDF5":
            return cls.from_hdf5(data)
        elif format == "MSGPACK":
            return cls.from_msgpack(data, **kwargs)
        elif format == "JSON":
            return cls.from_json(data)
        else:
            raise ValueError(f"Unsupported serialization format {format}")

    marshall = to_struct
    unmarshall = from_struct

    def save(self, path: Union[str, Path]):
        if isinstance(path, str):
            path = Path(path)
        with path.open("wb") as f:
            f.write(self.serialize(format="HDF5"))

    @classmethod
    def load(cls: Type[T], path: Union[str, Path]) -> T:
        if isinstance(path, str):
            path = Path(path)
        with path.open("rb") as f:
            return cls.deserialize(f.read())

    @hybridmethod
    def describe(
        cls_or_self,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> dict:

        if isclass(cls_or_self):
            cls = cls_or_self
        elif hasattr(cls_or_self, "__orig_class__"):
            cls = cls_or_self.__orig_class__  # type: ignore
        else:
            cls = type(cls_or_self)  # type: ignore

        return describe.describe(cls, name=name, description=description)

    @classmethod
    def template(cls: Type[T], *args, **kwargs):
        return cls.fake(*args, **kwargs).to_artifacts(
            config={"TEMPLATE": True}
        )[0]

    @classmethod
    def swagger(cls: Type[T], template=None):
        """ Create OpenAPI spec template for RVAI type """
        return swagger.to_swagger(cls, template)

    def deepcopy(self):
        """Make a deepcopy."""
        return copy.deepcopy(self)

    def __eq__(self, other):
        eq = super().__eq__(other)
        if eq is NotImplemented or eq is False:
            return False
        else:
            same_class = self.get_class() == getattr(other, CLASS_KEY, None)
            return eq and same_class

    def __ne__(self, other):
        return not self.__eq__(other)


def _ensure_attribute(attribute):

    if isinstance(attribute, rvai.types.Attribute):
        value = attribute.value
        name = attribute.name
        description = attribute.description
    else:
        value = attribute
        name = None
        description = None

    return rvai.types.Attribute[type(value)](
        value=value, name=name, description=description
    )


def _ensure_attributes(attributes):

    if attributes is None:
        attrs = {}
    else:
        attrs = {
            key: _ensure_attribute(value) for key, value in attributes.items()
        }

    return attrs


__all__ = ["BaseType", "typeclass"]
