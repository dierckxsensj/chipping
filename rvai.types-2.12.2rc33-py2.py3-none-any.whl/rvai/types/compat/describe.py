from typing import Optional

from rvai.types.constants import ALIAS_KEY
from rvai.types.utils import _get_parameter_types


def _get_type_name(cls):
    if hasattr(cls, "__base_type__"):
        return cls.__base_type__.__name__
    else:
        return cls.__name__


def _get_attributes(cls):
    return getattr(cls, "__attributes__", {})


def _get_arguments(cls):

    if hasattr(cls, "__args__"):
        args = _get_parameter_types(cls)
    else:
        args = []

    return args


def _get_alias(cls):

    return getattr(cls, ALIAS_KEY, None)


def describe(
    cls,
    name: Optional[str] = None,
    description: Optional[str] = None,
    default: Optional[dict] = None,
):

    descr = {
        "type": _get_type_name(cls),
        "name": name,
        "alias": _get_alias(cls),
        "description": description,
        "default": default,
        "arguments": [describe(arg) for arg in _get_arguments(cls)],
        "attributes": {
            attr_key: describe(
                cls=attr_value.get("type"),
                name=attr_value.get("name"),
                description=attr_value.get("description"),
                default=attr_value.get("default").to_json_struct()
                if attr_value.get("default") is not None
                else None,
            )
            for attr_key, attr_value in _get_attributes(cls).items()
        },
    }

    return descr
