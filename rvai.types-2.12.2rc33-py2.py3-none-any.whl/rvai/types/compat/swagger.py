def to_swagger(obj, template=None):
    """Create OpenAPI spec template for RVAI type."""
    if template is None:
        template = obj.fake().to_json_struct(
            config={"include_full_type": False}
        )
    else:
        # recreate recursed struct because of bug in .fake()
        # e.g. Parameter in Parameters.fake() is not same as
        # Parameter.fake()
        try:
            template = (
                obj.from_json_struct(template)
                .fake()
                .to_json_struct(config={"include_full_type": False})
            )
        except TypeError:
            # Fails for Dicts, Lists etc, but only needed for unparametrized
            # nested types like Parameters, DeploymentConfiguration, etc...
            pass
    properties = {"$type": {"type": "string", "enum": [template.pop("$type")]}}
    for k, v in template.items():

        # ingore Parameter.structure field
        if k == "structure":
            continue

        if k == "entries":
            properties[k] = {  # type: ignore
                "type": "object",
                "properties": {  # type: ignore
                    "string": {
                        "type": "object",
                        "properties": obj.swagger(next(iter(v.values()))),
                    }
                },
            }
        elif k == "items":  # List
            properties[k] = {  # type: ignore
                "type": "array",
                "items": {  # type: ignore
                    "type": "object",
                    "properties": obj.swagger(v[0]),
                },
            }
        else:
            nested_type = type(v).__name__
            if nested_type in ["dict"]:
                properties[k] = {
                    "type": "object",
                    "properties": obj.swagger(v),
                }
            else:
                if nested_type in ["int", "float"]:
                    nested_type = "number"
                elif nested_type in ["str"]:
                    nested_type = "string"
                elif nested_type == "bool":
                    nested_type = "boolean"
                properties[k] = {"type": nested_type}
    return properties
