import io

import h5py
import numpy as np
from h5py import Dataset, Group

from rvai.types.constants import (
    ATTRIBUTES_KEY,
    CLASS_KEY,
    HDF5_LIST_IDENTIFIER,
    TYPE_KEY,
)
from rvai.types.sdkjson import orjson

expected_kwargs = ["compression", "compression_opts", "maxshape"]


def serialize(obj, **kwargs):
    filtered_kwargs = {
        key: kwargs[key] for key in expected_kwargs if key in kwargs
    }

    with io.BytesIO() as bytes_:
        with h5py.File(bytes_, "w", libver="latest") as h5file:
            struct = obj.to_struct(config={"include_full_type": False})
            _serialize(h5file, struct, **filtered_kwargs)
        return bytes_.getvalue()


def _serialize(group, obj, parent_key=None, **kwargs):

    # Type
    if isinstance(obj, dict) and TYPE_KEY in obj:
        if parent_key:
            group = group.create_group(parent_key)

        type_value = obj.pop(TYPE_KEY)
        group.attrs[TYPE_KEY] = type_value

        # Stringify JSON first
        if type_value == "JSON":
            _serialize(
                group, obj.pop(CLASS_KEY, None), parent_key=CLASS_KEY, **kwargs
            )
            _serialize(
                group,
                obj.pop(ATTRIBUTES_KEY, None),
                parent_key=ATTRIBUTES_KEY,
                **kwargs
            )
            _serialize(
                group,
                orjson.dumps(obj["value"]).decode(),
                parent_key="value",
                **kwargs
            )
        else:
            for key, value in obj.items():
                _serialize(group, value, parent_key=key, **kwargs)

    # Dict
    elif isinstance(obj, dict) and TYPE_KEY not in obj:
        entries_group = group.create_group(parent_key)
        for key, value in obj.items():
            _serialize(entries_group, value, parent_key=key, **kwargs)

    # List
    elif isinstance(obj, list):
        list_group = group.create_group(parent_key)
        list_group.attrs[HDF5_LIST_IDENTIFIER] = True
        n_digits = len(str(len(obj)))
        for index, value in enumerate(obj):
            if type(value) in [int, float, bytes]:
                list_group[str(index).zfill(n_digits)] = value
            else:
                item_group = list_group.create_group(
                    str(index).zfill(n_digits)
                )
                _serialize(item_group, value, **kwargs)

    # Value
    elif obj is not None:
        if isinstance(obj, (np.number, int, float, bytes, str)):
            group.create_dataset(parent_key, data=obj)
        else:
            group.create_dataset(parent_key, data=obj, **kwargs)

    elif obj is None:
        return None

    else:
        raise RuntimeError("Unreachable!")


def deserialize(serialized, **kwargs):

    unmarshall = kwargs.pop("unmarshall")
    with io.BytesIO(serialized) as bytes_:
        with h5py.File(bytes_, "r") as h5file:
            return unmarshall(_deserialize(h5file))


def _deserialize(obj, parent_key=None):

    # Type
    if isinstance(obj, Group) and TYPE_KEY in obj.attrs:
        type_value = obj.attrs.get(TYPE_KEY)

        # Destringify JSON first
        if type_value == "JSON":
            attributes = obj.get(ATTRIBUTES_KEY, None)
            class_obj = obj.get(CLASS_KEY, None)
            retval = {}
            if class_obj is not None:
                retval[CLASS_KEY] = _deserialize(
                    class_obj, parent_key=CLASS_KEY
                )
            if attributes is not None:
                retval[ATTRIBUTES_KEY] = _deserialize(
                    attributes, parent_key=ATTRIBUTES_KEY
                )
            retval.update(
                {
                    TYPE_KEY: type_value,
                    "value": orjson.loads(obj["value"][()]),
                }
            )
            return retval

        return {
            TYPE_KEY: type_value,
            **{
                key: _deserialize(value, parent_key=key)
                for key, value in obj.items()
                if key != TYPE_KEY
            },
        }

    # Dict
    elif isinstance(obj, Group) and HDF5_LIST_IDENTIFIER not in obj.attrs:
        obj = {key: _deserialize(value) for key, value in obj.items()}
        return obj.get(HDF5_LIST_IDENTIFIER, obj)

    # List
    elif isinstance(obj, Group) and HDF5_LIST_IDENTIFIER in obj.attrs:
        return [_deserialize(value) for index, value in sorted(obj.items())]

    # Value
    elif isinstance(obj, Dataset):
        return obj[()]

    else:
        raise RuntimeError("Unreachable!")
