import rvai.types
from rvai.types.constants import PYTHON_NUMPY_PRIMITIVES, TYPE_KEY
from rvai.types.visit import (
    create_context,
    visit_type_instance,
    visit_type_struct,
)


def serialize(obj, config=None, **kwargs):

    config = {} if config is None else config
    context = create_context(config={"include_full_type": True, **config})

    return visit_type_instance(
        obj,
        context,
        apply_function=_to_struct,
        override_method_name="_on_marshall",
    )


def _to_struct(obj, context, data):

    # python primitives are fine
    if type(obj) in PYTHON_NUMPY_PRIMITIVES:
        return obj

    # check if the type is an RVAI primitive
    # if so: delegate marshalling to the type
    elif isinstance(obj, rvai.types.BaseType) and data is None:
        return obj._on_marshall(context)

    # otherwise we create a default type dict
    elif isinstance(obj, rvai.types.BaseType) and data is not None:
        struct = {TYPE_KEY: obj.type_name(), **data}
        return struct

    else:
        raise RuntimeError(
            f"object contains non-BaseType members: {'.'.join(context.chain)} is {type(obj)}"
        )


def deserialize(obj):

    assert isinstance(obj, dict) and "$type" in obj, type(obj)

    context = create_context()
    return visit_type_struct(
        obj,
        context,
        apply_function=_from_struct,
        override_method_name="_on_unmarshall",
    )


def _from_struct(T, data, context):

    if T is not None:
        return T(**data)
    return data
