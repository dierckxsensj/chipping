import re

import numpy
import requests

import rvai.types
from rvai.types.constants import NUMPY_PRIMITIVES, PYTHON_PRIMITIVES, TYPE_KEY
from rvai.types.serialization import artifacts
from rvai.types.visit import (
    create_context,
    visit_type_instance,
    visit_type_struct,
)

_underscorer1 = re.compile(r"(.)([A-Z][a-z]+)")
_underscorer2 = re.compile("([a-z0-9])([A-Z])")


def to_camel_case(snake_str):

    if len(snake_str) == 1:
        return snake_str

    components = snake_str.split("_")
    return components[0] + "".join(x.title() for x in components[1:])


def to_snake_case(camel_str):

    if len(camel_str) == 1:
        return camel_str

    subbed = _underscorer1.sub(r"\1_\2", camel_str)
    subbed = _underscorer2.sub(r"\1_\2", subbed).lower()

    if camel_str[0].isupper() and camel_str[1].isupper():
        subbed = f"{subbed[0].upper()}{subbed[1:]}"

    return subbed


def serialize(obj, config=None, **kwargs):

    config = {} if config is None else config
    context = create_context(config={"include_full_type": True, **config})
    marshalled = visit_type_instance(
        obj,
        context=context,
        apply_function=_to_struct,
        override_method_name="_on_json_encode",
    )

    return marshalled


def _to_struct(obj, context, data):

    # python primitives are fine
    if type(obj) in PYTHON_PRIMITIVES:
        return obj

    # numpy primitives should be converted to their closest python counterpart
    elif type(obj) in NUMPY_PRIMITIVES:
        if isinstance(obj, numpy.integer):
            return int(obj)
        elif isinstance(obj, numpy.floating):
            return float(obj)
        elif isinstance(obj, numpy.ndarray):
            return obj.tolist()

    # check if the type is an RVAI primitive
    # if so: delegate marshalling to the type
    elif isinstance(obj, rvai.types.BaseType) and data is None:
        return obj._on_marshall(context)

    # otherwise we create a default type dict
    elif isinstance(obj, rvai.types.BaseType) and data is not None:
        return {
            TYPE_KEY: obj.type_name(),
            **{to_camel_case(k): v for k, v in data.items()},
        }

    else:
        raise RuntimeError("Unreachable!")


def deserialize(obj, **kwargs):

    if not isinstance(obj, dict) or TYPE_KEY not in obj:
        raise ValueError("Not a valid type struct")

    if "resources" in obj:
        artifacts_ = {}
        for k, v in obj["resources"].items():
            try:
                download = requests.get(v)
            except:
                raise ValueError(
                    f"Could not deserialize {obj[TYPE_KEY]}. "
                    f"Failed to download resource with url {v}."
                )
            if download.status_code != 200:
                raise ValueError(
                    f"Could not deserialize {obj[TYPE_KEY]}. "
                    f"Status code for url {v} "
                    f"not 200 but {download.status_code}."
                )
            artifacts_[k] = download.content
        return artifacts.deserialize(obj, artifacts_)

    context = create_context()
    typed = visit_type_struct(
        obj,
        context=context,
        apply_function=_from_struct,
        override_method_name="_on_json_decode",
    )

    return typed


def _from_struct(T, data, context):

    if T is not None:
        return T(**{to_snake_case(k): v for k, v in data.items()})
    return data
