import uuid
from pathlib import Path
from string import Template
from typing import Dict, Optional, Tuple, Union

import rvai.types
from rvai.types.constants import (
    PYTHON_NUMPY_PRIMITIVES,
    REF_KEY,
    SHARED_FLAG_KEY,
    TYPE_KEY,
)
from rvai.types.sdkjson import orjson
from rvai.types.serialization.json import default
from rvai.types.serialization.json_struct import to_camel_case, to_snake_case
from rvai.types.types.placeholder import Placeholder
from rvai.types.visit import (
    create_context,
    visit_type_instance,
    visit_type_struct,
)


class MetadataTemplate(Template):
    idpattern = r"[_a-z][\._a-z0-9]*"


def recurse_struct(obj, updates):
    """Used in Metadata().render_struct() to
    recursively render (key, value) pairs in a dict
    """
    for key, value in obj.items():
        if isinstance(value, dict):
            obj[key] = recurse_struct(value, updates)
        elif value in updates.keys():
            obj[key] = updates[value]
    return obj


class Metadata(dict):
    def update_resource_locations(self, **kwargs):
        for ref, resource_id in kwargs.items():
            self["resources"][ref] = str(resource_id)
        return self

    def render(self, values=None, **kwargs):

        values = {} if values is None else values
        updates = {**values, **kwargs}

        return MetadataTemplate(
            orjson.dumps(dict(self), default=default).decode()
        ).safe_substitute(updates)

    def render_struct(self, values=None, **kwargs):

        values = {} if values is None else values
        updates = {**values, **kwargs}
        updates_magic = {f"${{{k}}}": v for k, v in updates.items()}

        return recurse_struct(self, updates_magic)


class Blob(bytes):
    def __new__(cls, extension=None, *args, **kwargs):
        return super().__new__(cls, *args, **kwargs)

    def __init__(self, extension=None, *args, **kwargs):
        self.extension = extension

    def __repr__(self):
        return f"Blob({bytes(self)}, extension={self.extension})"


def _create_artifact(
    context,
    artifacts: Dict[str, Tuple[str, bytes, Optional[str]]],
    attribute: str,
    bytes_: bytes,
    extension: str,
    ref: str,
) -> str:
    if ref is None:
        ref = str(uuid.uuid4())
    context.chain.append(attribute)
    target = ".".join(context.chain)
    artifacts[ref] = (target, bytes_, extension)
    return f"#/resources/{ref}"


def serialize(obj, config=None, context=None):

    artifacts = {}
    config = config if config is not None else {}
    context = context if context is not None else create_context(config=config)
    context.add_method(
        "create_artifact",
        lambda self, attribute, bytes_, extension=None, ref=None: _create_artifact(
            self, artifacts, attribute, bytes_, extension, ref
        ),
    )
    struct = visit_type_instance(
        obj,
        context,
        apply_function=_to_artifacts,
        override_method_name="_on_artifacts_encode",
    )

    struct["resources"] = {
        ref: f"${{{artifacts[ref][0]}}}" for ref in artifacts.keys()
    }

    artifacts_blobs = {
        k: Blob(extension, bytes_)
        for k, (attr, bytes_, extension) in artifacts.items()
    }

    return Metadata(struct), artifacts_blobs


def _to_artifacts(obj, context, data):

    # python primitives are fine
    if type(obj) in PYTHON_NUMPY_PRIMITIVES:
        return obj

    # check if the type is an RVAI primitive
    # if so: delegate marshalling to the type
    elif isinstance(obj, rvai.types.BaseType) and data is None:
        return obj._on_marshall(context)

    # otherwise we create a default type dict
    elif isinstance(obj, rvai.types.BaseType) and data is not None:
        return {
            TYPE_KEY: obj.type_name(),
            **{to_camel_case(k): v for k, v in data.items()},
        }

    elif isinstance(obj, Placeholder):
        ref = context.create_artifact("$root", obj.location)
        return {REF_KEY: ref, SHARED_FLAG_KEY: True}

    else:
        raise ValueError(f"Could not encode value of type {type(obj)}")


def deserialize(obj, artifacts):

    resources = obj.get("resources", {})
    context = create_context(artifacts=artifacts, resources=resources)

    return visit_type_struct(
        obj,
        context,
        apply_function=_from_artifacts,
        override_method_name="_on_artifacts_decode",
    )


def _from_artifacts(T, data, context):

    if isinstance(data, dict) and REF_KEY in data:
        return data

    if T is not None:

        return T(
            **{
                to_snake_case(k): v
                for k, v in data.items()
                if k not in ["resources"]
            }
        )

    return data


def save_artifacts(obj, path: Union[str, Path], config=None):
    if isinstance(path, str):
        path = Path(path)
    path.mkdir(exist_ok=True, parents=True)

    metadata, artifacts = serialize(obj, config=config)

    resources = {}
    for key, artifact in artifacts.items():
        ext = (
            f".{artifact.extension}" if artifact.extension is not None else ""
        )
        file_name = f"{key}{ext}"
        file_path = path / file_name

        with file_path.open("wb") as f:
            f.write(artifact)

        resource_key = metadata["resources"][key][2:-1]
        resources[resource_key] = file_name

    metadata_file = metadata.render(resources)
    metadata_path = path / f"{obj.full_type_name()}.json"

    with metadata_path.open("wb") as f:
        f.write(metadata_file.encode())


def load_artifacts(cls, path: Union[str, Path]):
    if isinstance(path, str):
        path = Path(path)

    # it should be possible to use an explicit reference to the json
    if path.is_file():
        metadata_path = path
        path = metadata_path.parent
    else:
        metadata_path = path / f"{cls.type_name()}.json"

    with metadata_path.open("rb") as f:
        metadata_file = f.read()

    metadata = orjson.loads(metadata_file)
    resources = metadata.get("resources")

    artifacts = {}
    for key, file_name in resources.items():
        file_path = path / file_name

        with file_path.open("rb") as f:
            artifacts[key] = f.read()

    return deserialize(metadata, artifacts)
