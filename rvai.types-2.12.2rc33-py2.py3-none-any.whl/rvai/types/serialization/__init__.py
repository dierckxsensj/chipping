from types import SimpleNamespace

magic = SimpleNamespace(
    HDF5_MAGIC_BYTES=b"\211HDF\r\n\032\n", JSON_MAGIC_BYTES=b"{"
)
