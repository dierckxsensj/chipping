import functools
import sys

import numpy as np
from msgpack import ExtType, Packer as _Packer, unpackb as _unpackb

if sys.platform == "darwin":
    ndarray_to_bytes = lambda obj: obj.tobytes()
else:
    ndarray_to_bytes = (
        lambda obj: obj.data if obj.flags["C_CONTIGUOUS"] else obj.tobytes()
    )

num_to_bytes = lambda obj: obj.data


def tostr(x):
    if isinstance(x, bytes):
        return x.decode()
    else:
        return str(x)


def encode(obj, chain=None):
    """
    Data encoder for serializing numpy data types.
    """

    if isinstance(obj, np.ndarray):
        # https://docs.scipy.org/doc/numpy-1.15.1/reference/generated/numpy.dtype.kind.html
        # b	boolean
        # i	signed integer
        # u	unsigned integer
        # f	floating-point
        # c	complex floating-point
        # m	timedelta
        # M	datetime
        # O	object
        # S	(byte-)string
        # U	Unicode
        # V	void
        if obj.dtype.kind in ["m", "M", "O", "S", "U", "V"]:
            raise NotImplementedError

        return {
            b"type": "Buffer",
            b"kind": obj.dtype.str,
            b"shape": obj.shape,
            b"bytes": ndarray_to_bytes(obj),
        }

    elif isinstance(obj, np.number):

        return {
            b"type": "Value",
            b"kind": obj.dtype.str,
            b"bytes": num_to_bytes(obj),
        }

    else:
        return obj if chain is None else chain(obj)


def get(obj, key, raw=False, default=None):
    value = obj.get(key, obj.get(key.encode(), default))
    if raw:
        if isinstance(value, ExtType):
            return value.data
        return value
    else:
        try:
            return value.decode()
        except (UnicodeDecodeError, AttributeError):
            return value


def decode(obj, chain=None):
    """
    Decoder for deserializing numpy data types.
    """

    try:
        type_ = get(obj, "type")
        if type_ is not None and type_ in ["Buffer", "Value"]:
            if type_ == "Buffer":
                kind = get(obj, "kind", default="|u1")
                return np.frombuffer(
                    get(obj, "bytes", raw=True), dtype=np.dtype(kind)
                ).reshape(get(obj, "shape"))
            elif type_ == "Value":
                kind = get(obj, "kind")
                return np.frombuffer(
                    get(obj, "bytes", raw=True), dtype=np.dtype(kind)
                )[0]
        else:
            return obj if chain is None else chain(obj)
    except KeyError as e:
        raise e
        return obj if chain is None else chain(obj)


class Packer(_Packer):
    def __init__(
        self,
        default=None,
        unicode_errors="strict",
        use_single_float=False,
        autoreset=1,
        use_bin_type=True,  # default override
        strict_types=False,
    ):
        default = functools.partial(encode, chain=default)
        super(Packer, self).__init__(
            default=default,
            unicode_errors=unicode_errors,
            use_single_float=use_single_float,
            autoreset=autoreset,
            use_bin_type=use_bin_type,
            strict_types=strict_types,
        )


def pack(obj, **kwargs) -> bytes:
    return Packer(**kwargs).pack(obj)


def unpack(packed, raw=False, **kwargs):
    object_hook = kwargs.get("object_hook")
    kwargs["object_hook"] = functools.partial(decode, chain=object_hook)
    unpacked = _unpackb(packed, raw=raw, **kwargs)

    return unpacked


def serialize(obj, **kwargs) -> bytes:
    """
    Pack an object and return the packed bytes.
    """

    return Packer(**kwargs).pack(obj.to_struct())


def deserialize(packed, use_bin_type=True, **kwargs):
    """
    Unpack a packed object.
    """
    raw = not use_bin_type
    unmarshall = kwargs.pop("unmarshall")
    object_hook = kwargs.get("object_hook")
    kwargs["object_hook"] = functools.partial(decode, chain=object_hook)
    unpacked = _unpackb(packed, raw=raw, **kwargs)

    if raw:
        unpacked = _convert_raw(unpacked)

    return unmarshall(unpacked)


def _convert_raw(obj):
    """Recursively convert raw encoded strings in dict-like structure back to strings."""
    if isinstance(obj, dict):
        return {_convert_raw(k): _convert_raw(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_convert_raw(k) for k in obj]
    if isinstance(obj, bytes):
        return obj.decode()
    else:
        return obj
