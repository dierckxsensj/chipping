import numpy
import requests

from rvai.types.constants import TYPE_KEY
from rvai.types.sdkjson import orjson
from rvai.types.serialization import artifacts
from rvai.types.serialization.json_struct import _from_struct, _to_struct
from rvai.types.visit import (
    create_context,
    visit_type_instance,
    visit_type_struct,
)


def default(obj):

    if isinstance(obj, numpy.integer):
        return int(obj)
    elif isinstance(obj, numpy.floating):
        return float(obj)
    elif isinstance(obj, numpy.ndarray):
        return obj.tolist()

    return obj


def serialize(obj, config=None, **kwargs):

    config = {
        **(config if config is not None else {}),
        "include_full_type": True,
    }

    context = create_context(config=config)
    marshalled = visit_type_instance(
        obj,
        context=context,
        apply_function=_to_struct,
        override_method_name="_on_json_encode",
    )

    return orjson.dumps(marshalled, default=default)


def deserialize(serialized, **kwargs):

    obj = orjson.loads(serialized)

    if "resources" in obj:
        artifacts_ = {}
        for k, v in obj["resources"].items():
            try:
                download = requests.get(v)
            except:
                raise ValueError(
                    f"Could not deserialize {obj[TYPE_KEY]}. "
                    f"Failed to download resource with url {v}."
                )
            if download.status_code != 200:
                raise ValueError(
                    f"Could not deserialize {obj[TYPE_KEY]}. "
                    f"Status code for url {v} "
                    f"not 200 but {download.status_code}."
                )
            artifacts_[k] = download.content
        return artifacts.deserialize(obj, artifacts_)

    context = create_context()
    typed = visit_type_struct(
        obj,
        context=context,
        apply_function=_from_struct,
        override_method_name="_on_json_decode",
    )

    return typed
