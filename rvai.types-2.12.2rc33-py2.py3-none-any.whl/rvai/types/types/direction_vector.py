import numpy as np

from rvai.types.base_type import primitive
from rvai.types.types.ndarray import NDArray


@primitive
class DirectionVector(NDArray):
    def __new__(cls, data, normalize=False):
        """ Required for subclassing ndarray. See:
            https://www.csie.ntu.edu.tw/~azarc/sna/numpy-1.3.0/numpy/doc/subclassing.py
        """
        if normalize:
            data = data / np.linalg.norm(data)
        return np.asarray(data).view(cls)

    def __hash__(self):
        return hash(self.data.tobytes())

    @classmethod
    def _on_fake(cls, T, context):

        data = np.random.randn(3).astype("float32")
        data /= np.linalg.norm(data)

        return cls(data.round(5), normalize=False)
