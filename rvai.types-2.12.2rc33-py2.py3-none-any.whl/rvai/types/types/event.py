from typing import Optional

from rvai.types.base_type import BaseType, record
from rvai.types.types.boolean import Boolean
from rvai.types.types.string import String


@record
class Event(BaseType):
    """Event Data Type

    :ivar eventtype: a :class:`String` object
    :type eventtype: String
    :ivar state: a :class:`String` object
    :type state: String
    :ivar comment: a :class:`String` object
    :type comment: String
    :ivar instant: a :class:`Boolean` object
    :type instant: Boolean
    :ivar uid: a :class:`Optional[String]` object, defaults to None
    :type uid: Optional[String]
    """

    eventtype: String
    state: String
    comment: String
    instant: Boolean
    uid: Optional[String] = None
