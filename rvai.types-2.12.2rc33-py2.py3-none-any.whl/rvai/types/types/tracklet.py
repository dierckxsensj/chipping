from typing import Optional

from rvai.types.base_type import BaseType, record
from rvai.types.types.bounding_box import AnchorPoint, BoundingBox
from rvai.types.types.dict import Dict
from rvai.types.types.integer import Integer
from rvai.types.types.list import List
from rvai.types.types.point import Point
from rvai.types.types.timestamp import Timestamp


@record
class Tracklet(BaseType):
    id: Integer
    position: BoundingBox
    history: Dict[Timestamp, BoundingBox]

    def __post_init__(self):
        super().__post_init__()
        if len(self.history) == 0:
            raise TypeError("A tracklet needs at least one history box")
        # Make sure that the timestamps are actually timestamps
        ts_history = {}
        for ts, box in self.history.items():
            new_ts = ts if isinstance(ts, Timestamp) else Timestamp(ts)
            ts_history[new_ts] = box
        self.history = Dict[Timestamp, BoundingBox](ts_history)

    @property
    def start_time(self) -> Timestamp:
        return list(sorted(self.history.keys()))[0]

    @property
    def stop_time(self) -> Timestamp:
        return list(sorted(self.history.keys()))[-1]

    @property
    def age(self) -> float:
        sortedtimes = list(sorted(self.history.keys()))
        return sortedtimes[-1].to_seconds() - sortedtimes[0].to_seconds()

    def items(self):
        for ts in sorted(self.history.keys()):
            yield ts, self.history[ts]

    def get_tail(
        self,
        current_time: Timestamp,
        anchor_point: Optional[AnchorPoint],
        length: float,
        exact_length: bool = True,
    ) -> List[Point]:
        """Get a point tail of specified length for the current tracklet.

        :param current_time: The current timestamp.
        :type current_time: Timestamp
        :param anchor_point: The anchor point of the bounding boxes to use for
         tail generation.
        :type anchor_point: Optional[AnchorPoint]
        :param length: The requested tail length in seconds.
        :type length: float
        :param exact_length: When enabled (by default) the tail will be
         interpolated to match the requested length when needed.
        :type exact_length: bool
        :return: List of tracklet tail points.
        :rtype: List[Point]
        """
        # Calculate the oldest timestamp for the tail
        tail_end = current_time.to_seconds() - length
        tail = List[Point]([])
        # Get all the timestamps, sorted from largest to smallest
        timestamps = sorted(self.history.keys(), reverse=True)
        for i in range(len(timestamps)):
            # Check if part of the tail
            if timestamps[i].to_seconds() >= tail_end:
                box = self.history[timestamps[i]]
                tail.append(box.get_anchor_point(anchor_point))
            # When exact length requested, interpolate
            elif (
                exact_length
                and i >= 1
                and timestamps[i - 1].to_seconds() > tail_end
            ):
                start = timestamps[i]
                stop = timestamps[i - 1]
                diff_s = stop.to_seconds() - start.to_seconds()
                p1 = self.history[start].get_anchor_point(anchor_point)
                p2 = self.history[stop].get_anchor_point(anchor_point)
                ratio = (tail_end - start.to_seconds()) / diff_s
                x = int(p1.x + ratio * (p2.x - p1.x))
                y = int(p1.y + ratio * (p2.y - p1.y))
                # Add interpolated point
                tail.append(Point(x=x, y=y))
            # Timestamps are sorted, so we can stop iterating here
            else:
                break
        # When the current position is not in the tail yet, add it
        if current_time not in self.history:
            tail.append(self.position.get_anchor_point(anchor_point))
        return tail

    def __iter__(self):
        for ts in sorted(self.history.keys()):
            yield ts

    def __len__(self):
        return len(self.history)
