from rvai.types.base_type import primitive
from rvai.types.constants import TYPE_KEY
from rvai.types.fuzzing.fake import MAX_SIZE
from rvai.types.types.string import String


@primitive
class URL(String):
    def __new__(cls, url, data_type):
        return super(URL, cls).__new__(cls, url)

    def __init__(self, url, data_type):
        self.url = url
        self.data_type = data_type

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self):
        state = (self.get_class(), self.get_attributes())
        return type(self), (str(self), self.data_type), state

    @classmethod
    def _on_fake(cls, T, context):
        param = context.np.randint(-MAX_SIZE, MAX_SIZE)
        return cls(
            url=f"https://www.example.com/image.png?{param}", data_type="Image"
        )

    def _on_marshall(self, context):
        return {
            TYPE_KEY: self.type_name(),
            "url": str(self),
            "data_type": self.data_type,
        }

    def __hash__(self):
        return hash(str(self))

    def __repr__(self):
        return f'URL(url="{str(self)}", data_type={repr(self.data_type)})'
