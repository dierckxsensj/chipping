import datetime

from rvai.types.base_type import primitive
from rvai.types.types.string import String


@primitive
class Timestamp(String):
    def __new__(cls, value=None):

        if value is not None:
            if isinstance(value, float):
                return super().__new__(cls, _from_seconds(value))
            elif isinstance(value, datetime.datetime):
                return super().__new__(cls, _datetime_to_str(value))
            else:
                return super().__new__(cls, _validate_timestamp(value))
        else:
            return super().__new__(cls, _now())

    @classmethod
    def _on_fake(cls, T, context):
        return cls()

    def __repr__(self):
        return f'Timestamp(value="{str(self)}")'

    def to_datetime(self) -> datetime.datetime:
        return datetime.datetime.strptime(
            str(self), "%Y_%m_%d__%H_%M_%S_%f000"
        )

    def to_seconds(self) -> float:
        return self.to_datetime().timestamp()


def _from_seconds(timestamp: float) -> str:
    ts = datetime.datetime.fromtimestamp(timestamp)
    return _datetime_to_str(ts)


def _datetime_to_str(ts: datetime.datetime) -> str:
    return "%04.i_%02.i_%02.i__%02.i_%02.i_%02.i_%06.i000" % (
        ts.year,
        ts.month,
        ts.day,
        ts.hour,
        ts.minute,
        ts.second,
        ts.microsecond,
    )


def _now() -> str:
    ts = datetime.datetime.now()
    return _datetime_to_str(ts)


def _validate_timestamp(timestamp: str) -> str:
    # NOT FAST!! DO NOT CALL IN TIME CRITICAL CODE!!!
    assert len(timestamp) in (20, 30), (
        "The string "
        + str(timestamp)
        + " does not have the correct length to be a timestamp!"
    )
    assert timestamp[0].isdigit()  # YYYY
    assert timestamp[1].isdigit()
    assert timestamp[2].isdigit()
    assert timestamp[3].isdigit()
    assert timestamp[4] == "_"
    assert timestamp[5].isdigit()  # MM
    assert timestamp[6].isdigit()
    assert timestamp[7] == "_"
    assert timestamp[8].isdigit()  # DD
    assert timestamp[9].isdigit()
    assert timestamp[10] == "_"
    assert timestamp[11] == "_"
    assert timestamp[12].isdigit()  # HH
    assert timestamp[13].isdigit()
    assert timestamp[14] == "_"
    assert timestamp[15].isdigit()  # MM
    assert timestamp[16].isdigit()
    assert timestamp[17] == "_"
    assert timestamp[18].isdigit()  # SS
    assert timestamp[19].isdigit()
    if len(timestamp) > 30:
        assert timestamp[20] == "_"
        assert timestamp[21:-1].isdigit()  # SS

    return timestamp
