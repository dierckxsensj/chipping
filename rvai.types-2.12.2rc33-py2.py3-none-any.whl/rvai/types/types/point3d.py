from rvai.types.base_type import BaseType, record
from rvai.types.types.ndarray import NDArray


@record
class Point3D(BaseType):
    """Point Data Type

    :ivar x: a :class:`float` object
    :type x: float
    :ivar y: a :class:`float` object
    :type y: float
    :ivar y: a :class:`float` object
    :type y: float
    """

    x: float
    y: float
    z: float

    @property
    def xyz(self):
        return self.x, self.y, self.z

    @property
    def xyzi(self):
        return int(self.x), int(self.y), int(self.z)

    def to_ndarray(self) -> NDArray:
        return NDArray(self.xyz)

    @classmethod
    def from_ndarray(cls, ndarray: NDArray) -> "Point3D":
        ndarray_flat = ndarray.flatten()
        if ndarray_flat.size != 3:
            raise ValueError("Expected a 3 element array!")
        return Point3D(x=ndarray_flat[0], y=ndarray_flat[1], z=ndarray_flat[2])
