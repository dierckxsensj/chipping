import string

from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import TYPE_KEY


@primitive
class String(BaseType, str):
    def __new__(cls, value):
        return super(String, cls).__new__(cls, value)

    def _on_hash(self, context):
        return context.update_hash(str(self).encode())

    @classmethod
    def _on_fake(cls, T, context):
        randstr = "".join(
            context.random.choice(string.ascii_uppercase + string.digits)
            for _ in range(context.random.randint(1, 100))
        )
        return cls(randstr)

    def _on_marshall(self, context):

        if getattr(context, "VISIT_TYPE_INSTANCE_DICT_KEY", False):
            return str(self)

        return {TYPE_KEY: self.type_name(), "value": str(self)}

    def __hash__(self):
        return hash(str(self))

    def __repr__(self):
        return f'String(value="{str(self)}")'

    def to_args(self):
        return {"value": str(self)}
