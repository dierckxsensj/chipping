from rvai.types.base_type import BaseType, record
from rvai.types.types.dict import Dict
from rvai.types.types.image import Image
from rvai.types.types.string import String

DEFAULT_FAKE_VIEWS = ("view1", "view2", "view3")


@record
class MultiViewImageSet(BaseType):
    """MultiViewImageSet Data Type

    :ivar views: a :class:`Dict[String, Image]` object
    :type views: Dict[String, Image]
    """

    views: Dict[String, Image]

    @classmethod
    def _on_fake(cls, T, context):
        view_names = context.config.get("FAKE_MULTI_VIEWS", DEFAULT_FAKE_VIEWS)
        return cls(
            views=Dict(
                {x: Image.fake(config=context.config) for x in view_names}
            )
        )
