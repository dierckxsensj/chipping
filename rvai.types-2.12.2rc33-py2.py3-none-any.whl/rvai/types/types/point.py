from rvai.types.base_type import BaseType, record


@record
class Point(BaseType):
    """Point Data Type

    :ivar x: a :class:`float` object
    :type x: float
    :ivar y: a :class:`float` object
    :type y: float
    """

    x: float
    y: float

    @property
    def xy(self):
        return self.x, self.y

    @property
    def xyi(self):
        return int(self.x), int(self.y)
