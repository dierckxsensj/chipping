from typing import Optional

from rvai.types.base_type import BaseType, record
from rvai.types.types.image import Image
from rvai.types.types.list import List
from rvai.types.types.timestamp import Timestamp


@record
class ImageSet(BaseType):
    """ImageSet Data Type

    :ivar images: a :class:`List[Image]` object
    :type images: List[Image]
    :ivar timestamp: a :class:`Optional[Timestamp]` object, defaults to None
    :type timestamp: Optional[Timestamp]
    """

    images: List[Image]
    timestamp: Optional[Timestamp] = None

    def __len__(self):
        return len(self.images)

    def __getitem__(self, key):
        return self.images[key]
