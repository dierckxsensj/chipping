import numpy

from rvai.types.base_type import primitive
from rvai.types.types.masks import Masks


@primitive
class DisjointMasks(Masks):
    """ A List of masks that do not overlap with each other. """

    def _on_fake(self, context):
        masks = Masks.fake()
        # Remove any overlap in the masks so that the
        # masks do no overlap.

        # Convert to an index image.
        index_image = numpy.full_like(
            masks[0], fill_value=-1, dtype=numpy.int32, subok=False
        )
        for i, mask in enumerate(masks):
            index_image[mask] = i

        # Convert back from the index image to separate masks.
        for i, mask in enumerate(masks):
            mask[:, :] = index_image == i

        return DisjointMasks(masks)
