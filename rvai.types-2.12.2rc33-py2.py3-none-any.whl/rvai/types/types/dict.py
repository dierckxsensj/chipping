from typing import Dict as TypingDict, Tuple, Type, TypeVar, Union

from rvai.types import inspect
from rvai.types.base_mutable import BaseDict
from rvai.types.base_type import BaseType, primitive
from rvai.types.meta_type import GenericMetaType
from rvai.types.types.string import String
from rvai.types.utils import TypeFactory
from rvai.types.visit import create_context, reset_chain, update_chain

K = TypeVar("K", bound=String)
V = TypeVar("V")


def _get_annotation_type(X, V):

    origin = inspect.get_origin(X)
    if origin is not None and origin == Union:
        X = inspect.get_args(X)[0]

    return V if isinstance(X, TypeVar) else X


@primitive
class Dict(BaseDict, BaseType, TypingDict[K, V], metaclass=GenericMetaType):  # type: ignore
    def __init__(self, entries=None, **kwargs):
        entries = kwargs or entries or {}
        dict.__init__(self, entries)

    def vars(self):
        return {
            k: v
            for k, v in vars(self).items()
            if not k.startswith("$")
            if k in getattr(self, "__annotations__", {})
        }

    def __repr__(self):
        type_name = str(self.full_type_name())
        items = ", ".join(
            f"{repr(str(k))}: {repr(v)}" for k, v in self.items()
        )
        entries = f"{{{items}}}"
        extras = (f"{k}: {repr(v)}" for k, v in self.vars().items())
        values = ", ".join((entries, *extras))

        return f"{type_name}({values})"

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self):
        T = TypeFactory(self.full_type_name())
        args = (dict(self),)
        state = (self.get_class(), self.get_attributes())
        return (T, args, state)

    @classmethod
    def visit_type(cls, context, apply_function, visit_function):
        args: Tuple = cls.__args__
        if len(args) == 1:
            K, V = String, args[0]
        elif len(args) == 2:
            K, V = args
        else:
            raise TypeError("Too many arguments for Dict type!")

        amount = context.config.get("VISIT_TYPE_DICT_AMOUNT", 10)

        extra = {
            k: visit_function(_get_annotation_type(X, V), context)
            for k, X in getattr(cls, "__annotations__", {}).items()
        }

        return apply_function(
            cls,
            context,
            {
                "entries": {
                    visit_function(K, context): visit_function(V, context)
                    for _ in range(amount)
                },
                **extra,
            },
        )

    def visit_type_instance(self, context, apply_function, visit_function):
        key_context = create_context(
            VISIT_TYPE_INSTANCE_DICT_KEY=True, **vars(context)
        )

        def visit_entry(key, value, context):
            with reset_chain(context):
                ret = visit_function(
                    value, update_chain(context, f"entries.{key}")
                )
            return ret

        return apply_function(
            self,
            context,
            {
                "entries": {
                    visit_function(key, key_context): visit_entry(
                        key, value, context
                    )
                    for key, value in self.items()
                },
                **{
                    key: visit_function(value, context)
                    for key, value in self.vars().items()
                },
            },
        )

    @classmethod
    def configure(cls: "Type[Dict[K, V]]", obj) -> "Type[Dict[K, V]]":

        key, value = next(iter(obj["entries"].items()), (None, None))

        if key is not None and value is not None:
            key_type = key.full_type() if hasattr(key, "full_type") else String
            value_type = value.full_type()
            return cls[key_type, value_type]  # type: ignore
        else:
            return cls
