from typing import Optional

from rvai.types.base_type import BaseType, record
from rvai.types.types.feed import Feed
from rvai.types.types.integer import Integer
from rvai.types.types.string import String


@record
class Port(BaseType):
    """Port Data Type

    :ivar name: a :class:`String` object
    :type name: String
    :ivar port: a :class:`Integer` object
    :type port: Integer
    :ivar service: a :class:`Optional[Feed]` object, defaults to None
    :type service: Optional[Feed]
    """

    name: String
    port: Integer
    service: Optional[Feed] = None
