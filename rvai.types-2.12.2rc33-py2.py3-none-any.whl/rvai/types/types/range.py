from typing import Generic, Optional, Type, TypeVar

from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import CLASS_KEY
from rvai.types.meta_type import GenericMetaType
from rvai.types.types.float import Float
from rvai.types.types.integer import Integer
from rvai.types.utils import TypeFactory
from rvai.types.validation import validate
from rvai.types.visit import update_chain

Number = TypeVar("Number", Float, Integer)


@primitive
class Range(BaseType, Generic[Number], metaclass=GenericMetaType):

    min: Optional[Number]
    max: Optional[Number]
    value: Optional[Number]

    def __init__(self, value=None, min=None, max=None):
        self.value = value
        self.min = min
        self.max = max

        if value is not None and (
            (self.min is not None and self.value < self.min)
            or (self.max is not None and self.value > self.max)
        ):
            raise ValueError(
                f"Range does not satisfy contstraint: {self.min} <= {self.value} <= {self.max}"
            )
        validate(self)

    def __hash__(self):
        return hash(frozenset((self.min, self.max, self.value)))

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self):
        T = TypeFactory(self.full_type_name())
        args = (self.value, self.min, self.max)
        state = (self.get_class(), self.get_attributes())
        return (T, args, state)

    def __repr__(self):
        return f"{self.full_type_name()}(value={repr(self.value)}, min={repr(self.min)}, value={repr(self.max)})"

    def __eq__(self, other):
        eq = True
        if type(self) == type(other):
            eq = self.value == other.value
        else:
            eq = self.value == other
        same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def __ne__(self, other):
        return not self == other

    @classmethod
    def _on_fake(cls, T, context):

        fake_min = context.random.randint(-1000, 1000)
        fake_max = fake_min + context.random.randint(1, 1000)
        fake_value = context.random.randint(fake_min, fake_max)
        cast, *_ = T.__args__

        return cls(
            value=cast(fake_value), min=cast(fake_min), max=cast(fake_max)
        )

    @classmethod
    def visit_type(cls, context, apply_function, visit_function):
        T, *_ = cls.__args__
        return apply_function(
            cls,
            context,
            {
                "value": visit_function(T, context),
                "min": visit_function(T, context),
                "max": visit_function(T, context),
            },
        )

    def visit_type_instance(self, context, apply_function, visit_function):
        return apply_function(
            self,
            context,
            {
                "value": visit_function(
                    self.value, update_chain(context, "value")
                ),
                "min": visit_function(self.min, update_chain(context, "min")),
                "max": visit_function(self.max, update_chain(context, "max")),
            },
        )

    @classmethod
    def configure(cls: "Type[Range]", obj) -> "Type[Range[Number]]":

        item_type = obj["value"].full_type()

        return cls[item_type]  # type: ignore
