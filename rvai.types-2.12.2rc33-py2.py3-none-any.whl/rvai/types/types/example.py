from typing import Any

from rvai.types.base_type import BaseType, record
from rvai.types.types.bounding_box import BoundingBox
from rvai.types.types.dict import Dict
from rvai.types.types.image import Image
from rvai.types.types.list import List
from rvai.types.types.string import String


@record
class Example(BaseType):
    """Example Data Type

    :ivar samples: a :class:`Dict[String, Any]` object
    :type samples: Dict[String, Any]
    :ivar annotations: a :class:`Dict[String, Any]` object
    :type annotations: Dict[String, Any]
    """

    samples: Dict[String, Any]
    annotations: Dict[String, Any]

    def _on_fake(self, context):
        return Example(
            samples=Dict({String("image"): Image.fake(config=context.config)}),
            annotations=Dict(
                {
                    String("bounding_boxes"): List[BoundingBox].fake(
                        config=context.config
                    )
                }
            ),
        )

    def __iter__(self):
        yield self.samples
        yield self.annotations
