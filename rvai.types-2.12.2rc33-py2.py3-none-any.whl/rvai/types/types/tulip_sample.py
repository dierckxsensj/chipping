from typing import Optional

import numpy

from rvai.types.base_type import record
from rvai.types.types.bounding_box import BoundingBox
from rvai.types.types.float import Float
from rvai.types.types.list import List
from rvai.types.types.mask import Mask
from rvai.types.types.ndarray import NDArray
from rvai.types.types.plane import Plane
from rvai.types.types.point3d import Point3D
from rvai.types.types.rigid_transformation_3d import RigidTransformation3D
from rvai.types.types.sample3d2d import Sample3D2D
from rvai.types.types.shape import Shape
from rvai.types.types.sphere import Sphere
from rvai.types.types.timestamp import Timestamp


@record
class TulipSample(Sample3D2D):
    """TulipSample Data Type

    :ivar sphere: a :class: `Sphere` object
    :type sphere: Sphere
    :ivar foreground_masks: a :class: `List[Mask]` object
    :type foreground_masks: List[Mask]
    :ivar backgrounds_timestamp: a :class: `Timestamp` object
    :type backgrounds_timestamp: Timestamp
    :ivar threshold_lower_cameras: a :class: `Float` object
    :type threshold_lower_cameras: Float
    :ivar threshold_upper_cameras: a :class: `Float` object
    :type threshold_upper_cameras: Float
    :ivar bounding_boxes: a :class: `List[BoundingBox]` object
    :type bounding_boxes: List[BoundingBox]
    :ivar point_to_pixel_luts: a :class: `NDArray` object
    :type point_to_pixel_luts: NDArray
    :ivar grid_shape: a :class: `Shape` object
    :type grid_shape: Shape
    :ivar T_global_to_voxels: a :class: `RigidTransformation3D` object
    :type T_global_to_voxels: RigidTransformation3D
    :ivar T_global_to_conveyor: a :class: `Optional[RigidTransformation3D]` object
    :type T_global_to_conveyor: RigidTransformation3D
    :ivar up_direction: a :class: `Optional[Point3D]` object
    :type up_direction: Point3D
    :ivar conveyor_plane: a :class: `Optional[Plane]` object
    :type conveyor_plane: Optional[Plane]
    """

    sphere: Sphere
    foreground_masks: List[Mask]
    backgrounds_timestamp: Timestamp
    threshold_lower_cameras: Float
    threshold_upper_cameras: Float
    bounding_boxes: List[BoundingBox]
    point_to_pixel_luts: NDArray
    T_global_to_voxels: RigidTransformation3D
    grid_shape: Shape
    T_global_to_conveyor: Optional[RigidTransformation3D] = None
    up_direction: Optional[Point3D] = None
    conveyor_plane: Optional[Plane] = None

    def _on_artifacts_encode(self, context):
        context.config["bgr"] = True
        context.config["3dlabeler"] = True
        return None

    @classmethod
    def _on_artifacts_decode(self, context, obj, encoding):
        context.config["bgr"] = True
        return None

    @property
    def occupancy_grid(self) -> NDArray:
        pc_vx = numpy.around(
            self.point_cloud.points @ self.T_global_to_voxels.R.T
            + self.T_global_to_voxels.t.T
        ).astype(int)
        occupancy_grid = numpy.zeros((self.grid_shape), dtype=numpy.bool)
        for idx in range(self.point_cloud.num_points):
            occupancy_grid[pc_vx[idx, 0], pc_vx[idx, 1], pc_vx[idx, 2]] = True
        return NDArray(occupancy_grid)

    @property
    def camera_voxel_positions(self) -> List[NDArray]:
        camera_voxel_positions = []
        for (
            camera_parameters
        ) in (
            self.working_volume_parameters.all_camera_parameters.all_camera_parameters
        ):
            T_camera_to_world = camera_parameters.T_camera_to_world.value
            assert (
                T_camera_to_world is not None
            ), "Cannot calculate camera voxel positions without T_camera_to_world!"
            camera_center_world = T_camera_to_world.t
            camera_center_voxels_float = (
                self.T_global_to_voxels.R @ camera_center_world
                + self.T_global_to_voxels.t
            )
            camera_center_voxels = numpy.floor(
                camera_center_voxels_float
            ).astype(numpy.int)
            camera_voxel_positions.append(camera_center_voxels)
        return List([NDArray(c) for c in camera_voxel_positions])
