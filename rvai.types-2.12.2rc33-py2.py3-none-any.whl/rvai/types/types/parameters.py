from rvai.types.base_mapping import BaseMapping
from rvai.types.base_type import BaseType, primitive
from rvai.types.types.classes import Classes
from rvai.types.types.parameter import DEFAULT_EXPERTISE, Parameter


class NOT_SET:
    pass


@primitive
class Parameters(BaseMapping):
    def __init__(self, entries=None, **kwargs):

        parameters = entries or kwargs
        processed_parameters = {
            name: self._process_value(name, value)
            for name, value in parameters.items()
        }

        super().__init__(**processed_parameters)

    def get_value(self, parameter, default=NOT_SET):
        if default == NOT_SET:
            extract = super().get(parameter)
            if extract is None:
                raise AttributeError(
                    f"Parameter {parameter} is not defined "
                    f"in the Parameters object"
                )
            return getattr(extract, "value")
        else:
            return getattr(super().get(parameter), "value", default)

    def unwrap(self, parameter, default=NOT_SET):
        obj = self.get_value(parameter, default)
        while True:
            try:
                obj = obj.value
            except AttributeError:
                break
        return obj

    def get_name(self, parameter, default=None):
        return getattr(super().get(parameter), "name", default)

    def get_description(self, parameter, default=None):
        return getattr(super().get(parameter), "description", default)

    def get_expertise(self, parameter, default=None):
        return getattr(super().get(parameter), "expertise", default)

    def _process_value(self, name, value):

        if isinstance(value, Parameter):
            return value

        # Raw value format, no description provided
        elif isinstance(value, (BaseType,)):

            display_name = name
            actual_value = value
            description = None
            expertise = DEFAULT_EXPERTISE

        # Classes format (special case)
        elif name == "classes":

            # Unpack if parameter format
            if "value" in value and "description" in value:
                value = value.value

            display_name = "Classes"
            actual_value = (
                value if isinstance(value, Classes) else Classes(value)
            )
            description = "Annotation Classes"
            expertise = DEFAULT_EXPERTISE

        # Dict format { value: str, description: str }
        elif isinstance(value, (dict,)) and ("value" in value):

            display_name = value.get("name", name)
            actual_value = value.get("value")
            description = value.get("description", None)
            expertise = value.get("expertise", DEFAULT_EXPERTISE)

        # Tuple format 1
        elif isinstance(value, (tuple,)) and len(value) == 2:

            actual_value, description = value
            display_name = name
            expertise = DEFAULT_EXPERTISE

        # Tuple format 2
        elif isinstance(value, (tuple,)) and len(value) == 3:

            actual_value, description, expertise = value
            display_name = name

        # Not supported, will raise ValueError
        else:
            display_name = None
            actual_value = None
            description = None
            expertise = None

        if actual_value is None or not (
            isinstance(actual_value, (BaseType,)) or name == "classes"
        ):
            raise ValueError(
                f"Invalid value: `{actual_value}` for parameter with name "
                f"`{name}`."
            )

        return Parameter(
            name=display_name,
            value=actual_value,
            description=description,
            expertise=expertise,
        )

    @property
    def metadata(self):
        return {
            parameter: {k: v for k, v in data.items() if k is not "value"}
            for parameter, data in super().items()
        }

    def __add__(self, other):
        """
        Merge 2 parameter objects
        where the right operand overrides parameters of
        the left operand
        """
        if not isinstance(other, Parameters):
            raise ValueError("Not a `Parameters` object")

        return Parameters({**self, **other})

    def __repr__(self):
        entries = ", ".join(f'"{str(k)}": {repr(v)}' for k, v in self.items())
        return f"Parameters(entries={{{entries}}})"
