from typing import Optional

from rvai.types.base_type import BaseType, record
from rvai.types.types.bounding_box import BoundingBox
from rvai.types.types.image_set import ImageSet
from rvai.types.types.list import List
from rvai.types.types.mask import Mask
from rvai.types.types.ndarray import NDArray
from rvai.types.types.point_cloud import PointCloud
from rvai.types.types.working_volume_geometry import WorkingVolumeGeometry


@record
class VoxelCarvingReconstruction(BaseType):
    """VoxelCarvingReconstruction Data Type

    :ivar working_volume_geometry: a :class:`WorkingVolumeGeometry` object
    :type working_volume_geometry: WorkingVolumeGeometry
    :ivar image_set: a :class:`ImageSet` object
    :type image_set: ImageSet
    :ivar point_cloud: a :class:`PointCloud` object
    :type point_cloud: PointCloud
    :ivar foreground_masks: a :class:`Optional[List[Mask]]` object, defaults to None
    :type foreground_masks: Optional[List[Mask]]
    :ivar bounding_boxes: a :class:`Optional[List[BoundingBox]]` object, defaults to None
    :type bounding_boxes: Optional[List[BoundingBox]]
    :ivar occupancy_grid: a :class:`Optional[NDArray]` object, defaults to None
    :type occupancy_grid: Optional[NDArray]
    :ivar voxel_to_point_lut: a :class:`Optional[NDArray]` object, defaults to None
    :type voxel_to_point_lut: Optional[NDArray]
    :ivar point_to_voxel_lut: a :class:`Optional[NDArray]` object, defaults to None
    :type point_to_voxel_lut: Optional[NDArray]
    :ivar point_to_pixel_luts: a :class:`Optional[NDArray]` object, defaults to None
    :type point_to_pixel_luts: Optional[NDArray]
    """

    working_volume_geometry: WorkingVolumeGeometry
    image_set: ImageSet
    point_cloud: PointCloud
    foreground_masks: Optional[List[Mask]] = None
    bounding_boxes: Optional[List[BoundingBox]] = None
    occupancy_grid: Optional[NDArray] = None
    voxel_to_point_lut: Optional[NDArray] = None
    point_to_voxel_lut: Optional[NDArray] = None
    point_to_pixel_luts: Optional[NDArray] = None
