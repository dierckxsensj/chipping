from rvai.types.base_type import BaseType, record
from rvai.types.constants import CLASS_KEY


@record
class Boolean(BaseType):
    """Boolean Data Type

    :ivar value: a :class:`bool` object
    :type value: bool
    """

    value: bool

    def __bool__(self):
        return self.value

    def __eq__(self, other):
        eq = False
        if self.value == other:
            eq = True
        same_class = True
        if isinstance(other, BaseType):
            same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def __req__(self, other):
        eq = False
        if self.value == other:
            eq = True
        same_class = True
        if isinstance(other, BaseType):
            same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class
