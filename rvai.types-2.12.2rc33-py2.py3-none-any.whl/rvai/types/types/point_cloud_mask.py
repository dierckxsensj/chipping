import numpy as np

from rvai.types.base_type import primitive
from rvai.types.types.ndarray import NDArray


@primitive
class PointCloudMask(NDArray):
    def __new__(cls, data):
        """ Required for subclassing ndarray. See:
            https://www.csie.ntu.edu.tw/~azarc/sna/numpy-1.3.0/numpy/doc/subclassing.py
        """

        data_array = np.asarray(data).astype(np.bool)
        shape = data_array.shape
        assert len(shape) == 1 or (
            len(shape) == 2 and shape[1] == 1
        ), "Data shape is required to be (num_points, 1) or (num_points,)"
        data_array = data_array.reshape((-1,))
        return np.asarray(data_array).astype(np.bool).view(cls)

    @classmethod
    def _on_fake(cls, T, context):
        num_points = context.np.randint(300)
        data = context.np.choice(a=[False, True], size=(num_points, 1))
        return cls(data,)
