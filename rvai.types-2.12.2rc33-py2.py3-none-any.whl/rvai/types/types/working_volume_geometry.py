from rvai.types.base_type import BaseType, record
from rvai.types.types.list import List
from rvai.types.types.ndarray import NDArray
from rvai.types.types.optional import Optional
from rvai.types.types.rigid_transformation_3d import RigidTransformation3D
from rvai.types.types.timestamp import Timestamp
from rvai.types.types.working_volume_parameters import WorkingVolumeParameters


@record
class WorkingVolumeGeometry(BaseType):
    """WorkingVolumeGeometry Data Type

    :ivar working_volume_parameters: a :class:`WorkingVolumeParameters` object
    :type working_volume_parameters: WorkingVolumeParameters
    :ivar timestamp: a :class:`Optional[Timestamp]` object
    :type timestamp: Optional[Timestamp]
    :ivar T_global_to_voxels: a :class:`RigidTransformation3D` object
    :type T_global_to_voxels: RigidTransformation3D
    :ivar T_voxels_to_global: a :class:`RigidTransformation3D` object
    :type T_voxels_to_global: RigidTransformation3D
    :ivar grid: a :class:`List[NDArray]` object
    :type grid: List[NDArray]
    :ivar voxel_to_pixel_luts: a :class:`List[NDArray]` object
    :type voxel_to_pixel_luts: List[NDArray]
    :ivar camera_voxel_positions: a :class:`List[NDArray]` object
    :type camera_voxel_positions: List[NDArray]
    """

    working_volume_parameters: WorkingVolumeParameters
    timestamp: Optional[Timestamp]
    T_global_to_voxels: RigidTransformation3D
    T_voxels_to_global: RigidTransformation3D
    grid: List[NDArray]
    voxel_to_pixel_luts: List[NDArray]
    camera_voxel_positions: List[NDArray]
