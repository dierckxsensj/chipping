from dataclasses import field
from io import BytesIO
from typing import List

import h5py
import numpy as np
import pybase64
from pydicom import Dataset, FileDataset, Sequence, dcmread, dcmwrite
from pydicom.filebase import DicomBytesIO
from pydicom.uid import ImplicitVRLittleEndian

from rvai.types.base_type import BaseType, record
from rvai.types.constants import ENCODING_KEY, REF_KEY, TYPE_KEY
from rvai.types.types.ndarray import NDArray

DEFAULT_FAKE_SHAPE = (128, 256, 256)
DEFAULT_FAKE_ANNOTATION_SHAPE = (1, 1, 128, 256, 256)


def to_dcm(dicom: "DICOM") -> bytes:
    pixel_data: np.ndarray = dicom.data
    pixel_spacing: np.ndarray = dicom.spacing

    ds = FileDataset("filenamedoesntmatter", {}, file_meta=Dataset())
    ds.file_meta.TransferSyntaxUID = ImplicitVRLittleEndian
    ds.SamplesPerPixel = 1
    ds.PixelRepresentation = 0
    assert pixel_data.dtype == np.uint16, "currently supports uint16 only"
    ds.BitsAllocated = 16
    ds.Columns = pixel_data.shape[1]
    ds.Rows = pixel_data.shape[2]
    ds.NumberOfFrames = pixel_data.shape[0]
    ds.PhotometricInterpretation = "MONOCHROME2"
    ds.PixelData = pixel_data.tobytes()

    ds.SharedFunctionalGroupsSequence = Sequence([Dataset()])
    ds.SharedFunctionalGroupsSequence[0].PixelSpacing = pixel_spacing[
        1:
    ].tolist()

    per_frame_ds_sequence: List[Dataset] = []
    for _ in range(pixel_data.shape[2]):
        per_frame_ds = Dataset()
        per_frame_ds.SliceThickness = pixel_spacing[0]
        per_frame_ds_sequence.append(per_frame_ds)
    ds.PerFrameFunctionalGroupsSequence = Sequence(per_frame_ds_sequence)

    dcm_file_buffer = DicomBytesIO()
    dcmwrite(dcm_file_buffer, ds)
    return dcm_file_buffer.getvalue()


def from_dcm(dcm_file: bytes) -> "DICOM":
    dcm_file_buffer = DicomBytesIO(dcm_file)
    ds = dcmread(dcm_file_buffer, force=True)
    pixel_array = ds.pixel_array
    pixel_spacing = [
        float(ds.PerFrameFunctionalGroupsSequence[0].SliceThickness)
    ] + list(ds.SharedFunctionalGroupsSequence[0].PixelSpacing)
    shift_scale = NDArray([0.0, 1.0])
    return DICOM(NDArray(pixel_array), NDArray(pixel_spacing), shift_scale)


def dicom_to_h5(dicom: "DICOM") -> bytes:
    h5_file_buffer = BytesIO()
    with h5py.File(h5_file_buffer, mode="w") as f:
        f["data"] = dicom.data
        f["_spacing"] = np.array(
            [[dicom.spacing[1], dicom.spacing[2], dicom.spacing[0],]]
        )
        f["_shiftScale"] = np.array([dicom.shift_scale])
    return h5_file_buffer.getvalue()


def dicom_from_h5(h5_file: bytes) -> "DICOM":
    h5_file_bytesio = BytesIO(h5_file)
    dicom_data = h5py.File(h5_file_bytesio, mode="r")
    data = NDArray(dicom_data["data"])
    spacing = NDArray(dicom_data["_spacing"])[0]
    spacing = NDArray([spacing[2], spacing[0], spacing[1]])
    shift_scale = NDArray(dicom_data["_shiftScale"])[0]
    return DICOM(data, spacing, shift_scale)


@record
class DICOM(BaseType):

    data: NDArray  # shape (1, #channels, #slices, #rows, #columns)
    spacing: NDArray  # [slice-spacing, X-spacing, Y-spacing]
    shift_scale: NDArray = field(
        default_factory=lambda: NDArray([0.0, 1.0])
    )  # [intercept, slope]

    def _on_artifacts_encode(self, context):
        encoding = context.config.get("dicom_encoding", "h5")

        if encoding == "dcm":
            buffer = to_dcm(self)
            ref = context.create_artifact("data", buffer, "dcm")
        else:
            buffer = dicom_to_h5(self)
            ref = context.create_artifact("data", buffer, "h5")

        return {
            TYPE_KEY: self.type_name(),
            ENCODING_KEY: {"data": encoding},
            "data": {REF_KEY: ref},
        }

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):
        data = obj.pop("data")
        ref = data.get(REF_KEY).split("#/resources/").pop(-1)
        artifact = context.artifacts[ref]

        obj.pop(TYPE_KEY, None)
        obj.pop(ENCODING_KEY, None)

        if encoding is not None and encoding["data"] == "dcm":
            return from_dcm(artifact)
        else:
            return dicom_from_h5(artifact)

    @classmethod
    def _on_fake(cls, T, context):
        shape = context.config.get("DICOM_FAKE_SHAPE", DEFAULT_FAKE_SHAPE)
        fake_data = context.np.randint(
            0, np.iinfo(np.uint16).max, shape, dtype=np.uint16
        )
        pixel_spacing = context.random.random() + 0.5
        frame_spacing = context.random.random() * 5 + 0.5
        fake_spacing = (frame_spacing, pixel_spacing, pixel_spacing)
        fake_shift_scale = NDArray([0.0, 1.0])
        return DICOM(fake_data, fake_spacing, fake_shift_scale)

    def _on_json_encode(self, context):
        encoding = context.config.get("dicom_encoding", "h5")

        if encoding == "dcm":
            buffer = to_dcm(self)
        else:
            buffer = dicom_to_h5(self)

        return {
            TYPE_KEY: self.type_name(),
            ENCODING_KEY: {"data": encoding},
            "data": pybase64.b64encode(buffer).decode("utf-8"),
        }

    @classmethod
    def _on_json_decode(cls, context, obj, encoding):
        data = pybase64.b64decode(obj["data"])
        if encoding["data"] == "dcm":
            return from_dcm(data)
        elif encoding["data"] == "h5":
            return dicom_from_h5(data)
        else:
            raise Exception(f"Unsupported dicom encoding: {encoding['data']}.")


def to_h5(dicom_anno: "DICOMAnnotation") -> bytes:
    h5_file_buffer = BytesIO()
    with h5py.File(h5_file_buffer, mode="w") as f:
        f["Labels"] = dicom_anno.data
        f["_spacing"] = np.array(
            [
                [
                    dicom_anno.spacing[1],
                    dicom_anno.spacing[2],
                    dicom_anno.spacing[0],
                ]
            ]
        )
        f["_shiftScale"] = np.array([[0.0, 1.0]])
    return h5_file_buffer.getvalue()


def from_h5(h5_file: bytes) -> "DICOMAnnotation":
    h5_file_bytesio = BytesIO(h5_file)
    annotation_data = h5py.File(h5_file_bytesio, mode="r")
    labels = NDArray(annotation_data["Labels"])
    spacing = NDArray(annotation_data["_spacing"])[0]
    spacing = NDArray([spacing[2], spacing[0], spacing[1]])
    return DICOMAnnotation(labels, spacing)


@record
class DICOMAnnotation(BaseType):

    data: NDArray
    spacing: NDArray

    def _on_artifacts_encode(self, context):
        buffer = to_h5(self)
        ref = context.create_artifact("data", buffer)
        return {
            TYPE_KEY: self.type_name(),
            "data": {REF_KEY: ref},
        }

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):
        data = obj.pop("data")
        ref = data.get(REF_KEY).split("#/resources/").pop(-1)
        artifact = context.artifacts[ref]
        obj.pop(TYPE_KEY, None)
        return from_h5(artifact)

    @classmethod
    def _on_fake(cls, T, context):
        shape = context.config.get(
            "DICOM_FAKE_ANNOTATION_SHAPE", DEFAULT_FAKE_ANNOTATION_SHAPE
        )
        fake_data = context.np.randint(0, 5, shape, dtype=np.uint8)
        pixel_spacing = context.random.random() + 0.5
        frame_spacing = context.random.random() * 5 + 0.5
        fake_spacing = (frame_spacing, pixel_spacing, pixel_spacing)
        return DICOMAnnotation(fake_data, fake_spacing)

    def _on_json_encode(self, context):
        buffer = to_h5(self)
        return {
            TYPE_KEY: self.type_name(),
            "data": pybase64.b64encode(buffer).decode("utf-8"),
        }

    @classmethod
    def _on_json_decode(cls, context, obj, encoding):
        data = pybase64.b64decode(obj["data"])
        return from_h5(data)
