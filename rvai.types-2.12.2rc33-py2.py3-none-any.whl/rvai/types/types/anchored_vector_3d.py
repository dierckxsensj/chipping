from rvai.types.base_type import BaseType, record
from rvai.types.types.point3d import Point3D


@record
class AnchoredVector3D(BaseType):
    """Vector Data Type

    :ivar anchor: a :class:`Point3D` object
    :type anchor: Point3D
    :ivar direction: a :class:`Point3D` object
    :type direction: Point3D
    """

    anchor: Point3D
    direction: Point3D
