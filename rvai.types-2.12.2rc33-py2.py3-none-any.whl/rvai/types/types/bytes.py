from typing import cast

import numpy as np
import pybase64

from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import REF_KEY, TYPE_KEY
from rvai.types.serialization.json_struct import to_camel_case, to_snake_case


@primitive
class Bytes(BaseType, bytes):
    def __new__(cls, value: bytes) -> "Bytes":
        return cast(Bytes, super().__new__(cls, value))  # type: ignore

    def __hash__(self):
        return hash(bytes(self))

    def _on_hash(self, context):
        return context.update_hash(bytes(self))

    def _on_marshall(self, context):
        return {
            TYPE_KEY: "Bytes",
            "value": np.frombuffer(bytes(self), dtype=np.uint8),
        }

    @classmethod
    def _on_unmarshall(cls, context, obj, encoding):
        return cls(bytes(obj["value"]))

    def _on_json_encode(self, context):
        return {
            TYPE_KEY: "Bytes",
            "value": pybase64.b64encode(bytes(self)).decode("utf-8"),
        }

    @classmethod
    def _on_json_decode(cls, context, obj, encoding):
        return cls(pybase64.b64decode(obj["value"]))

    def _on_artifacts_encode(self, context):

        ref = context.create_artifact("value", bytes(self))

        return {
            TYPE_KEY: self.type_name(),
            "value": {REF_KEY: ref},
            **{to_camel_case(k): v for k, v in self.vars().items()},
        }

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):

        ref = obj.pop("value").get(REF_KEY).split("#/resources/").pop(-1)
        artifact = context.artifacts[ref]

        obj.pop(TYPE_KEY, None)

        return cls(
            artifact,
            **{
                to_snake_case(k): v
                for k, v in obj.items()
                if k not in ["resources"]
            },
        )

    @classmethod
    def _on_fake(cls, T, context):
        value = bytes(context.np.bytes(context.np.randint(0, 100)))
        return Bytes(value)

    def __repr__(self):
        return f"Bytes({self.hex()})"

    def to_args(self):
        return {"value": bytes(self)}
