import json

from rvai.types.base_type import BaseType, record
from rvai.types.constants import ENCODING_KEY, REF_KEY, TYPE_KEY
from rvai.types.types.camera_parameters import (
    CameraParameters,
    from_json,
    to_json,
)
from rvai.types.types.list import List
from rvai.types.types.optional import Optional
from rvai.types.types.timestamp import Timestamp


@record
class CameraArrayParameters(BaseType):
    """CameraArrayParameters Data Type

    :ivar all_camera_parameters: a :class:`List[CameraParameters]` object
    :type all_camera_parameters: List[CameraParameters]
    :ivar calibration_timestamp: a :class:`Optional[Timestamp]` object
    :type calibration_timestamp: Optional[Timestamp]
    """

    all_camera_parameters: List[CameraParameters]
    calibration_timestamp: Optional[Timestamp]

    def _on_artifacts_encode(self, context):
        if context.config.get("3dlabeler", False):
            json_data = [
                to_json(camera_parameters)
                for camera_parameters in self.all_camera_parameters
            ]
            buffer = json.dumps(json_data).encode("utf-8")
            ref = context.create_artifact("data", buffer, "json")

            timestamp_data, _ = self.calibration_timestamp.to_artifacts()
            timestamp_data.pop("resources")

            return {
                TYPE_KEY: self.type_name(),
                ENCODING_KEY: {"data": "json"},
                "timestamp": dict(timestamp_data),
                "data": {REF_KEY: ref},
            }
        else:
            return None

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):

        if encoding is not None and encoding["data"] == "json":
            data = obj.pop("data")
            ref = data.get(REF_KEY).split("#/resources/").pop(-1)
            artifact = context.artifacts[ref]
            timestamp = context.deserialize(obj.pop("timestamp"))

            obj.pop(TYPE_KEY, None)
            obj.pop(ENCODING_KEY, None)

            json_data = json.loads(artifact.decode("utf-8"))
            camera_parameters = List(
                [from_json(json_element) for json_element in json_data]
            )
            return CameraArrayParameters(camera_parameters, timestamp)
        else:
            return None
