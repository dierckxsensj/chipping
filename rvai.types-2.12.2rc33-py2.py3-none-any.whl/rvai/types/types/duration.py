from rvai.types.base_type import BaseType, record


@record
class Duration(BaseType):
    """Duration Data Type

    :ivar seconds: a :class:`float` object, defaults to (0)
    :type seconds: float
    """

    seconds: float = 0

    @property
    def microseconds(self) -> float:
        return self.seconds * 1000

    @property
    def minutes(self) -> float:
        return self.seconds / 60

    @property
    def hours(self) -> float:
        return self.minutes / 60

    @property
    def days(self) -> float:
        return self.hours / 24
