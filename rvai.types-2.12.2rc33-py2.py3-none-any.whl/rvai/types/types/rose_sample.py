import numpy

from rvai.types.base_type import record
from rvai.types.types.list import List
from rvai.types.types.mask import Mask
from rvai.types.types.ndarray import NDArray
from rvai.types.types.rigid_transformation_3d import RigidTransformation3D
from rvai.types.types.sample3d2d import Sample3D2D
from rvai.types.types.shape import Shape


@record
class RoseSample(Sample3D2D):
    """RoseSample Data Type

    :ivar foreground_masks: a :class: `List[Mask]` object
    :type foreground_masks: List[Mask]
    :ivar T_global_to_voxels: a :class: `RigidTransformation3D` object
    :type T_global_to_voxels: RigidTransformation3D
    :ivar grid_shape: a :class: `Shape` object
    :type grid_shape: Shape
    """

    foreground_masks: List[Mask]
    T_global_to_voxels: RigidTransformation3D
    grid_shape: Shape

    @property
    def occupancy_grid(self) -> NDArray:
        pc_vx = numpy.around(
            self.point_cloud.points @ self.T_global_to_voxels.R.T
            + self.T_global_to_voxels.t.T
        ).astype(int)
        occupancy_grid = numpy.zeros((self.grid_shape), dtype=numpy.bool)
        for idx in range(self.point_cloud.num_points):
            occupancy_grid[pc_vx[idx, 0], pc_vx[idx, 1], pc_vx[idx, 2]] = True
        return occupancy_grid
