import numpy as np

from rvai.types.base_type import BaseType, record
from rvai.types.types.ndarray import NDArray
from rvai.types.types.point3d import Point3D


@record
class Plane(BaseType):
    """Plane Data Type
    plane expressed as a * x + b * y + c * z + d = 0

    :ivar a: a :class:`float` object
    :type a: float
    :ivar b: a :class:`float` object
    :type b: float
    :ivar c: a :class:`float` object
    :type c: float
    :ivar d: a :class:`float` object
    :type d: float
    """

    a: float
    b: float
    c: float
    d: float

    @property
    def abcd(self):
        return self.a, self.b, self.c, self.d

    def to_ndarray(self) -> NDArray:
        return NDArray(self.abcd)

    @classmethod
    def from_ndarray(cls, ndarray: NDArray) -> "Plane":
        ndarray_flat = ndarray.flatten()
        if ndarray_flat.size != 4:
            raise ValueError("Expected a 4 element array!")
        return Plane(
            a=ndarray_flat[0],
            b=ndarray_flat[1],
            c=ndarray_flat[2],
            d=ndarray_flat[3],
        )

    @classmethod
    def from_points(cls, pt1: Point3D, pt2: Point3D, pt3: Point3D) -> "Plane":
        """
        Describing a plane through 3 points
        """
        d = 1.0
        D = np.linalg.det(
            np.array(
                [
                    [pt1.x, pt1.y, pt1.z],
                    [pt2.x, pt2.y, pt2.z],
                    [pt3.x, pt3.y, pt3.z],
                ]
            )
        )
        a = (-d / D) * np.linalg.det(
            np.array([[1, pt1.y, pt1.z], [1, pt2.y, pt2.z], [1, pt3.y, pt3.z]])
        )
        b = (-d / D) * np.linalg.det(
            np.array([[pt1.x, 1, pt1.z], [pt2.x, 1, pt2.z], [pt3.x, 1, pt3.z]])
        )
        c = (-d / D) * np.linalg.det(
            np.array([[pt1.x, pt1.y, 1], [pt2.x, pt2.y, 1], [pt3.x, pt3.y, 1]])
        )
        return Plane(a=a, b=b, c=c, d=d)

    @classmethod
    def from_point_and_normal(cls, pt: Point3D, normal: Point3D) -> "Plane":
        """
        Describing a plane by a point in the plane and a vector orthogonal to
        it
        """
        normal_normalized = normal.to_ndarray()
        normal_normalized = normal_normalized / np.linalg.norm(
            normal_normalized
        )
        d = -(normal_normalized @ pt.to_ndarray())
        return Plane(
            a=normal_normalized[0],
            b=normal_normalized[1],
            c=normal_normalized[2],
            d=d,
        )
