from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import CLASS_KEY, MAX_FLOAT, MIN_FLOAT, TYPE_KEY


@primitive
class Float(BaseType, float):
    def __new__(cls, value):
        return super(Float, cls).__new__(cls, value)

    def _on_hash(self, context):
        return context.update_hash(float(self))

    @classmethod
    def _on_fake(cls, T, context):
        return cls(round(context.random.uniform(MIN_FLOAT, MAX_FLOAT), 5))

    def _on_marshall(self, context):
        return {TYPE_KEY: self.type_name(), "value": float(self)}

    def __repr__(self):
        return f"Float(value={float(self)})"

    def __hash__(self):
        return hash(float(self))

    def __eq__(self, other):
        eq = False
        if float(self) == other:
            eq = True
        same_class = True
        if isinstance(other, BaseType):
            same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def __req__(self, other):
        eq = False
        if float(self) == other:
            eq = True
        same_class = True
        if isinstance(other, BaseType):
            same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def to_args(self):
        return {"value": float(self)}
