from rvai.types.base_mapping import BaseMapping
from rvai.types.base_type import primitive


@primitive
class Inputs(BaseMapping):
    def __repr__(self):
        entries = ", ".join(f'"{str(k)}": {repr(v)}' for k, v in self.items())
        return f"Inputs(entries={{{entries}}})"

    def get_index(self):
        return self.metadata.get("index", -1)

    def get_timestamp(self):
        return self.metadata.get("timestamp", 0.0)

    def get_sourcename(self):
        return self.metadata.get("sourcename", "")

    @property
    def metadata(self):
        return self.get("_RVAI_METADATA", {})
