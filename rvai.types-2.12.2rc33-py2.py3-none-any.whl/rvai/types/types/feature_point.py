from rvai.types.base_type import record
from rvai.types.types.ndarray import NDArray
from rvai.types.types.point import Point


@record
class FeaturePoint(Point):
    """A point with an array of features. 

    :ivar features: a :class:`NDArray` object representing features associated
    with the point
    :type features: NDArray
    """

    features: NDArray
