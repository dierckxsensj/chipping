from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import TYPE_KEY


@primitive
class Shape(BaseType, tuple):
    def __new__(cls, *args, value=None):
        if len(args) == 1 and type(args[0]) == tuple:
            value = args[0]
        elif len(args) > 0:
            value = args

        return tuple.__new__(cls, value)

    def _on_hash(self, context):
        for dim in self:
            context.update_hash(dim)
        return True

    @classmethod
    def _on_fake(cls, T, context):
        return cls(
            tuple(
                context.random.randint(0, 100)
                for _ in range(context.random.randint(0, 10))
            )
        )

    def _on_marshall(self, context):
        return {TYPE_KEY: self.type_name(), "value": list(self)}

    def _on_json_encode(self, context):
        return {TYPE_KEY: self.type_name(), "value": list(self)}

    def __repr__(self):
        return f"Shape(value=({', '.join(str(r) for r in self)}))"

    def to_args(self):
        return {"value": tuple(self)}
