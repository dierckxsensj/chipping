from typing import Generic, Optional, Type, TypeVar

from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import CLASS_KEY
from rvai.types.meta_type import GenericMetaType
from rvai.types.utils import TypeFactory
from rvai.types.visit import reset_chain, update_chain

# ==============================================================================

T = TypeVar("T", bound=BaseType)


@primitive
class Attribute(BaseType, Generic[T], metaclass=GenericMetaType):

    value: Optional[T]
    name: Optional[str] = None
    description: Optional[str] = None
    default: Optional[T] = None

    def __init__(
        self,
        value: Optional[T] = None,
        name: Optional[str] = None,
        description: Optional[str] = None,
        default: Optional[T] = None,
    ):
        if value is not None and not isinstance(value, BaseType):
            name_str = f" for `{name}`" if name is not None else ""
            raise ValueError(
                f"Attribute value{name_str} should be a BaseType not a `{type(value).__name__}`"
            )
        if default is not None and not isinstance(default, BaseType):
            name_str = f" for `{name}`" if name is not None else ""
            raise ValueError(
                f"Attribute default value{name_str} should be a BaseType not a `{type(value).__name__}`"
            )

        self.value: T = value
        self.name = name
        self.description = description
        self.default = default

    def __hash__(self):
        return hash(self.value)

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self):
        T = TypeFactory(self.full_type_name())
        args = (self.value, self.name, self.description)
        state = (self.get_class(), self.get_attributes())
        return (T, args, state)

    def __repr__(self):
        return f"{self.full_type_name()}(value={repr(self.value)})"

    def __eq__(self, other):
        eq = True

        if type(self) == type(other):
            eq = self.value == other.value
        else:
            eq = self.value == other

        same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def __ne__(self, other):
        return not self == other

    @classmethod
    def visit_type(cls, context, apply_function, visit_function):
        T, *_ = cls.__args__
        return apply_function(
            cls,
            context,
            {
                "value": visit_function(T, context),
                "name": None,
                "description": None,
                "default": None,
            },
        )

    def visit_type_instance(self, context, apply_function, visit_function):
        with reset_chain(context):
            ret = apply_function(
                self,
                context,
                {
                    "value": visit_function(
                        self.value, update_chain(context, "value")
                    ),
                    "name": self.name,
                    "description": self.description,
                },
            )
        return ret

    @classmethod
    def configure(cls: "Type[Attribute]", obj) -> "Type[Attribute[T]]":

        item_type = (
            obj["value"].full_type() if obj.get("value") is not None else None
        )

        if item_type is None:
            return cls

        return cls[item_type]  # type: ignore


# ==============================================================================

"""
@record
class Attribute(BaseType):

    value: Optional[BaseType]
    name: Optional[str] = None
    description: Optional[str] = None

    def _on_fake(self, context):
        return Attribute(
            name="Some Attribute",
            value=Integer(context.np.randint(-MAX_SIZE, MAX_SIZE)),
            description="Description of some attribute...",
        )

    def __eq__(self, other):
        eq = self.value == getattr(other, "value", None)
        same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def __ne__(self, other):
        return not self.__eq__(other)

    def items(self):
        return {
            "name": self.name,
            "description": self.description,
            "value": self.value,
        }.items()
"""
