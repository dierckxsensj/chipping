from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import CLASS_KEY, TYPE_KEY
from rvai.types.fuzzing.fake import MAX_SIZE


@primitive
class Integer(BaseType, int):
    def __new__(cls, value):
        return super(Integer, cls).__new__(cls, value)

    def _on_hash(self, context):
        return context.update_hash(int(self))

    @classmethod
    def _on_fake(cls, T, context):
        return cls(context.random.randint(-MAX_SIZE, MAX_SIZE))

    def _on_marshall(self, context):
        return {TYPE_KEY: self.type_name(), "value": int(self)}

    def __repr__(self):
        return f"Integer(value={int(self)})"

    def __hash__(self):
        return hash(int(self))

    def __eq__(self, other):
        eq = False
        if int(self) == other:
            eq = True
        same_class = True
        if isinstance(other, BaseType):
            same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def __req__(self, other):
        eq = False
        if int(self) == other:
            eq = True
        same_class = True
        if isinstance(other, BaseType):
            same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def to_args(self):
        return {"value": int(self)}
