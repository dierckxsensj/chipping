from typing import Optional, TypeVar

from rvai.types.base_type import primitive
from rvai.types.types.class_ import Class
from rvai.types.types.dict import Dict
from rvai.types.types.string import String
from rvai.types.utils import TypeFactory

# ==============================================================================

V = TypeVar("V")


@primitive
class ClassParameters(Dict[String, V]):

    default: Optional[V]

    def __init__(self, entries=None, default: Optional[V] = None, **kwargs):
        entries = kwargs or entries or {}
        self.default = default
        dict.__init__(self, entries)

    # This method is defined in `base_mutable.BaseDict`. We override it here
    # to allow indexing with a Class as well (besides indexing the normal way
    # with a Class uuid string).
    def _transform_key(self, key):
        if isinstance(key, String):
            return key
        elif isinstance(key, Class):
            return String(key.class_uuid)
        else:
            return String(key)

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self):
        T = TypeFactory(self.full_type_name())
        args = (
            dict(self),
            self.default,
        )
        state = (self.get_class(), self.get_attributes())
        return (T, args, state)
