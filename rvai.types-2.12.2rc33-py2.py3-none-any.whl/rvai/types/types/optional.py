from typing import Generic, Optional as TypingOptional, Type, TypeVar

from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import CLASS_KEY
from rvai.types.meta_type import GenericMetaType
from rvai.types.utils import TypeFactory
from rvai.types.visit import reset_chain, update_chain

T = TypeVar("T")


@primitive
class Optional(BaseType, Generic[T], metaclass=GenericMetaType):

    value: TypingOptional[T]

    def __init__(self, value=None):
        self.value = value

    def __hash__(self):
        return hash(self.value)

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self):
        T = TypeFactory(self.full_type_name())
        args = (self.value,)
        state = (self.get_class(), self.get_attributes())
        return (T, args, state)

    def __repr__(self):
        return f"{self.full_type_name()}(value={repr(self.value)})"

    def __eq__(self, other):
        eq = True

        if type(self) == type(other):
            eq = self.value == other.value
        else:
            eq = self.value == other

        same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def __ne__(self, other):
        return not self == other

    @classmethod
    def visit_type(cls, context, apply_function, visit_function):
        T, *_ = cls.__args__
        return apply_function(
            cls, context, {"value": visit_function(T, context)}
        )

    def visit_type_instance(self, context, apply_function, visit_function):
        with reset_chain(context):
            ret = apply_function(
                self,
                context,
                {
                    "value": visit_function(
                        self.value, update_chain(context, "value")
                    )
                },
            )
        return ret

    @classmethod
    def configure(cls: "Type[Optional]", obj) -> "Type[Optional[T]]":

        item_type = (
            obj["value"].full_type() if obj.get("value") is not None else None
        )

        if item_type is None:
            return cls

        return cls[item_type]  # type: ignore


Null: Optional = Optional(None)
Some = Optional
