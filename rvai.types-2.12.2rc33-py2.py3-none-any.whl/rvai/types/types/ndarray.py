import copy
import inspect
import logging
import zlib
from typing import Union

import numpy as np
import pybase64

from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import CLASS_KEY, ENCODING_KEY, REF_KEY, TYPE_KEY
from rvai.types.fuzzing.fake import _fake_annotations
from rvai.types.serialization.json_struct import to_camel_case, to_snake_case
from rvai.types.serialization.msgpack import pack, unpack
from rvai.types.utils import as_numpy_index

DEFAULT_FAKE_SHAPE = (50, 40, 30, 10)
NDARRAY_INDEX_KEY = "$index"


@primitive
class NDArray(BaseType, np.ndarray):

    data: np.ndarray

    def __new__(cls, data):
        """ Required for subclassing ndarray. See:
            https://www.csie.ntu.edu.tw/~azarc/sna/numpy-1.3.0/numpy/doc/subclassing.py
        """
        return np.asarray(data).view(cls)

    def __hash__(self):
        return hash(self.data.tobytes())

    def _on_hash(self, context):
        return context.update_hash(np.ascontiguousarray(self))

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self):
        state = (self.get_class(), self.get_attributes())
        return (type(self), tuple(self.to_args().values()), state)

    def __deepcopy__(self, memo):
        args = list(map(copy.deepcopy, self.to_args().values()))
        return type(self)(*args)

    @classmethod
    def _on_fake(cls, T, context):
        shape = context.config.get("NDARRAY_FAKE_SHAPE", DEFAULT_FAKE_SHAPE)

        # subclasses can define extra attributes using cls annotations
        attribute_values = _fake_annotations(cls, context, ignore=["data"])
        # the data attribute is special cased though
        attribute_values.pop("data", None)

        return cls(data=context.np.rand(*shape), **attribute_values)

    def _on_marshall(self, context):

        return {
            TYPE_KEY: self.type_name(),
            "data": np.asarray(self),
            **{k: context.serialize(v) for k, v in self.vars().items()},
        }

    def _on_json_encode(self, context):

        use_compression = context.config.get("compression", True)

        if use_compression:
            data = zlib.compress(pack(np.asarray(self)))
            encoding = "msgpack+zlib+base64"
        else:
            data = pack(np.asarray(self))
            encoding = "msgpack+base64"

        return {
            TYPE_KEY: self.type_name(),
            ENCODING_KEY: {"data": encoding},
            "data": pybase64.b64encode(data).decode("utf-8"),
            **{
                to_camel_case(k): context.serialize(v)
                for k, v in self.vars().items()
            },
        }

    @classmethod
    def _on_json_decode(cls, context, obj, encoding):

        artifact = obj.pop("data")

        if encoding["data"] == "msgpack+zlib+base64":
            artifact = zlib.decompress(pybase64.b64decode(artifact))
            data = unpack(artifact)
        elif encoding["data"] == "msgpack+base64":
            artifact = pybase64.b64decode(artifact)
            data = unpack(artifact)
        else:
            raise ValueError(
                f"No or wrong encoding specified for data: {encoding}"
            )

        obj.pop(TYPE_KEY, None)
        obj.pop(ENCODING_KEY, None)

        return cls(
            data,
            **{
                to_snake_case(k): context.deserialize(v)
                for k, v in obj.items()
            },
        )

    def _on_artifacts_encode(self, context):

        use_compression = context.config.get("compression", True)

        if use_compression:
            data = zlib.compress(pack(np.asarray(self)))
            ref = context.create_artifact("data", data, "msgpack.zlib")
            encoding = "msgpack+zlib"
        else:
            data = pack(np.asarray(self))
            ref = context.create_artifact("data", data, "msgpack")
            encoding = "msgpack"

        return {
            TYPE_KEY: self.type_name(),
            ENCODING_KEY: {"data": encoding},
            "data": {REF_KEY: ref},
            **{
                to_camel_case(k): context.serialize(v)
                for k, v in self.vars().items()
            },
        }

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):

        ref = obj.pop("data").get(REF_KEY).split("#/resources/").pop(-1)
        artifact = context.artifacts[ref]

        obj.pop(TYPE_KEY, None)
        encoding: str = obj.pop(ENCODING_KEY, {}).get("data")
        index: Union[str, int] = obj.pop(NDARRAY_INDEX_KEY, None)

        if encoding == "msgpack+zlib":
            artifact = zlib.decompress(artifact)
        elif encoding == "msgpack":
            pass
        else:
            logging.error(
                f"No or wrong encoding specified for data: {encoding}"
            )

        array = unpack(artifact)

        try:
            indexed_array = (
                array[as_numpy_index(index)].squeeze()
                if index is not None
                else array
            )
        except ValueError as e:
            error_msg = (
                f"Encountered invalid index string `{index}` while trying to decode {cls}.\n"
                f"{e}"
            )
            logging.error(error_msg)
            raise ValueError(error_msg)
        except IndexError as e:
            error_msg = (
                f"Encountered invalid index `{index}` while trying to decode {cls}.\n"
                f"{e}"
            )
            logging.error(error_msg)
            raise IndexError(error_msg)

        return cls(
            indexed_array,
            **{
                to_snake_case(k): context.deserialize(v)
                for k, v in obj.items()
                if k not in ["resources"]
            },
        )

    def __eq__(self, other):
        """ Override numpy's eq function with one that is strict
            regarding the shape and data type if both objects are of type NDArray. """

        if not isinstance(other, np.ndarray):
            return False
        else:
            if tuple(self.shape) != tuple(other.shape):
                return False
            if not np.array_equal(self, other):
                return False
            if isinstance(other, BaseType) and not self.vars() == other.vars():
                return False

        # If this point is reached,
        # the values are equal, so only check class label.
        return self.get_class() == getattr(other, CLASS_KEY, None)

    def __ne__(self, other):
        return not self == other

    def __repr__(self):
        data = repr(np.asarray(self))
        attributes = ", ".join(
            [f"{k}={repr(v)}" for k, v in self.vars().items()]
        )
        separator = ", " if attributes else ""
        return f"{self.type_name()}(data={data}{separator}{attributes})"

    def to_args(self):

        # sensible default implementation for subclasses:
        # - `data` should be the first argument and should represent the np.ndarray
        # - all other constructor arguments are extracted from either the
        #   current state, i.e. using `vars`, or the argument default

        arguments = {
            name: parameter.default
            for name, parameter in inspect.signature(
                self.__new__
            ).parameters.items()
            if parameter.kind
            in (
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                inspect.Parameter.KEYWORD_ONLY,
            )
            and name is not "cls"
        }

        state = {**self.vars(), "data": np.asarray(self)}

        args = {
            name: _get_value_or_raise(state, arguments, name)
            for name in arguments.keys()
        }

        return args


def _get_value_or_raise(state: dict, defaults: dict, name: str):

    value = state.get(name, inspect.Parameter.empty)

    if value is inspect.Parameter.empty:
        value = defaults[name]

    if value is inspect.Parameter.empty:
        raise ValueError(f"No value for {name} specified.")

    return value
