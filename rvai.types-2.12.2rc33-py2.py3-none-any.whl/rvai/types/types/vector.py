from rvai.types.base_type import BaseType, record
from rvai.types.types.point import Point


@record
class Vector(BaseType):
    """Vector Data Type

    :ivar p1: a :class:`Point` object
    :type p1: Point
    :ivar p2: a :class:`Point` object
    :type p2: Point
    """

    p1: Point
    p2: Point
