from typing import Union

from rvai.types import Class, Float
from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import TYPE_KEY

TEMP_CLASS = Class(
    class_uuid="00000000-0000-0000-0000-000000000000", name="TEMP"
)


@primitive
class Label(BaseType):
    """Label Data Type

    Needs a Class object and optional score.
    """

    def __init__(
        self, class_object: Class, score: Union[Float, float, None] = None,
    ):
        score = Float(score) if score is not None else None

        self.set_class(class_object, score=score)

    @property
    def class_uuid(self):
        return self.get_class().class_uuid

    @property
    def name(self):
        return self.get_class().name

    @property
    def score(self):
        return self.get_class().get_attributes().get("score")

    @classmethod
    def _on_fake(cls, T, context):
        fake_class = Class.fake()
        ret = cls(fake_class, score=1.0)
        return ret

    def __repr__(self):
        return f"Label(class={self.get_class()}, score={self.score})"

    def __hash__(self):
        return hash(self.get_class())

    def _on_hash(self, context):
        return context.update_hash(self.get_class().hash())

    def __eq__(self, other):

        return (
            type(self) == type(other) and self.get_class() == other.get_class()
        )

    def __ne__(self, other):
        return not self.__eq__(other)

    def _on_marshall(self, context):
        return {TYPE_KEY: self.type_name()}

    @classmethod
    def _on_unmarshall(cls, context, obj, encoding):
        return cls(
            # this will be overwritten later,
            # but the constructor needs a class_object
            TEMP_CLASS
        )

    @classmethod
    def _on_json_decode(cls, context, obj, encoding):
        return cls(
            # this will be overwritten later,
            # but the constructor needs a class_object
            TEMP_CLASS
        )

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):
        return cls(
            # this will be overwritten later,
            # but the constructor needs a class_object
            TEMP_CLASS
        )
