from rvai.types.base_type import primitive
from rvai.types.types.list import List
from rvai.types.types.mask import Mask


@primitive
class Masks(List[Mask]):
    """ A List of Masks. """
