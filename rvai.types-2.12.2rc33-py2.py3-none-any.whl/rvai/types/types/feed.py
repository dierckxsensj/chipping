from rvai.types.base_type import BaseType, record
from rvai.types.types.string import String


@record
class Feed(BaseType):
    """Feed Data Type

    :ivar name: a :class:`String` object
    :type name: String
    :ivar description: a :class:`String` object
    :type description: String
    :ivar source_id: a :class:`String` object
    :type source_id: String
    :ivar path: a :class:`String` object
    :type path: String
    """

    name: String
    description: String
    source_id: String
    path: String
