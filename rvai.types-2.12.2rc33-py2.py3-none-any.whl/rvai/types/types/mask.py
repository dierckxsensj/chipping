import numpy as np

from rvai.types.base_type import primitive
from rvai.types.types.ndarray import NDArray


@primitive
class Mask(NDArray):
    def __new__(cls, data):
        """ Required for subclassing ndarray. See:
            https://www.csie.ntu.edu.tw/~azarc/sna/numpy-1.3.0/numpy/doc/subclassing.py
        """
        new_mask = np.asarray(data).astype(np.bool).view(cls)
        if len(new_mask.shape) != 2:
            raise ValueError(
                "Array passed into Mask constructor should be two dimensional!"
            )
        return new_mask

    @classmethod
    def _on_fake(cls, T, context):
        shape = context.config.get("MASK_FAKE_SHAPE", (256, 256))
        return cls(context.np.choice(a=[False, True], size=shape),)

    def __repr__(self):
        return f"Mask(data={np.asarray(self)}, class={self.get_class()})"
