from typing import Optional

from typing_extensions import Literal

from rvai.types.base_type import BaseType, record
from rvai.types.constants import CLASS_KEY, TYPE_KEY
from rvai.types.fuzzing.fake import MAX_SIZE
from rvai.types.types.integer import Integer

EXPERTISES_TYPE = Literal["basic", "advanced", "expert"]
EXPERTISES = ["basic", "advanced", "expert"]
DEFAULT_EXPERTISE = EXPERTISES[0]


@record
class Parameter(BaseType):
    """Parameter Data Type

    :ivar value: a :class:`BaseType` object
    :type value: BaseType
    :ivar name: a :class:`Optional[str]` object, defaults to None
    :type name: Optional[str]
    :ivar description: a :class:`Optional[str]` object, defaults to None
    :type description: Optional[str]
    :ivar expertise: a :class:`Optional[EXPERTISES_TYPE]` object, defaults to ""\"basic""\"
    :type expertise: Optional[EXPERTISES_TYPE]
    """

    value: BaseType
    name: Optional[str] = None
    description: Optional[str] = None
    expertise: Optional[EXPERTISES_TYPE] = "basic"
    optimizable: bool = False
    postprocessing: bool = False

    def __post_init__(self):
        if self.expertise not in EXPERTISES:
            raise ValueError(
                f"The expertise of a parameter must be one of {EXPERTISES}, not '{self.expertise}'"
            )
        self.name = str(self.name) if self.name is not None else None
        self.description = (
            str(self.description) if self.description is not None else None
        )
        self.expertise = str(self.expertise)
        self._structure = self.value.describe()

        super().__post_init__()

    def _on_fake(self, context):
        return Parameter(
            name="Some Parameter",
            value=Integer(context.np.randint(-MAX_SIZE, MAX_SIZE)),
            description="Description of some parameter...",
            expertise=DEFAULT_EXPERTISE,
        )

    def _on_marshall(self, context):
        return {
            TYPE_KEY: "Parameter",
            "value": context.serialize(self.value),
            "name": self.name,
            "description": self.description,
            "expertise": self.expertise,
            "optimizable": self.optimizable,
            "postprocessing": self.postprocessing,
            "structure": self._structure,
        }

    @classmethod
    def _on_unmarshall(cls, context, obj, encoding):
        obj.pop(TYPE_KEY)
        obj.pop("structure", None)

        value = context.deserialize(obj["value"])
        name = obj.get("name")
        description = obj.get("description")
        expertise = obj.get("expertise")
        optimizable = obj.get("optimizable")
        postprocessing = obj.get("postprocessing")

        return cls(
            value=value,
            name=name,
            description=description,
            expertise=expertise,
            optimizable=optimizable,
            postprocessing=postprocessing,
        )

    def _on_json_encode(self, context):
        return self._on_marshall(context)

    @classmethod
    def _on_json_decode(cls, context, obj, encoding):
        return cls._on_unmarshall(context, obj, encoding)

    def _on_artifacts_encode(self, context):
        return self._on_marshall(context)

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):
        return cls._on_unmarshall(context, obj, encoding)

    def __eq__(self, other):
        eq = self.value == getattr(other, "value", None)
        same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def __ne__(self, other):
        return not self.__eq__(other)

    def items(self):
        return {
            "name": self.name,
            "description": self.description,
            "value": self.value,
            "expertise": self.expertise,
            "optimizable": self.optimizable,
            "postprocessing": self.postprocessing,
        }.items()
