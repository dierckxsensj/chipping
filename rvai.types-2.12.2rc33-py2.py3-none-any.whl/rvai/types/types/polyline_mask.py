from dataclasses import field

from rvai.types.base_type import primitive
from rvai.types.types.list import List
from rvai.types.types.point_cloud_mask import PointCloudMask
from rvai.types.types.sphere import Sphere


@primitive
class PolyLineMask(PointCloudMask):
    vertices: List[Sphere] = field(default_factory=List[Sphere])

    def __init__(self, data, vertices):
        self.vertices = vertices
        super().__init__()

    def __new__(cls, data, vertices):
        return super().__new__(cls, data)

    @classmethod
    def _on_fake(cls, T, context):
        vertices = List[Sphere].fake()
        return cls(PointCloudMask._on_fake(T, context), vertices=vertices)
