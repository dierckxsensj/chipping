import json
import logging

from rvai.types.base_mutable import BaseDict
from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import TYPE_KEY
from rvai.types.sdkjson import orjson


@primitive
class JSON(BaseDict, BaseType):
    def __init__(self, *args, **kwargs):
        dict.__init__(self, *args, **kwargs)
        try:
            orjson.dumps(dict(self))
        except Exception:
            logging.exception("Invalid JSON data")
            raise ValueError(f"Invalid JSON data: {self}")

    def __hash__(self):
        return hash(json.dumps(dict(self), sort_keys=True, indent=2))

    def _on_hash(self, context):
        return context.update_hash(
            json.dumps(dict(self), sort_keys=True, indent=2).encode()
        )

    def _on_marshall(self, context):
        return {TYPE_KEY: "JSON", "value": dict(self)}

    @classmethod
    def _on_unmarshall(cls, context, obj, encoding):
        return cls(**obj["value"])

    def _on_json_encode(self, context):
        return self._on_marshall(context)

    @classmethod
    def _on_json_decode(cls, context, obj, encoding):
        return cls._on_unmarshall(context, obj, encoding)

    def _on_artifacts_encode(self, context):
        return self._on_marshall(context)

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):
        return cls._on_unmarshall(context, obj, encoding)

    def _on_fake(self, context):

        random_list = [
            context.np.randint(0, 1024)
            for _ in range(context.np.randint(0, 1024))
        ]

        return JSON({"my_key": {"my_nested_key": random_list}})

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self):
        state = (self.get_class(), self.get_attributes())
        return (self.__class__, (dict(self),), state)

    def __repr__(self):
        return f"JSON({repr(dict(self))})"
