from typing import Optional

from rvai.types.base_type import BaseType, record


@record
class Color(BaseType):
    """Color Data Type

    :ivar r: a :class:`int` object
    :type r: int
    :ivar g: a :class:`int` object
    :type g: int
    :ivar b: a :class:`int` object
    :type b: int
    :ivar a: a :class:`Optional[int]` object, defaults to (255)
    :type a: Optional[int]
    """

    r: int
    g: int
    b: int
    a: Optional[int] = 255

    def __post_init__(self):
        super().__post_init__()
        try:
            self.r = int(self.r)
        except (TypeError, ValueError):
            raise TypeError("Wrong type for red channel")
        try:
            self.g = int(self.g)
        except (TypeError, ValueError):
            raise TypeError("Wrong type for green channel")
        try:
            self.b = int(self.b)
        except (TypeError, ValueError):
            raise TypeError("Wrong type for blue channel")
        try:
            self.a = int(self.a)
        except (TypeError, ValueError):
            raise TypeError("Wrong type for alpha channel")
        if not 0 <= self.r <= 255:
            raise ValueError("Wrong value for red channel")
        if not 0 <= self.g <= 255:
            raise ValueError("Wrong value for green channel")
        if not 0 <= self.b <= 255:
            raise ValueError("Wrong value for blue channel")
        if not 0 <= self.a <= 255:
            raise ValueError("Wrong value for alpha channel")

    @classmethod
    def _on_fake(cls, T, context):
        r = context.random.randint(0, 255)
        g = context.random.randint(0, 255)
        b = context.random.randint(0, 255)
        a = context.random.randint(0, 255)
        return cls(r=r, g=g, b=b, a=a)

    def __iter__(self):
        yield self.r
        yield self.g
        yield self.b
        yield self.a

    @property
    def rgb(self):
        return self.r, self.g, self.b

    @property
    def rgba(self):
        return self.r, self.g, self.b, self.a

    @property
    def bgr(self):
        return self.b, self.g, self.r

    @property
    def bgra(self):
        return self.b, self.g, self.r, self.a

    @property
    def hex(self):
        return "#%02x%02x%02x" % self.rgb

    @property
    def hexa(self):
        return "#%02x%02x%02x%02x" % self.rgba
