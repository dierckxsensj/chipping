from typing import Optional

from rvai.types.base_numeric import BaseFloat
from rvai.types.base_type import BaseType, record
from rvai.types.constants import CLASS_KEY


@record
class FloatRange(BaseType, BaseFloat):
    """FloatRange Data Type

    :ivar value: a :class:`Optional[float]` object, defaults to None
    :type value: Optional[float]
    :ivar min: a :class:`Optional[float]` object, defaults to None
    :type min: Optional[float]
    :ivar max: a :class:`Optional[float]` object, defaults to None
    :type max: Optional[float]
    """

    value: float
    min: Optional[float] = None
    max: Optional[float] = None

    def __post_init__(self):
        self.value = float(self.value)
        if self.min is not None:
            self.min = float(self.min)
        if self.max is not None:
            self.max = float(self.max)
        if self.min is not None and self.value < self.min:
            raise ValueError(
                f"Value {self.value} is smaller than minimum {self.min}"
            )
        if self.max is not None and self.value > self.max:
            raise ValueError(
                f"Value {self.value} is greater than maximum {self.max}"
            )
        super().__post_init__()

    def __float__(self):
        return float(self.value)

    @classmethod
    def _on_fake(cls, T, context):
        fake_min = (context.random.random() - 0.5) * 100000000
        fake_max = fake_min + context.random.randint(1, 1000000)
        fake_value = (fake_min + fake_max) / 2
        return cls(value=fake_value, min=fake_min, max=fake_max)

    def __eq__(self, other):
        eq = False
        if self.value == other:
            eq = True
        same_class = True
        if isinstance(other, BaseType):
            same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def __req__(self, other):
        eq = False
        if self.value == other:
            eq = True
        same_class = True
        if isinstance(other, BaseType):
            same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def __ne__(self, other):
        neq = False
        if self.value != other:
            neq = True
        not_same_class = False
        if isinstance(other, BaseType):
            not_same_class = self.get_class() != getattr(
                other, CLASS_KEY, None
            )
        return neq or not_same_class
