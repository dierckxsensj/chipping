import numpy as np
from numpy import float32, uint8
from pypcd import pypcd

from rvai.types.base_type import BaseType, record
from rvai.types.constants import ENCODING_KEY, REF_KEY, TYPE_KEY
from rvai.types.types.ndarray import NDArray
from rvai.types.types.optional import Optional


def to_pcd(point_cloud, compression="binary"):
    num_points = point_cloud.num_points
    fields = ["points"]
    if point_cloud.colors.value is not None:
        fields.append("colors")
    if point_cloud.normals.value is not None:
        fields.append("normals")
    if num_points == 0:
        return num_points, fields, None
    points = np.array(point_cloud.points[:num_points, :], dtype=float32)
    if point_cloud.colors.value is not None:
        colors = np.array(
            point_cloud.colors.value[:num_points, :], dtype=uint8
        )
        encoded_colors = pypcd.encode_rgb_for_pcl(colors)
        points_w_colors = np.hstack((points, encoded_colors[:, np.newaxis]))
        pcd = pypcd.make_xyz_rgb_point_cloud(points_w_colors)
    else:
        pcd = pypcd.make_xyz_point_cloud(points)
    if point_cloud.normals.value is not None:
        metadata = {}
        metadata["fields"] = ["normal_x", "normal_y", "normal_z"]
        metadata["count"] = [1, 1, 1]
        metadata["size"] = [4, 4, 4]
        metadata["type"] = ["F", "F", "F"]
        normals = np.array(
            point_cloud.normals.value[:num_points, :], dtype=float32
        )
        pc_data = normals.view(
            np.dtype(
                [
                    ("normal_x", float32),
                    ("normal_y", float32),
                    ("normal_z", float32),
                ]
            )
        ).squeeze()
        pcd = pypcd.add_fields(pcd, metadata, pc_data)
    pcd_buffer = pcd.save_pcd_to_buffer(compression=compression)
    return num_points, fields, pcd_buffer


def from_pcd(pcd_buffer):
    pcd = pypcd.point_cloud_from_buffer(pcd_buffer)
    num_points = pcd.points
    points = NDArray(
        np.c_[pcd.pc_data["x"], pcd.pc_data["y"], pcd.pc_data["z"]]
    )
    if "rgb" in pcd.fields:
        colors = Optional(
            NDArray(pypcd.decode_rgb_from_pcl(pcd.pc_data["rgb"]))
        )
    else:
        colors = Optional(None)
    if (
        "normal_x" in pcd.fields
        and "normal_y" in pcd.fields
        and "normal_z" in pcd.fields
    ):
        normals = Optional(
            NDArray(
                np.c_[
                    pcd.pc_data["normal_x"],
                    pcd.pc_data["normal_y"],
                    pcd.pc_data["normal_z"],
                ]
            )
        )
    else:
        normals = Optional(None)
    return PointCloud(
        num_points=num_points, points=points, colors=colors, normals=normals
    )


@record
class PointCloud(BaseType):
    """PointCloud Data Type

    :ivar num_points: a :class:`int` object
    :type num_points: int
    :ivar points: a :class:`NDArray` object
    :type points: NDArray
    :ivar colors: a :class:`Optional[NDArray]` object
    :type colors: Optional[NDArray]
    :ivar normals: a :class:`Optional[NDArray]` object
    :type normals: Optional[NDArray]
    """

    num_points: int
    points: NDArray
    colors: Optional[NDArray] = Optional(None)
    normals: Optional[NDArray] = Optional(None)

    def __init__(
        self,
        points: NDArray,
        colors: Optional[NDArray] = Optional(None),
        normals: Optional[NDArray] = Optional(None),
        **kwargs
    ):
        self.points = points
        self.colors = colors
        self.normals = normals
        self.num_points = points.shape[0]

    @classmethod
    def _on_fake(cls, T, context):
        num_points = context.np.randint(300)
        points = NDArray(context.np.rand(num_points, 3).astype(np.float32))
        if context.np.rand() > 0.5:
            colors = Optional(
                NDArray(
                    context.np.randint(0, 255, (num_points, 3)).astype(
                        np.uint8
                    )
                )
            )
        else:
            colors = Optional()
        if context.np.rand() > 0.5:
            normals = Optional(
                NDArray(context.np.rand(num_points, 3).astype(np.float32))
            )
        else:
            normals = Optional()
        return cls(points, colors, normals)

    def _on_artifacts_encode(self, context):
        if context.config.get("3dlabeler", False):
            num_points, fields, buffer = to_pcd(self)
            if buffer is not None:
                ref = context.create_artifact("data", buffer, "pcd")
            else:
                ref = None
            ret = {
                TYPE_KEY: self.type_name(),
                ENCODING_KEY: {"data": "pcd"},
                "data": {"num_points": num_points, "fields": fields},
            }
            if ref is not None:
                ret["data"][REF_KEY] = ref
            return ret
        else:
            return None

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):
        if ENCODING_KEY in obj and obj[ENCODING_KEY]["data"] == "pcd":
            data = obj.pop("data")
            if "num_points" in data and data["num_points"] == 0:
                points = NDArray(np.zeros((0, 3), dtype=np.float32))
                colors = Optional()
                normals = Optional()
                if "fields" in data and "colors" in data["fields"]:
                    colors = Optional(
                        NDArray(np.zeros((0, 3), dtype=np.uint8))
                    )
                if "fields" in data and "normals" in data["fields"]:
                    normals = Optional(
                        NDArray(np.zeros((0, 3), dtype=np.float32))
                    )
                return cls(
                    num_points=0, points=points, colors=colors, normals=normals
                )
            else:
                ref = data.get(REF_KEY).split("#/resources/").pop(-1)
                artifact = context.artifacts[ref]
                obj.pop(TYPE_KEY, None)
                obj.pop(ENCODING_KEY, None)
                return from_pcd(artifact)
        else:
            return None
