from enum import Enum
from typing import Optional

from rvai.types.base_type import BaseType, record
from rvai.types.types.point import Point


class AnchorPoint(Enum):
    TOP_LEFT = "Top-Left"
    TOP_CENTER = "Top-Center"
    TOP_RIGHT = "Top-Right"
    MIDDLE_LEFT = "Middle-Left"
    MIDDLE_CENTER = "Middle-Center"
    MIDDLE_RIGHT = "Middle-Right"
    BOTTOM_LEFT = "Bottom-Left"
    BOTTOM_CENTER = "Bottom-Center"
    BOTTOM_RIGHT = "Bottom-Right"

    def __str__(self):
        return self.value


@record
class BoundingBox(BaseType):
    """BoundingBox Data Type

    :ivar p1: a :class:`Point` object
    :type p1: Point
    :ivar p2: a :class:`Point` object
    :type p2: Point
    :ivar score: a :class:`Optional[float]` object, defaults to (1.0)
    :type score: Optional[float]
    """

    p1: Point
    p2: Point

    # Points represent the ratio between point 1 and point 2
    #  E.g. x=0 -> p1.x, x=0.5 -> (p1.x+p2.x)/2, x=1. -> p2.x. Idem for y
    __anchor_points = {
        AnchorPoint.TOP_LEFT: Point(x=0.0, y=0.0),
        AnchorPoint.TOP_CENTER: Point(x=0.5, y=0.0),
        AnchorPoint.TOP_RIGHT: Point(x=1.0, y=0.0),
        AnchorPoint.MIDDLE_LEFT: Point(x=0.0, y=0.5),
        AnchorPoint.MIDDLE_CENTER: Point(x=0.5, y=0.5),
        AnchorPoint.MIDDLE_RIGHT: Point(x=1.0, y=0.5),
        AnchorPoint.BOTTOM_LEFT: Point(x=0.0, y=1.0),
        AnchorPoint.BOTTOM_CENTER: Point(x=0.5, y=1.0),
        AnchorPoint.BOTTOM_RIGHT: Point(x=1.0, y=1.0),
    }

    def __post_init__(self):
        p1 = Point(*self.p1) if isinstance(self.p1, tuple) else self.p1
        p2 = Point(*self.p2) if isinstance(self.p2, tuple) else self.p2
        self.p1 = Point(min(p1.x, p2.x), min(p1.y, p2.y))
        self.p2 = Point(max(p1.x, p2.x), max(p1.y, p2.y))
        super().__post_init__()

    def width(self):
        return abs(self.p1.x - self.p2.x)

    def height(self):
        return abs(self.p1.y - self.p2.y)

    def get_anchor_point(self, anchor_point: Optional[AnchorPoint]) -> Point:
        """Get the position of one of the box's anchor points.

        :param anchor_point: Requested anchor point name (Middle-Center when None).
        :type anchor_point: Optional[AnchorPoint]
        :return: The requested anchor point.
        :rtype: Point
        """
        # If no anchor point specified, use "Middle-Center" by default
        if anchor_point is None:
            anchor_point = AnchorPoint.MIDDLE_CENTER
        if anchor_point not in self.__anchor_points:
            raise ValueError(f"Invalid anchor point {anchor_point}")
        # Get the ratio point for the given anchor point
        ratio_point = self.__anchor_points[anchor_point]
        # Calculate the anchor point
        x = int((1.0 - ratio_point.x) * self.p1.x + ratio_point.x * self.p2.x)
        y = int((1.0 - ratio_point.y) * self.p1.y + ratio_point.y * self.p2.y)
        return Point(x=x, y=y)

    def __repr__(self):
        return f"BoundingBox(p1={self.p1}, p2={self.p2}, class={self.get_class()})"
