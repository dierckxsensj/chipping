from rvai.types.base_mapping import BaseMapping
from rvai.types.base_type import primitive


@primitive
class Outputs(BaseMapping):
    def __repr__(self):
        entries = ", ".join(f'"{str(k)}": {repr(v)}' for k, v in self.items())
        return f"Outputs(entries={{{entries}}})"
