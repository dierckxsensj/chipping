import json
from collections import defaultdict
from typing import Dict, Optional, Tuple, Union
from uuid import uuid4

from rvai.types import Class
from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import TYPE_KEY


@primitive
class ConfusionMatrix(BaseType):
    scores: Dict[Tuple[Optional[Class], Optional[Class]], Union[int, float]]

    def __init__(
        self,
        scores: Optional[
            Dict[Tuple[Optional[Class], Optional[Class]], Union[int, float]]
        ] = None,
    ):
        self.scores = defaultdict(self._default_score)
        if scores is not None:
            self.scores.update(scores)

    @staticmethod
    def _default_score():
        # necessary to allow pickling
        return 0

    def _on_marshall(self, context):
        as_dict = {}
        for (annot_a, annot_b), score in self.scores.items():
            annot_a_key = annot_a.class_uuid if annot_a is not None else "null"
            annot_b_key = annot_b.class_uuid if annot_b is not None else "null"

            if annot_a_key not in as_dict:
                as_dict[annot_a_key] = {}

            as_dict[annot_a_key][annot_b_key] = score

        return {
            TYPE_KEY: self.type_name(),
            "scores": as_dict,
        }

    def _get_keys(self):
        return [(k[0].class_uuid, k[1].class_uuid) for k in self.scores.keys()]

    @classmethod
    def _on_unmarshall(cls, context, obj, encoding):
        scores = defaultdict(cls._default_score)
        for class_a_id, nested in obj["scores"].items():
            for class_b_id, score in nested.items():
                class_a = Class(class_a_id) if class_a_id != "null" else None
                class_b = Class(class_b_id) if class_b_id != "null" else None
                scores[(class_a, class_b)] = score
        return cls(scores)

    def _on_json_encode(self, context):
        return self._on_marshall(context)

    @classmethod
    def _on_json_decode(cls, context, obj, encoding):
        return cls._on_unmarshall(context, obj, encoding)

    def _on_artifacts_encode(self, context):
        return self._on_marshall(context)

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):
        return cls._on_unmarshall(context, obj, encoding)

    def _on_hash(self, context):
        context.update_hash(
            json.dumps(self.to_json_struct(), sort_keys=True, indent=2)
        )

    def __hash__(self):
        return hash(
            json.dumps(self.to_json_struct(), sort_keys=True, indent=2)
        )

    def __eq__(self, other):
        if not isinstance(other, ConfusionMatrix):
            return False

        if set(self._get_keys()) != set(other._get_keys()):
            return False

        for key, val in self.scores.items():
            if other.scores[key] != val:
                return False

        return self.get_class() == other.get_class()

    def __repr__(self):
        return f"{self.type_name()}({self.marshall()['scores']})"

    @classmethod
    def _on_fake(cls, T, context):
        res = cls()
        classes = [Class(str(uuid4())) for _ in range(3)]
        for class_a in classes:
            for class_b in classes:
                res.scores[(class_a, class_b)] = context.random.randint(0, 255)
        return res
