from rvai.types.base_type import BaseType, record
from rvai.types.types.camera_array_parameters import CameraArrayParameters
from rvai.types.types.ndarray import NDArray
from rvai.types.types.optional import Optional


@record
class WorkingVolumeParameters(BaseType):
    """WorkingVolumeParameters Data Type

    :ivar voxel_size: a :class:`float` object
    :type voxel_size: float
    :ivar extra_planes: a :class:`Optional[NDArray]` object
    :type extra_planes: Optional[NDArray]
    :ivar aligning_axis: a :class:`Optional[NDArray]` object
    :type aligning_axis: Optional[NDArray]
    :ivar all_camera_parameters: a :class:`CameraArrayParameters` object
    :type all_camera_parameters: CameraArrayParameters
    """

    voxel_size: float
    extra_planes: Optional[NDArray]
    aligning_axis: Optional[NDArray]
    all_camera_parameters: CameraArrayParameters
