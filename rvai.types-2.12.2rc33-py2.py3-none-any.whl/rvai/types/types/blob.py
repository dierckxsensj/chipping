from rvai.types.base_type import BaseType, record
from rvai.types.types.bytes import Bytes
from rvai.types.types.json import JSON
from rvai.types.types.optional import Optional


@record
class Blob(BaseType):
    """Blob Data Type

    :ivar data: a :class:`Bytes` object
    :type data: Bytes
    :ivar metadata: a :class:`Optional[JSON]` object
    :type metadata: Optional[JSON]
    """

    data: Bytes
    metadata: Optional[JSON]
