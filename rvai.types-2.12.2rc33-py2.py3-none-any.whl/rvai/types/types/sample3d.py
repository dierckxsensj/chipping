from rvai.types.base_type import BaseType, record
from rvai.types.types.point_cloud import PointCloud


@record
class Sample3D(BaseType):
    """Sample3D Data Type

    :ivar point_cloud: a :class:`PointCloud` object
    :type point_cloud: PointCloud
    """

    point_cloud: PointCloud

    def _on_artifacts_encode(self, context):
        context.config["3dlabeler"] = True
        return None
