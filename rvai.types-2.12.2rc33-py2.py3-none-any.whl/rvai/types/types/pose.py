import typing
from dataclasses import field
from typing import Generic, Optional, TypeVar

import cv2

from rvai.types.base_type import BaseType, primitive, record
from rvai.types.constants import CLASS_KEY
from rvai.types.meta_type import GenericMetaType
from rvai.types.types.bounding_box import BoundingBox
from rvai.types.types.class_ import Class
from rvai.types.types.float import Float
from rvai.types.types.image import Image
from rvai.types.types.integer import Integer
from rvai.types.types.list import List
from rvai.types.types.point import Point
from rvai.types.types.string import String
from rvai.types.types.vector import Vector
from rvai.types.utils import TypeFactory, _get_parameter_types
from rvai.types.visit import reset_chain, update_chain


def _wrap_labels(labels: typing.List[str]) -> List[String]:
    return List(*map(String, labels))


def _wrap_connections(
    connections: typing.List[typing.Tuple[int, int]]
) -> List[List[Integer]]:
    return List(
        [
            List(Integer(origin), Integer(target))
            for (origin, target) in connections
        ]
    )


def _averaging_point_attributes(point1, point2):
    p1_attr = point1.get_attributes()
    p2_attr = point2.get_attributes()
    p3_attr = None
    if (p1_attr is not None) and (p2_attr is not None):
        p3_attr = {}
        for attribute in set(p1_attr.keys()).intersection(set(p2_attr.keys())):
            p1_value = p1_attr[attribute]
            p2_value = p2_attr[attribute]
            if isinstance(p1_value, Float) and isinstance(p2_value, Float):
                p3_attr[attribute] = Float((p1_value + p2_value) / 2)
    return p3_attr


@record
class Skeleton(BaseType):
    key_points: List[Point]
    num_key_points: Integer
    key_point_connections: List[List[Integer]]
    key_point_labels: Optional[List[String]]

    def __post_init__(self):
        if isinstance(self.key_points, list):
            self.key_points = List(self.key_points)
        if isinstance(self.num_key_points, int):
            self.num_key_points = Integer(self.num_key_points)

    def get_order(self):
        return [
            (index, key_point)
            for index, key_point in enumerate(self.key_point_labels)
        ]

    def get_connection_vectors(self):
        return [
            Vector(self.key_points[index1], self.key_points[index2])
            for index1, index2 in self.key_point_connections
        ]

    @property
    def total_score(self):
        if self.num_key_points == 0:
            return None
        total_score = 0
        for kp in self.key_points:
            kp_attr = kp.get_attributes()
            if kp_attr is not None:
                if "score" in kp_attr:
                    total_score += kp_attr["score"]
        return total_score / self.num_key_points


COCO_17_LABELS = [
    "nose",
    "left_eye",
    "right_eye",
    "left_ear",
    "right_ear",
    "left_shoulder",
    "right_shoulder",
    "left_elbow",
    "right_elbow",
    "left_hand",
    "right_hand",
    "left_hip",
    "right_hip",
    "left_knee",
    "right_knee",
    "left_foot",
    "right_foot",
]

COCO_17_CONNECTIONS = [
    (0, 1),
    (0, 2),
    (1, 3),
    (2, 4),
    (3, 5),
    (4, 6),
    (5, 6),
    (5, 7),
    (5, 11),
    (6, 8),
    (6, 12),
    (7, 9),
    (8, 10),
    (11, 12),
    (11, 13),
    (12, 14),
    (13, 15),
    (14, 16),
]


@record
class Coco17Skeleton(Skeleton):
    key_point_labels: List[String] = field(
        default_factory=lambda: _wrap_labels(COCO_17_LABELS)
    )
    key_point_connections: List[List[Integer]] = field(
        default_factory=lambda: _wrap_connections(COCO_17_CONNECTIONS)
    )
    num_key_points: Integer = Integer(17)

    @classmethod
    def _on_fake(cls, T, context):
        kp = List([Point.fake() for _ in range(17)])
        return Coco17Skeleton(kp)

    def to_coco17(self):
        return self

    def to_coco18(self):
        ls_x, ls_y = self.key_points[5].xy
        rs_x, rs_y = self.key_points[6].xy

        neck = type(self.key_points[0])((ls_x + rs_x) / 2, (ls_y + rs_y) / 2)
        neck.set_class(Class(class_uuid=17, name="neck"))
        neck.set_attributes(
            _averaging_point_attributes(self.key_points[5], self.key_points[6])
        )

        reorder = [0, 6, 8, 10, 5, 7, 9, 12, 14, 16, 11, 13, 15, 2, 1, 4, 3]
        new_key_points = [self.key_points[index] for index in reorder]
        new_key_points.insert(1, neck)

        return Coco18Skeleton(new_key_points)

    def to_mpii(self):
        return self.to_coco18().to_mpii()


COCO_18_LABELS = [
    "nose",
    "neck",
    "right_shoulder",
    "right_elbow",
    "right_hand",
    "left_shoulder",
    "left_elbow",
    "left_hand",
    "right_hip",
    "right_knee",
    "right_foot",
    "left_hip",
    "left_knee",
    "left_foot",
    "right_eye",
    "left_eye",
    "right_ear",
    "left_ear",
]

COCO_18_CONNECTIONS = [
    (0, 1),
    (0, 14),
    (0, 15),
    (0, 1),
    (1, 2),
    (1, 5),
    (1, 8),
    (1, 11),
    (2, 3),
    (3, 4),
    (5, 6),
    (6, 7),
    (8, 9),
    (9, 10),
    (11, 12),
    (12, 13),
    (14, 16),
    (15, 17),
]


@record
class Coco18Skeleton(Skeleton):
    key_point_labels: List[String] = field(
        default_factory=lambda: _wrap_labels(COCO_18_LABELS)
    )
    key_point_connections: List[List[Integer]] = field(
        default_factory=lambda: _wrap_connections(COCO_18_CONNECTIONS)
    )
    num_key_points: Integer = Integer(18)

    @classmethod
    def _on_fake(cls, T, context):
        kp = List([Point.fake() for _ in range(18)])
        return Coco18Skeleton(kp)

    def to_coco17(self):
        reorder = [0, 15, 14, 17, 16, 5, 2, 6, 3, 7, 4, 11, 8, 12, 9, 13, 10]
        new_key_points = [self.key_points[index] for index in reorder]
        return Coco17Skeleton(new_key_points)

    def to_coco18(self):
        return self

    def to_mpii(self):
        rh_x, rh_y = self.key_points[8].xy
        lh_x, lh_y = self.key_points[11].xy
        pelvis = type(self.key_points[0])((rh_x + lh_x) / 2, (rh_y + lh_y) / 2)
        pelvis.set_class(Class(class_uuid=18, name="pelvis"))
        pelvis.set_attributes(
            _averaging_point_attributes(
                self.key_points[8], self.key_points[11]
            )
        )

        n_x, n_y = self.key_points[0].xy
        t_x, t_y = self.key_points[1].xy
        upper_neck = type(self.key_points[0])(
            (n_x + t_x * 4) / 5, (n_y + t_y * 4) / 5
        )
        upper_neck.set_class(Class(class_uuid=19, name="upper_neck"))
        upper_neck.set_attributes(
            _averaging_point_attributes(self.key_points[0], self.key_points[1])
        )

        reorder = [10, 9, 8, 11, 12, 13, 1, 0, 4, 3, 2, 5, 6, 7]
        new_key_points = [self.key_points[index] for index in reorder]
        new_key_points.insert(6, pelvis)
        new_key_points.insert(8, upper_neck)
        return MPIISkeleton(new_key_points)


MPII_LABELS = [
    "right_foot",
    "right_knee",
    "right_hip",
    "left_hip",
    "left_knee",
    "left_foot",
    "pelvis",
    "thorax",
    "upper_neck",
    "top_head",
    "right_hand",
    "right_elbow",
    "right_shoulder",
    "left_shoulder",
    "left_elbow",
    "left_hand",
]

MPII_CONNECTIONS = [
    (0, 1),
    (1, 2),
    (2, 6),
    (3, 4),
    (3, 6),
    (4, 5),
    (6, 7),
    (7, 8),
    (7, 12),
    (7, 13),
    (8, 9),
    (10, 11),
    (11, 12),
    (13, 14),
    (14, 15),
]


@record
class MPIISkeleton(Skeleton):
    key_point_labels: List[String] = field(
        default_factory=lambda: _wrap_labels(MPII_LABELS)
    )
    key_point_connections: List[List[Integer]] = field(
        default_factory=lambda: _wrap_connections(MPII_CONNECTIONS)
    )
    num_key_points: Integer = Integer(16)

    @classmethod
    def _on_fake(cls, T, context):
        kp = List([Point.fake() for _ in range(16)])
        return MPIISkeleton(kp)

    def to_coco17(self):
        n_x, n_y = self.key_points[8].xy
        th_x, th_y = self.key_points[9].xy
        middle_of_head = type(self.key_points[0])(
            (n_x + th_x) / 2, (n_y + th_y) / 2
        )
        middle_of_head.set_class(Class(class_uuid=16, name="middle_of_head"))
        middle_of_head.set_attributes(
            _averaging_point_attributes(self.key_points[8], self.key_points[9])
        )

        reorder = [13, 12, 14, 11, 15, 10, 3, 2, 4, 1, 5, 0]
        new_key_points = [self.key_points[index] for index in reorder]
        for _ in range(5):
            new_key_points.insert(0, middle_of_head)

        return Coco17Skeleton(new_key_points)

    def to_coco18(self):
        return self.to_coco17().to_coco18()

    def to_mpii(self):
        return self


SUPPORTED_POSES = [Coco17Skeleton, Coco18Skeleton, MPIISkeleton]

# The Skeleton type is not supported but needed until Union is supported in typechecks
T = TypeVar("T", Coco17Skeleton, Coco18Skeleton, MPIISkeleton, Skeleton)


@primitive
class Pose(BaseType, Generic[T], metaclass=GenericMetaType):

    value: Optional[T] = None
    bounding_box: Optional[BoundingBox] = None

    def __init__(
        self,
        value: Optional[T] = None,
        bounding_box: Optional[BoundingBox] = None,
    ):
        self.bounding_box = bounding_box
        if value is not None:
            if not any(isinstance(value, sp) for sp in SUPPORTED_POSES):
                raise ValueError(
                    f"Invalid pose, expected a pose of type {SUPPORTED_POSES}"
                )
        self.value = value

    def __hash__(self):
        return hash(frozenset((self.value, self.bounding_box)))

    def __repr__(self):
        return f"{self.full_type_name()}(value={repr(self.value)}, bounding_box={repr(self.bounding_box)})"

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self):
        T = TypeFactory(self.full_type_name())
        args = (
            self.value,
            self.bounding_box,
        )
        state = (self.get_class(), self.get_attributes())
        return (T, args, state)

    def __eq__(self, other):
        eq = False
        if type(self) == type(other):
            eq = self.value == other.value
            eq &= self.bounding_box == other.bounding_box
        elif type(self.value) == type(other):
            eq = self.value == other
        same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def show(self, image: Image):
        if self.value is not None:
            tmp_img = image.copy()
            skeleton = self.value
            for connection in skeleton.get_connection_vectors():
                cv2.line(
                    tmp_img,
                    connection.p1.xyi,
                    connection.p2.xyi,
                    (255, 0, 0),
                    2,
                )
            if self.bounding_box is not None:
                box = self.bounding_box
                Image(
                    tmp_img[
                        box.p1.xyi[1] : box.p2.xyi[1],
                        box.p1.xyi[0] : box.p2.xyi[0],
                        :,
                    ]
                ).show()
            else:
                tmp_img.show()
        return self

    @classmethod
    def visit_type(cls, context, apply_function, visit_function):
        T, *_ = _get_parameter_types(cls)
        return apply_function(
            cls,
            context,
            {
                "value": visit_function(T, context),
                "bounding_box": visit_function(BoundingBox, context),
            },
        )

    def visit_type_instance(self, context, apply_function, visit_function):
        with reset_chain(context):
            ret = apply_function(
                self,
                context,
                {
                    "value": visit_function(
                        self.value, update_chain(context, "value")
                    ),
                    "bounding_box": visit_function(
                        self.bounding_box,
                        update_chain(context, "bounding_box"),
                    ),
                },
            )
        return ret
