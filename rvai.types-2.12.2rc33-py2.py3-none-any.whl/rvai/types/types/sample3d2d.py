from rvai.types.base_type import record
from rvai.types.types.image_set import ImageSet
from rvai.types.types.sample3d import Sample3D
from rvai.types.types.working_volume_parameters import WorkingVolumeParameters


@record
class Sample3D2D(Sample3D):
    """Sample3D2D Data Type

    :ivar point_cloud: a :class:`PointCloud` object
    :type point_cloud: PointCloud
    :ivar image_set: a :class:`ImageSet` object
    :type image_set: ImageSet
    :ivar working_volume_parameters: a :class:`WorkingVolumeParameters` object
    :type working_volume_parameters: WorkingVolumeParameters
    """

    image_set: ImageSet
    working_volume_parameters: WorkingVolumeParameters
