import string
from enum import Enum
from typing import Any, Dict, Optional, Union

from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import TYPE_KEY


@primitive
class LocalizedString(BaseType, str):
    class Lang(Enum):
        ENG = "English"
        NLD = "Dutch, Flemish"
        FRA = "French"
        DEU = "German"
        SPA = "Castilian, Spanish"
        JPN = "Japanese"

    id: str
    translations: Dict[str, str]
    args: Dict[str, str]

    def __new__(cls, id, translations, *args, **kwargs):
        if (
            cls.Lang.ENG not in translations
            and cls.Lang.ENG.name.lower() not in translations
        ):
            raise ValueError(f"Missing translation for message `{id}`")
        message = translations.get(
            cls.Lang.ENG, translations.get(cls.Lang.ENG.name.lower())
        )
        return super().__new__(cls, message)

    def __init__(
        self,
        id: str,
        translations: Union[Dict[str, str], Dict[Lang, str]],
        args: Optional[Dict[str, Any]] = None,
    ):
        self.id = id
        self.translations = {
            lang.name.lower()
            if isinstance(lang, self.Lang)
            else lang.lower(): message
            for lang, message in translations.items()
        }
        self.args = args if args is not None else {}

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self):
        state = (self.get_class(), self.get_attributes())
        return (type(self), (self.id, self.translations, self.args,), state)

    def _on_hash(self, context):
        return context.update_hash((str(self) + str(vars(self))).encode())

    @classmethod
    def _on_fake(cls, T, context):
        def randstr():
            return "".join(
                context.random.choice(string.ascii_uppercase + string.digits)
                for _ in range(context.random.randint(1, 100))
            )

        return cls(
            id=randstr(),
            translations={cls.Lang.ENG: randstr(), cls.Lang.NLD: randstr()},
            args={"arg1": randstr(), "arg2": randstr()},
        )

    def _on_marshall(self, context):
        return {
            TYPE_KEY: self.type_name(),
            "id": self.id,
            "translations": self.translations,
            "args": self.args,
        }

    def __hash__(self):
        return hash(str(self) + str(vars(self)))

    def __repr__(self):
        return (
            f'LocalizedString(value="{str(self)}",'
            f'{",".join(f"{k}={v}" for k, v in vars(self).items())})'
        )

    def get_message(self, lang: Union[str, "Lang"] = Lang.ENG) -> str:
        if isinstance(lang, self.Lang):
            lang_ = lang.name.lower()
        else:
            lang_ = lang.lower()
        return self.translations.get(lang_, str(self))

    @property
    def messages(self) -> Dict[str, str]:
        """Get i18n messages in all supported languages."""
        return self.translations

    @property
    def message(self) -> str:
        """Get i18n message in default language."""
        return self.get_message()
