from numpy import float64

from rvai.types.base_type import BaseType, record
from rvai.types.types.point3d import Point3D


@record
class Sphere(BaseType):
    """Sphere Data Type

    :ivar center: a :class:`Point3D` object
    :type center: Point3D
    :ivar radius: a :class:`float64` object
    :type radius: float64
    """

    center: Point3D
    radius: float64

    @classmethod
    def _on_fake(cls, T, context):
        return cls(center=Point3D(0, 0, 0), radius=context.np.rand(),)
