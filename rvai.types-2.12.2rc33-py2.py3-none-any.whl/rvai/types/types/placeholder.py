class Placeholder:
    def __init__(self, location=None):
        self.location = location
