from typing import Dict, Tuple

from rvai.types import Class
from rvai.types.base_type import primitive
from rvai.types.types.list import List, parse_args_items


@primitive
class Classes(List[Class]):
    """Class Data Type

    :ivar sorting: if True, will use sorting based on UUID when creating
    the mapping between class and index
    :type sorting: bool
    """

    sorting: bool = True

    def __init__(self, *args, items=None, sorting: bool = True):
        self.sorting = sorting
        items = parse_args_items(args, items)
        list.__init__(self, items)

    def class_index_mapping(self, start: int = 0) -> Tuple[Dict, Dict]:
        class_to_index_mapping: Dict = {}
        index_to_class_mapping: Dict = {}
        current_index = start
        class_objects = self.sorted_by_uuid() if self.sorting else self
        for class_object in class_objects:
            class_to_index_mapping[class_object] = current_index
            index_to_class_mapping[current_index] = class_object
            current_index += 1
        return class_to_index_mapping, index_to_class_mapping

    def _on_fake(self, context):
        return Classes(List(Class.fake()))

    def sorted_by_uuid(self):
        return Classes(sorted(self, key=lambda item: item.class_uuid))

    def __repr__(self):
        return f"Classes(items={list(self)}, sorting={self.sorting})"

    def __hash__(self):
        return hash(frozenset(list(self)))
