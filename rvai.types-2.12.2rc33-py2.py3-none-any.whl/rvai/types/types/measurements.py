from datetime import datetime
from typing import Optional

from rvai.types.base_mapping import BaseMapping
from rvai.types.base_type import BaseType, primitive, record
from rvai.types.types.list import List
from rvai.types.types.string import String

...


@primitive
class Tags(BaseMapping):
    def __init__(self, entries=None, **kwargs):
        tags = entries or kwargs
        for name, value in tags.items():
            if not isinstance(value, BaseType):
                raise ValueError(
                    f"{type(value)} not a valid type for tag `{name}`"
                )
        super().__init__(**tags)

    def __repr__(self):
        entries = ", ".join(f'"{str(k)}": {repr(v)}' for k, v in self.items())
        return f"Tags(entries={{{entries}}})"


@primitive
class Fields(BaseMapping):
    def __init__(self, entries=None, **kwargs):
        fields = entries or kwargs
        for name, value in fields.items():
            if not isinstance(value, BaseType):
                raise ValueError(
                    f"{type(value)} not a valid type for field `{name}`"
                )
        super().__init__(**fields)

    def __repr__(self):
        entries = ", ".join(f'"{str(k)}": {repr(v)}' for k, v in self.items())
        return f"Fields(entries={{{entries}}})"


@record
class Measurement(BaseType):
    """Measurement Data Type

    :ivar name: a :class:`str` object
    :type name: str
    :ivar fields: a :class:`Fields` object
    :type fields: Fields
    :ivar tags: a :class:`Optional[Tags]` object, defaults to None
    :type tags: Optional[Tags]
    :ivar timestamp: a :class:`Optional[str]` object, defaults to None
    :type timestamp: Optional[str]
    """

    name: str
    fields: Fields
    tags: Optional[Tags] = None
    timestamp: Optional[str] = None

    def __post_init__(self):
        self.timestamp = self.timestamp or datetime.utcnow().isoformat()
        super().__post_init__()


@record
class TagDefinition(BaseType):
    """TagDefinition Data Type

    :ivar name: a :class:`str` object
    :type name: str
    :ivar type: a :class:`str` object, defaults to ""\"String""\"
    :type type: str
    :ivar label: a :class:`Optional[str]` object, defaults to None
    :type label: Optional[str]
    :ivar options: a :class:`Optional[List[String]]` object, defaults to None
    :type options: Optional[List[String]]
    """

    name: str
    type: str = "String"
    label: Optional[str] = None
    options: Optional[List[String]] = None

    def __post_init__(self):
        self.label = self.label or self.name
        super().__post_init__()


@record
class FieldDefinition(BaseType):
    """FieldDefinition Data Type

    :ivar name: a :class:`str` object
    :type name: str
    :ivar type: a :class:`str` object
    :type type: str
    :ivar label: a :class:`Optional[str]` object, defaults to None
    :type label: Optional[str]
    """

    name: str
    type: str
    label: Optional[str] = None

    def __post_init__(self):
        self.label = self.label or self.name
        super().__post_init__()


@record
class MeasurementDefinition(BaseType):
    """MeasurementDefinition Data Type

    :ivar name: a :class:`str` object
    :type name: str
    :ivar fields: a :class:`List[FieldDefinition]` object
    :type fields: List[FieldDefinition]
    :ivar label: a :class:`Optional[str]` object, defaults to None
    :type label: Optional[str]
    :ivar tags: a :class:`Optional[List[TagDefinition]]` object, defaults to None
    :type tags: Optional[List[TagDefinition]]
    """

    name: str
    fields: List[FieldDefinition]
    label: Optional[str] = None
    tags: Optional[List[TagDefinition]] = None

    def __post_init__(self):
        self.label = self.label or self.name
        super().__post_init__()

    def validate_measurement(self, measurement: Measurement):
        """
        Validate if a measurement is valid according to
        this measurement definition.
        """
        if measurement.name != self.name:
            raise ValueError("Measurement name mismatch")
        if measurement.tags:
            if not self.tags:
                raise ValueError(f"Tags not defined for {self.name}")
            for m_tag, m_tag_value in measurement.tags.items():
                matched_tag = next(
                    (t for t in self.tags if t.name == m_tag), None
                )
                if matched_tag is None:
                    raise ValueError(
                        f"Tag `{m_tag}` not defined for {self.name}"
                    )
                if m_tag_value.type_name() != matched_tag.type:
                    raise ValueError(
                        f"Tag `{m_tag}` is a `{matched_tag.type}` but got a `{m_tag_value.type_name()}`"
                    )
        for m_field, m_field_value in measurement.fields.items():
            matched_field = next(
                (f for f in self.fields if f.name == m_field), None
            )
            if matched_field is None:
                raise ValueError(
                    f"Field `{m_field}` not defined for {self.name}"
                )
            if m_field_value.type_name() != matched_field.type:
                raise ValueError(
                    f"Field `{m_field}` is a `{matched_field.type}` but got a `{m_field_value.type_name()}`"
                )
