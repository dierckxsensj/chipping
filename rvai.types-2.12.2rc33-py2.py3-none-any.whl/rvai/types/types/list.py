import inspect
from typing import List as TypingList, Type, TypeVar

from rvai.types.base_mutable import BaseList
from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import CLASS_KEY
from rvai.types.inspect import get_parameters
from rvai.types.meta_type import GenericMetaType
from rvai.types.utils import TypeFactory, _get_parameter_types
from rvai.types.visit import reset_chain, update_chain

T = TypeVar("T")


def parse_args_items(args, items=None):
    if items is None and len(args) == 1:
        if isinstance(args[0], (tuple, list, List)):
            items = args[0]
        elif inspect.isgenerator(args[0]):
            items = list(args[0])
        else:
            items = args
    elif items is None and len(args) > 1:
        items = args
    elif items is None:
        items = []
    return items


@primitive
class List(BaseList, BaseType, TypingList[T], metaclass=GenericMetaType):  # type: ignore
    def __init__(self, *args, items=None):
        items = parse_args_items(args, items)
        list.__init__(self, items)

    def __eq__(self, other):
        eq = super().__eq__(other)
        same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(frozenset(list(self)))

    def __setstate__(self, state):
        class_, attributes, params = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)
        for attr_name, attr_value in params.items():
            setattr(self, attr_name, attr_value)

    def __reduce__(self):
        T = TypeFactory(self.full_type_name())
        args = (list(self),)
        params = {}
        annotations = getattr(self, "__annotations__", {})
        for attr_name, attr_type in annotations.items():
            attr_val = getattr(self, attr_name)
            params[attr_name] = attr_val
        state = (self.get_class(), self.get_attributes(), params)
        return T, args, state

    def __repr__(self):
        return f"{self.full_type_name()}(items=[{', '.join(repr(v) for v in self)}])"

    def __getitem__(self, item):
        if isinstance(item, slice):
            return List(super().__getitem__(item))
        else:
            return super().__getitem__(item)

    @classmethod
    def visit_type(cls, context, apply_function, visit_function):

        T, *_ = _get_parameter_types(cls)

        amount = context.config.get("VISIT_TYPE_LIST_AMOUNT", 10)
        return apply_function(
            cls,
            context,
            {"items": [visit_function(T, context) for _ in range(amount)]},
        )

    def visit_type_instance(self, context, apply_function, visit_function):
        def visit_item(index, item, context):
            with reset_chain(context):
                ret = visit_function(
                    item, update_chain(context, f"items.{index}")
                )
            return ret

        return apply_function(
            self,
            context,
            {
                "items": [
                    visit_item(index, item, context)
                    for index, item in enumerate(self)
                ]
            },
        )

    @classmethod
    def configure(cls: "Type[List]", obj) -> "Type[List[T]]":

        item = next(iter(obj["items"]), None)

        if get_parameters(cls) and item is not None:
            item_type = item.full_type()
            return cls[item_type]  # type: ignore

        else:
            return cls
