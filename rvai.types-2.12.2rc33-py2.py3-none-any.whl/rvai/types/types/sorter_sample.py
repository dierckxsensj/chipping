from typing import Optional

import numpy as np

from rvai.types.base_type import record
from rvai.types.types.list import List
from rvai.types.types.mask import Mask
from rvai.types.types.ndarray import NDArray
from rvai.types.types.point3d import Point3D
from rvai.types.types.rigid_transformation_3d import RigidTransformation3D
from rvai.types.types.sample3d2d import Sample3D2D
from rvai.types.types.shape import Shape
from rvai.types.types.timestamp import Timestamp


@record
class SorterSample(Sample3D2D):
    T_global_to_voxels: RigidTransformation3D
    grid_shape: Shape
    foreground_masks: List[Mask]
    backgrounds_timestamp: Timestamp
    volume_boundaries: Point3D
    plug_diameter: int
    plug_height: int
    cone_angle: float

    @property
    def timestamp(self) -> Optional[Timestamp]:
        return self.image_set.timestamp

    def _on_artifacts_encode(self, context):
        context.config["bgr"] = True
        context.config["3dlabeler"] = True
        return None

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):
        context.config["bgr"] = True
        return None

    @property
    def occupancy_grid(self) -> NDArray:
        pc_vx = np.around(
            self.point_cloud.points @ self.T_global_to_voxels.R.T
            + self.T_global_to_voxels.t.T
        ).astype(int)
        occupancy_grid = NDArray(np.zeros(self.grid_shape, dtype=np.bool))
        for idx in range(self.point_cloud.num_points):
            occupancy_grid[pc_vx[idx, 0], pc_vx[idx, 1], pc_vx[idx, 2]] = True
        return occupancy_grid
