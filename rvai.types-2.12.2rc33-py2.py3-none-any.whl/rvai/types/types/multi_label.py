from rvai.types import Class, Label
from rvai.types.base_type import primitive


@primitive
class MultiLabel(Label):
    def __init__(
        self, class_object: Class, score: float = 1.0,
    ):
        super().__init__(class_object, score=score)

    def __repr__(self):
        return f"MultiLabel(class={self.get_class()}, score={self.score})"
