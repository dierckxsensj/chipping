import numpy as np

from rvai.types.base_type import BaseType, primitive, record
from rvai.types.constants import TYPE_KEY
from rvai.types.types.boolean import Boolean
from rvai.types.types.feature_point import FeaturePoint
from rvai.types.types.float import Float
from rvai.types.types.image import Image
from rvai.types.types.integer import Integer
from rvai.types.types.list import List
from rvai.types.types.ndarray import NDArray
from rvai.types.types.point import Point


@record
class FeatureImageParameters(BaseType):
    """The parameters that control the creation of a :class:`FeatureImage`"""

    offset_step: Float
    border: Float
    extra_border: Integer
    threshold: Float
    multi: Float
    min_plant_size: Float
    zoom_factor: Float
    erode_plants: Float
    small_circ: Float
    big_circ: Float
    small_strip_length: Float
    big_root: Boolean
    max_plant_size: Float


@primitive
class FeatureImage(Image):
    """An image with a list of :class:`FeaturePoint` objects
    representing calculated features at locations in the image

    :ivar feature_points: A :class:`List` with the features of the image
    :type feature_points: List[FeaturePoint]
    :ivar parameters: The parameters that were used to create this
        :class:`FeatureImage`
    :type parameters: FeatureImageParameters
    """

    feature_points: List[FeaturePoint]
    parameters: FeatureImageParameters

    def __init__(self, data, feature_points, parameters):
        self.feature_points = feature_points
        self.parameters = parameters
        super().__init__()

    def __new__(cls, data, feature_points, parameters):
        return super().__new__(cls, data)

    @property
    def features(self) -> NDArray:
        if len(self.feature_points) != 0:
            return NDArray(
                np.stack(
                    [point.features for point in self.feature_points], axis=0,
                )
            )
        else:
            return NDArray([])

    @property
    def points(self) -> List[Point]:
        result: List[Point] = List()
        for point in self.feature_points:
            newpoint = point.deepcopy()
            # Dirty downcast
            newpoint.__class__ = Point
            delattr(newpoint, "features")
            result.append(newpoint)
        return result

    def _on_artifacts_encode(self, context):
        base = context.serialize(Image(self.data))
        base[TYPE_KEY] = self.type_name()
        base["features"] = context.serialize(self.features)
        base["points"] = context.serialize(self.points)
        base["parameters"] = context.serialize(self.parameters)
        return base

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):
        features = context.deserialize(obj.pop("features"))
        points = context.deserialize(obj.pop("points"))
        parameters = context.deserialize(obj.pop("parameters"))
        obj[TYPE_KEY] = "Image"
        img = context.deserialize(obj)
        for point, feature_vector in zip(points, features):
            # Dirty upcast
            point.__class__ = FeaturePoint
            point.features = feature_vector

        return FeatureImage(img.data, points, parameters)
