import string
from typing import Optional, Union
from uuid import uuid4

from rvai.types.base_type import BaseType, record
from rvai.types.types.float import Float


@record(unsafe_hash=False)
class Class(BaseType):
    """Class Data Type

    :ivar class_uuid: a :class:`str` object
    :type class_uuid: str
    :ivar name: a :class:`Optional[str]` object, defaults to None
    :type name: Optional[str]
    """

    class_uuid: str
    name: Optional[str] = None

    def __init__(
        self, class_uuid: str, name: Optional[str] = None,
    ):
        self.class_uuid = str(class_uuid)
        self.name = name

    def _on_fake(cls, context):

        randstr = "".join(
            context.random.choice(string.ascii_uppercase + string.digits)
            for _ in range(context.random.randint(1, 20))
        )

        return cls(class_uuid=str(uuid4()), name=randstr)

    # Overwrite function from BaseType
    # since Class shouldn't have a Class attribute
    def set_class(
        self,
        class_object,
        score: Optional[Union[Float, float]] = None,
        **kwargs,
    ):
        self.class_uuid = str(class_object.class_uuid)
        self.name = class_object.name

        if score is not None:
            kwargs["score"] = Float(score)

        existing_attributes = self.get_attributes()
        if existing_attributes is not None:
            existing_attributes.update(kwargs)
            self.set_attributes(**existing_attributes)
        else:
            self.set_attributes(**kwargs)

    # Overwrite function from BaseType
    # since Class shouldn't have a Class attribute
    def get_class(self):
        return self

    # Overwrite __hash__, since the class_uuid should
    # already uniquely define a Class.
    def __hash__(self):
        return hash(self.class_uuid)

    def _on_hash(self, context):
        return context.update_hash(str(self.class_uuid))

    def __eq__(self, other):

        return (
            type(self) == type(other) and self.class_uuid == other.class_uuid
        )

    def __ne__(self, other):
        return not self.__eq__(other)
