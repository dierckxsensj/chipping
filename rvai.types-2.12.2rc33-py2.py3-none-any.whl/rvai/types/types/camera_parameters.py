import json
from typing import Any, Dict

from rvai.types.base_type import BaseType, record
from rvai.types.constants import ENCODING_KEY, REF_KEY, TYPE_KEY
from rvai.types.types.ndarray import NDArray
from rvai.types.types.optional import Optional
from rvai.types.types.rigid_transformation_3d import RigidTransformation3D


def to_json(camera_parameters: "CameraParameters") -> Dict[str, Any]:
    json_data = {
        "model": "halcon_area_scan_division",
        "matrix": camera_parameters.intrinsic_matrix.tolist(),
        "imageSize": [
            int(camera_parameters.image_width),
            int(camera_parameters.image_height),
        ],
        "center": [camera_parameters.cx, camera_parameters.cy],
        "pixelSize": [
            camera_parameters.pixel_width,
            camera_parameters.pixel_height,
        ],
        "focalLength": camera_parameters.f,
        "distortion": camera_parameters.kappa,
    }
    if camera_parameters.T_world_to_camera.value is not None:
        transform = camera_parameters.T_world_to_camera.value
        json_data["rotation"] = transform.R.tolist()
        json_data["translation"] = transform.t.tolist()

    return json_data


def from_json(json_data: Dict[str, Any]) -> "CameraParameters":
    assert (
        json_data["model"] == "halcon_area_scan_division"
    ), "unknown camera model"

    if "rotation" in json_data and "translation" in json_data:
        transform: Optional[RigidTransformation3D] = Optional(
            RigidTransformation3D(
                NDArray(json_data["rotation"]),
                NDArray(json_data["translation"]),
            )
        )
    else:
        transform = Optional()

    return CameraParameters(
        json_data["distortion"],
        json_data["focalLength"],
        json_data["pixelSize"][0],
        json_data["pixelSize"][1],
        json_data["center"][0],
        json_data["center"][1],
        json_data["imageSize"][0],
        json_data["imageSize"][1],
        transform,
    )


@record
class CameraParameters(BaseType):
    """CameraParameters Data Type

    :ivar kappa: a :class:`float64` object
    :type kappa: float64
    :ivar f: a :class:`float64` object
    :type f: float64
    :ivar pixel_width: a :class:`float64` object
    :type pixel_width: float64
    :ivar pixel_height: a :class:`float64` object
    :type pixel_height: float64
    :ivar cx: a :class:`float64` object
    :type cx: float64
    :ivar cy: a :class:`float64` object
    :type cy: float64
    :ivar image_width: a :class:`int32` object
    :type image_width: int32
    :ivar image_height: a :class:`int32` object
    :type image_height: int32
    :ivar T_world_to_camera: a :class:`Optional[RigidTransformation3D]` object
    :type T_world_to_camera: Optional[RigidTransformation3D]
    """

    kappa: float
    f: float
    pixel_width: float
    pixel_height: float
    cx: float
    cy: float
    image_width: int
    image_height: int
    T_world_to_camera: Optional[RigidTransformation3D]

    def __init__(
        self,
        kappa: float,
        f: float,
        pixel_width: float,
        pixel_height: float,
        cx: float,
        cy: float,
        image_width: int,
        image_height: int,
        T_world_to_camera: Optional[RigidTransformation3D],
        **kwargs
    ):
        self.kappa = kappa
        self.f = f
        self.pixel_width = pixel_width
        self.pixel_height = pixel_height
        self.cx = cx
        self.cy = cy
        self.image_width = image_width
        self.image_height = image_height
        self.T_world_to_camera = T_world_to_camera

    def _on_artifacts_encode(self, context):
        if context.config.get("3dlabeler", False):
            buffer = json.dumps(to_json(self)).encode("utf-8")
            ref = context.create_artifact("data", buffer, "json")
            return {
                TYPE_KEY: self.type_name(),
                ENCODING_KEY: {"data": "json"},
                "data": {REF_KEY: ref},
            }
        else:
            return None

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):
        if encoding is not None and encoding["data"] == "json":
            data = obj.pop("data")
            ref = data.get(REF_KEY).split("#/resources/").pop(-1)
            artifact = context.artifacts[ref]

            obj.pop(TYPE_KEY, None)
            obj.pop(ENCODING_KEY, None)

            json_data = json.loads(artifact.decode("utf-8"))
            return from_json(json_data)
        else:
            return None

    @property
    def intrinsic_matrix(self) -> NDArray:
        """
        A matrix which represents the intrinsic parameters of a camera
        @return: a matrix of 3x3
        """
        fx = self.f / self.pixel_width
        fy = self.f / self.pixel_height
        return NDArray([[fx, 0, self.cx], [0, fy, self.cy], [0, 0, 1]])

    @property
    def T_camera_to_world(self) -> Optional[RigidTransformation3D]:
        if self.T_world_to_camera.value is None:
            return Optional()
        else:
            return Optional(self.T_world_to_camera.value.invert())
