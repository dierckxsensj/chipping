from rvai.types.base_type import BaseType, record
from rvai.types.types.list import List
from rvai.types.types.point import Point


@record
class Polygon(BaseType):
    """Polygon Data Type

    :ivar points: a :class:`List[Point]` object
    :type points: List[Point]
    """

    points: List[Point]

    def __post_init__(self):
        super().__post_init__()
        if any(type(p) != Point for p in self.points):
            raise TypeError("Polygon can only contain Points")
        if len(self.points) < 2:
            raise ValueError("Polygon needs at least 2 points")

    @classmethod
    def _on_fake(cls, T, context):
        min_amount = context.config.get("POLYGON_POINTS_MIN_AMOUNT", 2)
        max_amount = context.config.get("POLYGON_POINTS_MAX_AMOUNT", 10)
        n_points = context.random.randint(min_amount, max_amount)
        points = List(
            Point(
                x=(context.random.random() - 0.5) * 100000000,
                y=(context.random.random() - 0.5) * 100000000,
            )
            for _ in range(n_points)
        )
        return cls(points)

    def __iter__(self):
        for p in self.points:
            yield p

    def __len__(self):
        return len(self.points)
