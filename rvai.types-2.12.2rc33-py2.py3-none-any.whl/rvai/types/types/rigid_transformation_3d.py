import numpy as np

from rvai.types.base_type import BaseType, record
from rvai.types.types.ndarray import NDArray


@record
class RigidTransformation3D(BaseType):
    """RigidTransformation3D Data Type

    :ivar R: a :class:`NDArray` object
    :type R: NDArray
    :ivar t: a :class:`NDArray` object
    :type t: NDArray
    """

    R: NDArray
    t: NDArray

    @classmethod
    def _on_fake(cls, T, context):
        return cls(
            NDArray(context.np.rand(3, 3)), NDArray(context.np.rand(3)),
        )

    def invert(self) -> "RigidTransformation3D":
        if np.allclose(self.R.T @ self.R, np.eye(3)):  # orthogonal R
            R = self.R.T
            t = (-self.R.T @ np.c_[self.t]).ravel()
        else:
            Tinv = np.linalg.solve(self.homogeneous(), np.eye(4))
            R = Tinv[:3, :3]
            t = Tinv[:3, 3]
        return RigidTransformation3D(R, t)

    def homogeneous(self) -> NDArray:
        homogeneous = np.eye(4)
        homogeneous[:3, :3] = self.R
        homogeneous[:3, 3] = self.t
        return homogeneous

    def __matmul__(
        self, other: "RigidTransformation3D"
    ) -> "RigidTransformation3D":
        R = self.R @ other.R
        t = self.R @ other.t + self.t
        return RigidTransformation3D(R, t)
