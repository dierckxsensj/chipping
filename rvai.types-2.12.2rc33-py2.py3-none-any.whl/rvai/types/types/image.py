import io
import typing

import cv2
import numpy as np
import pybase64
import requests
from numpy import float32, float64
from PIL import Image as PILImage

from rvai.types.base_type import primitive
from rvai.types.constants import ENCODING_KEY, REF_KEY, TYPE_KEY
from rvai.types.fuzzing.fake import _fake_annotations
from rvai.types.serialization.json_struct import to_camel_case, to_snake_case
from rvai.types.types.ndarray import NDArray


def to_png(image, resolution=None, swap_channels=False, **kwargs):
    scaled, image = to_pil_image(
        image, resolution=resolution, swap_channels=swap_channels
    )
    return scaled, to_bytes(image, encoding="png", **kwargs)


def to_webp(image, resolution=None, swap_channels=False, **kwargs):
    scaled, image = to_pil_image(
        image, resolution=resolution, swap_channels=swap_channels
    )
    return scaled, to_bytes(image, encoding="webp", **kwargs)


def to_bmp(image, resolution=None, swap_channels=False, **kwargs):
    scaled, image = to_pil_image(
        image, resolution=resolution, swap_channels=swap_channels
    )
    return scaled, to_bytes(image, encoding="bmp", **kwargs)


def to_jpeg(image, resolution=None, swap_channels=False, **kwargs):
    scaled, image = to_pil_image(
        image, resolution=resolution, swap_channels=swap_channels
    )
    return scaled, to_bytes(image, encoding="jpeg", **kwargs)


def from_png(
    png, shape=None, kind=None, scaled=1, resolution=None, swap_channels=False
):
    return from_bytes(
        png,
        shape,
        kind,
        scaled,
        encoding="png",
        resolution=resolution,
        swap_channels=swap_channels,
    )


def from_webp(
    webp, shape=None, kind=None, scaled=1, resolution=None, swap_channels=False
):
    return from_bytes(
        webp,
        shape,
        kind,
        scaled,
        encoding="webp",
        resolution=resolution,
        swap_channels=swap_channels,
    )


def from_bmp(
    bmp, shape=None, kind=None, scaled=1, resolution=None, swap_channels=False
):
    return from_bytes(
        bmp,
        shape,
        kind,
        scaled,
        encoding="bmp",
        resolution=resolution,
        swap_channels=swap_channels,
    )


def from_jpeg(
    jpeg, shape=None, kind=None, scaled=1, resolution=None, swap_channels=False
):
    return from_bytes(
        jpeg,
        shape,
        kind,
        scaled,
        encoding="jpeg",
        resolution=resolution,
        swap_channels=swap_channels,
    )


def to_pil_image(image, resolution=None, swap_channels=False):
    array = image.squeeze()
    scaled = 1
    if array.dtype in (float32, float64):
        scaled = 255
        array = (array * scaled).astype("uint8")
    if swap_channels:
        # Only swap channels when 3 channels are provided
        if len(array.shape) == 3:
            if array.shape[2] == 3:
                array = cv2.cvtColor(array, cv2.COLOR_BGR2RGB)

    image = PILImage.fromarray(array)
    if resolution is not None:
        image = image.resize(resolution)

    return scaled, image


def to_bytes(image: PILImage, encoding: str = "png", **kwargs):

    buffer = io.BytesIO()
    if encoding == "png":
        image.save(buffer, "PNG", **kwargs)
    elif encoding == "webp":
        image.save(buffer, "WebP", **kwargs)
    elif encoding == "bmp":
        image.save(buffer, "BMP", **kwargs)
    elif encoding == "jpeg":
        image.save(buffer, "JPEG", **kwargs)

    return buffer.getvalue()


def from_bytes(
    buffer,
    shape=None,
    kind=None,
    scaled=1,
    encoding="png",
    resolution=None,
    swap_channels=False,
):
    image = PILImage.open(io.BytesIO(buffer))
    if resolution is not None:
        image = image.resize(resolution)

    array = np.asarray(image)

    if encoding == "webp":
        # Needed because PILImage will add an alpha channel to webp files
        array = array[:, :, :3]
        if shape is not None and len(shape) == 2:
            # if input image was rank 2, keep it as rank 2
            array = array[:, :, 1]

    if swap_channels:
        # Only swap channels when 3 channels are provided
        if len(array.shape) == 3:
            if array.shape[2] == 3:
                cv2.cvtColor(array, cv2.COLOR_RGB2BGR, dst=array)

    shape = shape if shape is not None else array.shape
    kind = kind if kind is not None else array.dtype
    array = array.reshape(shape).astype(kind)

    if scaled != 1:
        array = array / scaled

    return scaled, array


@primitive
class Image(NDArray):
    def __hash__(self):
        return hash(self.data.tobytes())

    def vars(self):
        return {
            k: v
            for k, v in vars(self).items()
            if not k.startswith("$") and not k in ["scaled"]
        }

    @classmethod
    def _on_fake(cls, T, context):

        shape = context.config.get("IMAGE_FAKE_SHAPE", (256, 256, 3))

        # subclasses can define extra attributes using cls annotations
        attribute_values = _fake_annotations(cls, context, ignore=["data"])
        # the data attribute is special cased though
        attribute_values.pop("data", None)

        return cls(
            data=context.np.randint(255, size=shape).astype("uint8"),
            **attribute_values,
        )

    def as_rgb(self):

        try:
            array = np.asarray(self)
        except Exception:
            raise ValueError("Unsupported data buffer.")

        nb_dims = len(array.shape)

        if nb_dims == 2:
            array = np.dstack((array, array, array))

        elif nb_dims == 3:
            height, width, nb_channels = array.shape
            if nb_channels == 1:
                array = np.dstack((array, array, array))
            elif nb_channels == 3:
                pass

            elif nb_channels == 4:
                array = np.ascontiguousarray(array[:, :, :3])

            else:
                raise ValueError(
                    f"Unsupported number of channels in image data."
                    f"Image shape: {height}x{width}x{nb_channels}"
                )

        else:
            shape = "x".join(map(str, array.shape))
            raise ValueError(
                f"Unsupported number of dimensions in image data. "
                f"Image shape: {shape}"
            )

        return Image(array)

    def _on_json_encode(self, context):

        scaled, buffer = to_png(self)

        return {
            TYPE_KEY: self.type_name(),
            ENCODING_KEY: {"data": "png+base64"},
            "data": {
                "buffer": pybase64.b64encode(buffer).decode("utf-8"),
                "kind": self.dtype.str,
                "shape": self.shape,
                "scaled": scaled,
            },
            **{
                to_camel_case(k): context.serialize(v)
                for k, v in self.vars().items()
            },
        }

    @classmethod
    def _on_json_decode(cls, context, obj, encoding):

        data = obj.pop("data")
        obj.pop(TYPE_KEY, None)
        obj.pop(ENCODING_KEY, None)

        if encoding["data"] == "png+base64" and isinstance(data, dict):
            png = pybase64.b64decode(data["buffer"])
            shape = data.get("shape", None)
            kind = data.get("kind", None)
            scaled = data.get("scaled", 1)
            scaled, array = from_png(
                png, shape=shape, kind=kind, scaled=scaled
            )

        elif encoding["data"] == "png+url" and isinstance(data, str):
            request = requests.get(data)
            png = request.content
            scaled, array = from_png(png, kind=np.uint8)

        # legacy
        elif encoding["data"] == "png+base64" and isinstance(data, str):
            png = pybase64.b64decode(data)
            scaled, array = from_png(png, kind=np.uint8)

        else:
            raise Exception(f"Unsupported image encoding: {encoding['data']}.")

        image = cls(
            array,
            **{
                to_snake_case(k): context.deserialize(v)
                for k, v in obj.items()
            },
        )

        if scaled != 1:
            image.scaled = scaled

        return image

    def _on_artifacts_encode_3d(self, context):
        swap_channels = context.config.get("bgr", False)
        scaled, pil_image = to_pil_image(self, swap_channels=swap_channels)
        encoding = "bmp"
        buffer = to_bytes(pil_image, encoding=encoding)
        compressed_encoding = "jpeg"
        compressed_buffer = to_bytes(
            pil_image, encoding=compressed_encoding, quality=25
        )

        compressed_ref = context.create_artifact(
            "compressed", compressed_buffer, compressed_encoding
        )
        if context.config.get("TEMPLATE", False):
            compressed_metadata = {}
        else:
            compressed_metadata = {
                "kind": self.dtype.str,
                "shape": self.shape,
                "scaled": scaled,
                "resolution": None,
            }
        return scaled, buffer, compressed_ref, compressed_metadata, encoding

    def _on_artifacts_encode_2d(self, context):
        swap_channels = context.config.get("bgr", False)
        encoding = context.config.get("image_encoding", "png")
        compressed_ref = None
        compressed_metadata = None

        if encoding == "bmp":
            scaled, buffer = to_bmp(self, swap_channels=swap_channels)
        elif encoding == "jpeg":
            scaled, buffer = to_jpeg(self, swap_channels=swap_channels)
        else:
            scaled, buffer = to_png(self, swap_channels=swap_channels)

        return scaled, buffer, compressed_ref, compressed_metadata, encoding

    def _on_artifacts_encode(self, context):

        if context.config.get("3dlabeler", False):
            (
                scaled,
                buffer,
                compressed_ref,
                compressed_metadata,
                encoding,
            ) = self._on_artifacts_encode_3d(context)
        else:
            (
                scaled,
                buffer,
                compressed_ref,
                compressed_metadata,
                encoding,
            ) = self._on_artifacts_encode_2d(context)

        # optionally the artifact can be saved with specific filename
        filename = context.config.get("image_filename", None)

        ref = context.create_artifact("data", buffer, encoding, filename)

        if context.config.get("TEMPLATE", False):
            metadata = {}
        else:
            metadata = {
                "kind": self.dtype.str,
                "shape": self.shape,
                "scaled": scaled,
            }

        result = {
            TYPE_KEY: self.type_name(),
            ENCODING_KEY: {"data": encoding},
            "data": {REF_KEY: ref, **metadata},
            **{
                to_camel_case(k): context.serialize(v)
                for k, v in self.vars().items()
            },
        }

        if compressed_ref is not None and compressed_metadata is not None:
            result["compressed"] = {
                REF_KEY: compressed_ref,
                **compressed_metadata,
            }

        return result

    @classmethod
    def _on_artifacts_decode(cls, context, obj, encoding):
        data = obj.pop("data")
        ref = data.get(REF_KEY).split("#/resources/").pop(-1)
        shape = data.get("shape", None)
        kind = data.get("kind", None)
        scaled = data.get("scaled", 1)
        artifact = context.artifacts[ref]

        obj.pop(TYPE_KEY, None)
        obj.pop(ENCODING_KEY, None)

        swap_channels = context.config.get("bgr", False)

        if encoding is not None and encoding["data"] == "webp":
            scaled, array = from_webp(
                artifact,
                shape=shape,
                kind=kind,
                scaled=scaled,
                swap_channels=swap_channels,
            )
        if encoding is not None and encoding["data"] == "bmp":
            scaled, array = from_bmp(
                artifact,
                shape=shape,
                kind=kind,
                scaled=scaled,
                swap_channels=swap_channels,
            )
        else:
            scaled, array = from_png(
                artifact,
                shape=shape,
                kind=kind,
                scaled=scaled,
                swap_channels=swap_channels,
            )

        image = cls(
            array,
            **{
                to_snake_case(k): context.deserialize(v)
                for k, v in obj.items()
                if k not in ["resources", "compressed"]
            },
        )

        if scaled != 1:
            image.scaled = scaled

        return image

    def __eq__(self, other):

        scaled = max(getattr(self, "scaled", 1), getattr(other, "scaled", 1))

        # increase tolerance if scaled
        if scaled != 1:
            atol = 1 / scaled
        else:
            atol = 1e-08

        if not hasattr(other, "shape"):
            return False
        if tuple(self.shape) != tuple(other.shape):
            return False
        if self.dtype != other.dtype:
            return False
        if not np.allclose(self, other, atol=atol):
            return False
        if not {k: v for k, v in vars(self).items() if k != "scaled"} == {
            k: v for k, v in vars(other).items() if k != "scaled"
        }:
            return False

        return True

    def show(self):
        array = self.squeeze()
        scaled = 1
        if array.dtype in [float32, float64]:
            scaled = 255
            array = (array * scaled).astype("uint8")

        PILImage.fromarray(array).show()

    @classmethod
    def from_stream(cls, stream: typing.IO):
        return Image(PILImage.open(stream))

    @classmethod
    def from_file(cls, path: str):
        return Image(PILImage.open(path))
