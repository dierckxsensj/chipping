from typing import Generic, Optional, Type, TypeVar

from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import CLASS_KEY
from rvai.types.inspect import get_parameters
from rvai.types.meta_type import GenericMetaType
from rvai.types.types.list import List
from rvai.types.utils import TypeFactory
from rvai.types.visit import reset_chain, update_chain

T = TypeVar("T")


def parse_args(*args, options=None, selected=None):
    if len(args) == 1 and isinstance(args[0], (tuple, list, List)):
        options = args[0]
    elif len(args) == 2 and isinstance(args[0], (tuple, list, List)):
        options = args[0]
        selected = args[1]
    elif len(args) > 1:
        options = args
    elif options is None:
        options = List()
    return options, selected


@primitive
class Enum(BaseType, Generic[T], metaclass=GenericMetaType):

    options: List[T]
    selected: Optional[T] = None

    def __new__(cls, *args, options=None, selected=None, T=None):
        try:
            T = cls.__args__[0]
        except TypeError:
            pass
        return super().__new__(
            cls, *args, options=options, selected=selected, T=T
        )

    def __init__(self, *args, options=None, selected=None, T=None):

        options, selected = parse_args(
            *args, options=options, selected=selected
        )
        T = T if T is not None else type(options[0])
        options = List(
            *map(lambda v: T(v) if not isinstance(v, BaseType) else v, options)
        )
        selected = (
            T(selected)
            if not isinstance(selected, (BaseType, type(None)))
            else selected
        )

        if not issubclass(T, BaseType):
            raise ValueError("Could not infer Enum inner type")
        if not isinstance(selected, (BaseType, type(None))):
            raise ValueError("Enum selected value should be an RVAI Type")
        if not isinstance(options, List):
            raise ValueError("Enum options should be an RVAI List")

        self.options, self.selected = options, selected

    def __hash__(self):
        return hash(frozenset((*self.options, self.selected)))

    def __repr__(self):
        selected = repr(self.selected)
        options = repr(self.options)
        return (
            f"{self.full_type_name()}(selected={selected}, options={options})"
        )

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self):
        T = TypeFactory(self.full_type_name())
        args = (self.options, self.selected)
        state = (self.get_class(), self.get_attributes())
        return (T, args, state)

    def __eq__(self, other):
        eq = True
        if type(self) == type(other):
            eq = (
                self.selected == other.selected
                and self.options == other.options
            )
        else:
            eq = self.selected == other

        same_class = self.get_class() == getattr(other, CLASS_KEY, None)

        return eq and same_class

    @classmethod
    def visit_type(cls, context, apply_function, visit_function):
        T, *_ = cls.__args__
        return apply_function(
            cls,
            context,
            {
                "options": visit_function(List[T], context),
                "selected": visit_function(T, context),
            },
        )

    def visit_type_instance(self, context, apply_function, visit_function):
        def reset(context, f):
            with reset_chain(context):
                ret = f()
            return ret

        return apply_function(
            self,
            context,
            {
                "options": reset(
                    context,
                    lambda: visit_function(
                        self.options, update_chain(context, "options")
                    ),
                ),
                "selected": reset(
                    context,
                    lambda: visit_function(
                        self.selected, update_chain(context, "selected")
                    ),
                ),
            },
        )

    @classmethod
    def configure(cls: "Type[Enum]", obj) -> "Type[Enum[T]]":

        option = next(iter(obj["options"]), None)
        if get_parameters(cls) and option is not None:
            option_type = option.full_type()
            return cls[option_type]  # type: ignore

        else:
            return cls
