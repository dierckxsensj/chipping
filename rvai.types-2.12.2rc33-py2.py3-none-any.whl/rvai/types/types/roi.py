import warnings
from typing import Generic, Optional, Tuple, Type, TypeVar, Union

import numpy as np
from PIL import Image as PILImage
from shapely import geometry

from rvai.types.base_type import BaseType, primitive
from rvai.types.constants import CLASS_KEY
from rvai.types.inspect import get_parameters
from rvai.types.meta_type import GenericMetaType
from rvai.types.types.bounding_box import BoundingBox
from rvai.types.types.color import Color
from rvai.types.types.image import Image
from rvai.types.types.integer import Integer
from rvai.types.types.list import List
from rvai.types.types.mask import Mask
from rvai.types.types.point import Point
from rvai.types.types.polygon import Polygon
from rvai.types.types.shape import Shape
from rvai.types.types.string import String
from rvai.types.utils import TypeFactory, _get_parameter_types
from rvai.types.visit import reset_chain, update_chain

SUPPORTED_TYPES = [Mask, BoundingBox, Polygon]

T = TypeVar(
    "T",
    Mask,
    BoundingBox,
    Polygon,
    List[Mask],
    List[BoundingBox],
    List[Polygon],
)


@primitive
class ROI(BaseType, Generic[T], metaclass=GenericMetaType):

    value: Optional[T] = None
    canvas_shape: Optional[Shape] = None
    canvas_url: Optional[String] = None
    color: Color = Color(r=255, g=0, b=0)
    roi_id: int = 0

    def __init__(
        self,
        value: Optional[T] = None,
        canvas_shape: Optional[Shape] = None,
        canvas_url: Optional[String] = None,
        color: Color = Color(r=255, g=0, b=0),
        roi_id: int = 0,
    ):
        self.color = color
        self.roi_id = roi_id
        self.canvas_shape = canvas_shape
        self.canvas_url = canvas_url
        if value is not None:
            if isinstance(value, List):
                for item in value:
                    if not any(isinstance(item, t) for t in SUPPORTED_TYPES):
                        raise ValueError(
                            f"Invalid ROI Type, expected on of {SUPPORTED_TYPES}"
                        )

            elif not any(isinstance(value, t) for t in SUPPORTED_TYPES):
                raise ValueError(
                    f"Invalid ROI Type, expected on of {SUPPORTED_TYPES}"
                )
        self.value = value

    def __hash__(self):
        return hash(
            frozenset(
                (
                    self.value,
                    self.canvas_shape,
                    self.canvas_url,
                    self.color,
                    self.roi_id,
                )
            )
        )

    def __setstate__(self, state):
        class_, attributes = state
        if class_:
            self.set_class(class_)
        if attributes:
            self.set_attributes(attributes)

    def __reduce__(self):
        T = TypeFactory(self.full_type_name())
        args = (
            self.value,
            self.canvas_shape,
            self.canvas_url,
            self.color,
            self.roi_id,
        )
        state = (self.get_class(), self.get_attributes())
        return (T, args, state)

    def __repr__(self):
        return f"{self.full_type_name()}(value={repr(self.value)}, canvas_shape={repr(self.canvas_shape)}, roi_id={repr(self.roi_id)})"

    def __eq__(self, other):
        if type(self) == type(other):
            eq = self.value == other.value
            eq &= self.canvas_shape == other.canvas_shape
            eq &= self.roi_id == other.roi_id
        else:
            eq = self.value == other
        same_class = self.get_class() == getattr(other, CLASS_KEY, None)
        return eq and same_class

    def __ne__(self, other):
        return not self == other

    @classmethod
    def visit_type(cls, context, apply_function, visit_function):

        T, *_ = _get_parameter_types(cls)

        return apply_function(
            cls,
            context,
            {
                "value": visit_function(T, context),
                "canvas_shape": visit_function(Shape, context),
                "canvas_url": visit_function(String, context),
                "color": visit_function(Color, context),
                "roi_id": visit_function(Integer, context),
            },
        )

    def visit_type_instance(self, context, apply_function, visit_function):
        with reset_chain(context):
            ret = apply_function(
                self,
                context,
                {
                    "value": visit_function(
                        self.value, update_chain(context, "value")
                    ),
                    "canvas_shape": visit_function(
                        self.canvas_shape,
                        update_chain(context, "canvas_shape"),
                    ),
                    "canvas_url": visit_function(
                        self.canvas_url, update_chain(context, "canvas_url"),
                    ),
                    "color": visit_function(
                        self.color, update_chain(context, "color")
                    ),
                    "roi_id": visit_function(
                        self.roi_id, update_chain(context, "canvas_shape")
                    ),
                },
            )
        return ret

    @classmethod
    def configure(cls: "Type[ROI]", obj) -> "Type[ROI[T]]":

        if get_parameters(cls):
            item_type = obj["value"].full_type()
            return cls[item_type]  # type: ignore

        else:
            return cls

    @staticmethod
    def _point_inside_mask(point: Point, mask: Mask) -> bool:
        return mask.data[int(point.y), int(point.x)] > 0

    @staticmethod
    def _point_inside_boundingbox(point: Point, box: BoundingBox) -> bool:
        return (
            box.p1.x <= point.x <= box.p2.x and box.p1.y <= point.y <= box.p2.y
        )

    @staticmethod
    def _point_inside_polygon(point: Point, polygon: Polygon) -> bool:
        # convert to Shapely polygon
        n_polygon = geometry.Polygon([(p.x, p.y) for p in polygon])

        return n_polygon.contains(
            geometry.Point(point.x, point.y)
        ) or n_polygon.touches(geometry.Point(point.x, point.y))

    def point_inside_supported_type(self, point: Point, item) -> bool:
        # loop over the different supported types the ROI can be represented in
        if isinstance(item, Mask):
            return self._point_inside_mask(point=point, mask=item)
        elif isinstance(item, Polygon):
            return self._point_inside_polygon(point=point, polygon=item)
        elif isinstance(item, BoundingBox):
            return self._point_inside_boundingbox(point=point, box=item)
        elif item is None:
            # When no ROI is specified, each point is inside
            return True
        else:
            raise TypeError("unsupported type")

    def point_inside_roi(self, point: Point) -> bool:
        """
        Function that checks if a point is inside the ROI or not
        :param point: Point as defined in rvai.types
        :return: True if the point is inside the ROI, False otherwise
        """
        # When the point is outside of the canvas, it's outside of the ROI for sure
        if self.canvas_shape is not None:
            height, width = self.canvas_shape
            if (
                point.x < 0
                or point.x >= width
                or point.y < 0
                or point.y >= height
            ):
                return False

        if isinstance(self.value, List):
            for item in self.value:
                if self.point_inside_supported_type(point=point, item=item):
                    return True
            return False

        else:  # When creating the ROI, only supported types can be in self.value
            return self.point_inside_supported_type(
                point=point, item=self.value
            )

    @staticmethod
    def _box_inside_mask(
        box: BoundingBox, mask: Mask, min_overlap: float
    ) -> bool:
        x1, y1 = int(box.p1.x), int(box.p1.y)
        x2, y2 = int(box.p2.x), int(box.p2.y)
        patch = mask[y1:y2, x1:x2]
        # Calculate the ratio of the box that is in the zone. Mask is a boolean
        #  array, so casted this gives 1 for a pixel in the zone, 0 for a pixel
        #  outside of the zone
        if np.size(patch) > 0:
            ratio = int(np.sum(patch)) / int(np.size(patch))
        else:
            ratio = 0.0
        return ratio >= min_overlap

    @staticmethod
    def _box_inside_boundingbox(
        box: BoundingBox, roi_box: BoundingBox, min_overlap: float
    ) -> bool:
        box_area = box.width() * box.height()
        # Get intersection box
        x1 = max(box.p1.x, roi_box.p1.x)
        y1 = max(box.p1.y, roi_box.p1.y)
        x2 = min(box.p2.x, roi_box.p2.x)
        y2 = min(box.p2.y, roi_box.p2.y)
        if x2 < x1 or y2 < y1:
            return False

        intersection_area = (x2 - x1) * (y2 - y1)
        return (intersection_area / box_area) >= min_overlap

    @staticmethod
    def _box_inside_polygon(
        box: BoundingBox, polygon: Polygon, min_overlap: float
    ) -> bool:
        box_area = box.width() * box.height()
        # convert to Shapely polygon
        n_polygon = geometry.Polygon([(p.x, p.y) for p in polygon])
        n_box = geometry.box(box.p1.x, box.p1.y, box.p2.x, box.p2.y)
        # Calculate intersection area
        intersection_area = n_polygon.intersection(n_box).area
        return (intersection_area / box_area) >= min_overlap

    def box_inside_supported_type(
        self, box: BoundingBox, item, min_overlap: float
    ) -> bool:
        # loop over the different supported types the ROI can be represented in
        if isinstance(item, Mask):
            return self._box_inside_mask(
                box=box, mask=item, min_overlap=min_overlap
            )
        elif isinstance(item, Polygon):
            return self._box_inside_polygon(
                box=box, polygon=item, min_overlap=min_overlap
            )
        elif isinstance(item, BoundingBox):
            return self._box_inside_boundingbox(
                box=box, roi_box=item, min_overlap=min_overlap
            )
        elif item is None:
            # When no ROI is specified, each point is inside
            return True
        else:
            raise TypeError("unsupported type")

    def box_inside_roi(
        self, box: BoundingBox, min_overlap: float = 0.5
    ) -> bool:
        """
        Function that checks if a bounding box is inside the ROI or not
        :param box: BoundingBox as defined in rvai.types
        :param min_overlap: Minimum ratio of the box that has to be inside the ROI
        :return: True if the box is inside the ROI, False otherwise
        """
        if isinstance(self.value, List):
            for item in self.value:
                if self.box_inside_supported_type(
                    box=box, item=item, min_overlap=min_overlap
                ):
                    return True
            return False

        else:  # When creating the ROI, only supported types can be in self.value
            return self.box_inside_supported_type(
                box=box, item=self.value, min_overlap=min_overlap
            )

    def _resize_mask(self, mask: Mask, target_shape: Tuple[int, ...]) -> Mask:
        # Currently only 2D resizing is supported
        assert len(target_shape) == 2
        target_height, target_width = target_shape
        wh_shape = (target_width, target_height)
        # This will only be called when shape is specified
        assert self.canvas_shape is not None
        return Mask(
            np.array(
                PILImage.fromarray(mask.astype(np.uint8)).resize(wh_shape)
            ).astype(np.bool)
        )

    def _resize_polygon(
        self, polygon: Polygon, target_shape: Tuple[int, ...]
    ) -> Polygon:
        # Currently only 2D resizing is supported
        assert len(target_shape) == 2
        target_height, target_width = target_shape
        # This will only be called when shape is specified
        assert self.canvas_shape is not None
        current_height, current_width = self.canvas_shape[:2]
        scale_width = target_width / current_width
        scale_height = target_height / current_height
        scaled_points: List[Point] = List[Point]([])
        for point in polygon.points:
            scaled_points.append(
                Point(x=point.x * scale_width, y=point.y * scale_height)
            )
        return Polygon(points=scaled_points)

    def _resize_boundingbox(
        self, box: BoundingBox, target_shape: Tuple[int, ...]
    ) -> BoundingBox:
        # Currently only 2D resizing is supported
        assert len(target_shape) == 2
        target_height, target_width = target_shape
        # This will only be called when shape is specified
        assert self.canvas_shape is not None
        current_height, current_width = self.canvas_shape[:2]
        scale_width = target_width / current_width
        scale_height = target_height / current_height
        scaled_p1 = Point(x=box.p1.x * scale_width, y=box.p1.y * scale_height)
        scaled_p2 = Point(x=box.p2.x * scale_width, y=box.p2.y * scale_height)
        return BoundingBox(p1=scaled_p1, p2=scaled_p2)

    def resize_value(self, value, target_shape: Tuple[int, ...]):
        if isinstance(value, Mask):
            return self._resize_mask(value, target_shape)
        elif isinstance(value, Polygon):
            return self._resize_polygon(value, target_shape)
        elif isinstance(value, BoundingBox):
            return self._resize_boundingbox(value, target_shape)
        elif value is None:
            return None
        else:
            raise TypeError("unsupported type")

    def resize_to_canvas(self, canvas: Union[Image]) -> "ROI[T]":
        # When canvas shape is not specified, we cannot reshape
        if self.canvas_shape is None:
            warnings.warn("Cannot resize empty canvas")
            return self
        if isinstance(canvas, Image):
            target_height, target_width = canvas.shape[:2]
            target_shape = Shape((target_height, target_width))

            if isinstance(self.value, List):
                new_value = List[T]([])
                for item in self.value:
                    new_value.append(
                        self.resize_value(
                            value=item, target_shape=target_shape
                        )
                    )
            else:  # When creating the ROI, only supported types can be in self.value
                new_value = self.resize_value(
                    value=self.value, target_shape=target_shape,
                )
            return ROI[T](
                value=new_value,  # type: ignore
                canvas_shape=target_shape,
                canvas_url=self.canvas_url,
                color=self.color,
                roi_id=self.roi_id,
            )
        else:
            raise TypeError(f"Unsupported canvas type {type(canvas)}")
