import random
import string
import sys
from collections import Mapping
from dataclasses import MISSING, Field, is_dataclass
from typing import Any, Dict, List, Union

import numpy as np
from numpy import float32, float64, int32, int64

from rvai.types.constants import (
    ALIAS_KEY,
    DEFAULT_RANDOM_SEED,
    MAX_FLOAT,
    MIN_FLOAT,
)
from rvai.types.inspect import fields, get_args, is_optional_type
from rvai.types.visit import create_context, visit_type

RANDOM = random.Random(DEFAULT_RANDOM_SEED)
RANDOM_NP = np.random.RandomState(seed=DEFAULT_RANDOM_SEED)
MAX_SIZE = sys.maxsize

# Functions used to generate fake data for 'primitive' types.
# Can be overridden by Type classes by implementing `generate_fake_sample.

# TODO: use JSON value in context to toggle rounding,
# as rounding is not needed for HDF5 and msgpack encoding

_primitive_generators = {
    bool: lambda context: bool(context.random.getrandbits(1)),
    bytes: lambda context: bytes(context.np.bytes(context.np.randint(0, 100))),
    int: lambda context: context.random.randint(-MAX_SIZE, MAX_SIZE),
    int32: lambda context: int32(context.np.randint(-MAX_SIZE, MAX_SIZE)),
    int64: lambda context: int64(context.np.randint(-MAX_SIZE, MAX_SIZE)),
    float: lambda context: round(
        context.random.uniform(MIN_FLOAT, MAX_FLOAT), 5
    ),
    float32: lambda context: np.round(float32(context.np.rand()), 5),
    float64: lambda context: np.round(float64(context.np.rand()), 5),
    str: lambda context: "".join(
        context.random.choice(string.ascii_uppercase + string.digits)
        for _ in range(context.random.randint(1, 100))
    ),
}


def fake(T, seed=None, config={}):

    """Create Random context and visit the the recursively with the
    `_fake` function."""

    if seed is not None:
        _random = random.Random(seed)
        _np = np.random.RandomState(seed=seed)
    else:
        _random = RANDOM
        _np = RANDOM_NP

    _context = create_context(
        random=_random,
        np=_np,
        config={
            "VISIT_TYPE_LIST_AMOUNT": 3,
            "VISIT_TYPE_DICT_AMOUNT": 3,
            **config,
        },
    )

    try:
        return visit_type(T, _context, _fake, "_on_fake")
    except TypeError as e:
        if "Cannot visit" in str(e):
            raise TypeError(
                f"Cannot fake unparametrized generic type {T.type_name()}"
            )
        else:
            raise


def _fake(T, context, value):

    if hasattr(T, ALIAS_KEY):
        return T.fake()

    if value is None and hasattr(T, "_on_fake"):
        return T._on_fake(context)

    # Check if Union type
    # TODO: generate None's occasionally
    if hasattr(T, "__origin__") and T.__origin__ == Union:
        T, *_ = T.__args__
        return visit_type(T, context, _fake, "_on_fake")

    if _primitive_generators.get(T, None):
        return _primitive_generators[T](context)

    elif value is not None and isinstance(value, Mapping):
        return T(**value)

    else:
        raise ValueError(
            f"Don't know how to generate a fake value for {repr(T)} type"
        )


def _fake_annotations(
    cls, context, ignore: List[str], ignore_defaults=False
) -> Dict[str, Any]:

    if is_dataclass(cls):
        annotations = {f.name: f.type for f in fields(cls)}
    else:
        annotations = cls.__annotations__
    values: Dict[str, Any] = {}

    for attr_name, attr_type in annotations.items():

        if attr_name in ignore:
            continue

        # try getting a value from the cls attributes
        attr_value = getattr(cls, attr_name, MISSING)

        # if it's a Field we have some more work to do
        if isinstance(attr_value, Field):
            attr_value = (
                attr_value.default
                if attr_value.default is not MISSING
                else attr_value.default_factory()  # type: ignore
            )

        if is_optional_type(attr_type):
            attr_type, *_ = get_args(attr_type)

        # if we still don't have a valid value, we can try faking one
        if (attr_value is MISSING or ignore_defaults) and hasattr(
            attr_type, "fake"
        ):
            attr_value = attr_type.fake()

        # last chance, try generating one of the supported primitive types
        generator = _primitive_generators.get(attr_type)
        if generator is not None:
            attr_value = generator(context)

        # still no value, something is wrong yo
        if attr_value is MISSING:
            raise ValueError(
                f"Annotation type could not be faked: {attr_type}. \n"
                f"Class annotations for {cls.__name__}: {annotations}"
            )

        values[attr_name] = attr_value

    return values


def fake_dataclass_instance(
    dataclass, seed=None, config={}, ignore_defaults=True
):
    """Fake a dataclass."""

    if seed is not None:
        _random = random.Random(seed)
        _np = np.random.RandomState(seed=seed)
    else:
        _random = RANDOM
        _np = RANDOM_NP

    _context = create_context(
        random=_random,
        np=_np,
        config={
            "VISIT_TYPE_LIST_AMOUNT": 3,
            "VISIT_TYPE_DICT_AMOUNT": 3,
            **config,
        },
    )

    annotations = _fake_annotations(
        dataclass, context=_context, ignore=[], ignore_defaults=ignore_defaults
    )
    return dataclass(**annotations)
