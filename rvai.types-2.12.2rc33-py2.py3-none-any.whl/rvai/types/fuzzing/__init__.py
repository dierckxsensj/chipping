from .fake import fake

__all__ = ["fake"]
