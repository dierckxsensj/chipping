from typing import GenericMeta

from rvai.types.constants import ALIAS_KEY


class BaseMetaType(type):
    """
    A metaclass is used to provide better representations for Type classes.
    """

    def __repr__(cls):
        return getattr(cls, ALIAS_KEY, cls.type_name())


class GenericMetaType(GenericMeta, BaseMetaType):
    """
    A metaclass is used to provide better representations for Type classes.
    """

    def __repr__(cls):
        return getattr(cls, ALIAS_KEY, cls.type_name())
