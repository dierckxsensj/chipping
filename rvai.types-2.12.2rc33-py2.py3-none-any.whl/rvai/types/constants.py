from numpy import float32, float64, int32, int64, ndarray

TYPE_KEY = "$type"
NAME_KEY = "$name"
DESCRIPTION_KEY = "$description"
FULL_TYPE_KEY = "$fullType"
ALIAS_KEY = "$alias"
ENCODING_KEY = "$encoding"
SHARED_FLAG_KEY = "$shared"
REF_KEY = "$ref"
ATTRIBUTES_KEY = "$attributes"
CLASS_KEY = "$class"
CLASS_UUID_KEY = "$class_uuid"
CLASS_NAME_KEY = "$class_name"

# used in HDF5 encoding, which lacks a list type
HDF5_LIST_IDENTIFIER = "$list"

PYTHON_PRIMITIVES = [bool, float, int, str, type(None), bytes]

NUMPY_PRIMITIVES = [float32, float64, int32, int64, ndarray]

PYTHON_NUMPY_PRIMITIVES = PYTHON_PRIMITIVES + NUMPY_PRIMITIVES

DEFAULT_RANDOM_SEED = 42
MIN_FLOAT = -1000
MAX_FLOAT = 1000
