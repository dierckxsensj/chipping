"""Top-level package for RVAI Types."""

__author__ = """Robovision"""
__email__ = "dev@robovision.ai"
__version__ = "2.12.2rc33"

from typing import TYPE_CHECKING

from rvai.types.base_type import BaseType, primitive
from rvai.types.globals import _types
from rvai.types.types.anchored_vector_3d import AnchoredVector3D
from rvai.types.types.attribute import Attribute
from rvai.types.types.blob import Blob
from rvai.types.types.boolean import Boolean
from rvai.types.types.bounding_box import BoundingBox
from rvai.types.types.bytes import Bytes
from rvai.types.types.camera_array_parameters import CameraArrayParameters
from rvai.types.types.camera_parameters import CameraParameters
from rvai.types.types.class_ import Class
from rvai.types.types.class_parameters import ClassParameters
from rvai.types.types.classes import Classes
from rvai.types.types.color import Color
from rvai.types.types.confusion_matrix import ConfusionMatrix
from rvai.types.types.dicom import DICOM, DICOMAnnotation
from rvai.types.types.dict import Dict
from rvai.types.types.direction_vector import DirectionVector
from rvai.types.types.disjoint_masks import DisjointMasks
from rvai.types.types.duration import Duration
from rvai.types.types.enum import Enum
from rvai.types.types.event import Event
from rvai.types.types.example import Example
from rvai.types.types.feature_image import FeatureImage, FeatureImageParameters
from rvai.types.types.feature_point import FeaturePoint
from rvai.types.types.feed import Feed
from rvai.types.types.float import Float
from rvai.types.types.float_range import FloatRange
from rvai.types.types.image import Image
from rvai.types.types.image_set import ImageSet
from rvai.types.types.inputs import Inputs
from rvai.types.types.integer import Integer
from rvai.types.types.integer_range import IntegerRange
from rvai.types.types.json import JSON
from rvai.types.types.label import Label
from rvai.types.types.list import List
from rvai.types.types.localized_string import LocalizedString
from rvai.types.types.mask import Mask
from rvai.types.types.masks import Masks
from rvai.types.types.measurements import (
    FieldDefinition,
    Fields,
    Measurement,
    MeasurementDefinition,
    TagDefinition,
    Tags,
)
from rvai.types.types.multi_label import MultiLabel
from rvai.types.types.multi_view_image_set import MultiViewImageSet
from rvai.types.types.ndarray import NDArray
from rvai.types.types.optional import Optional
from rvai.types.types.outputs import Outputs
from rvai.types.types.parameter import Parameter
from rvai.types.types.parameters import Parameters
from rvai.types.types.plane import Plane
# from rvai.types.types.plant_sampler_sample import PlantSamplerSample
# from rvai.types.types.point import Point
# from rvai.types.types.point3d import Point3D
# from rvai.types.types.point_cloud import PointCloud
# from rvai.types.types.point_cloud_mask import PointCloudMask
from rvai.types.types.polygon import Polygon
from rvai.types.types.polyline_mask import PolyLineMask
from rvai.types.types.port import Port
from rvai.types.types.pose import (
    Coco17Skeleton,
    Coco18Skeleton,
    MPIISkeleton,
    Pose,
    Skeleton,
)
from rvai.types.types.range import Range
from rvai.types.types.rigid_transformation_3d import RigidTransformation3D
from rvai.types.types.roi import ROI
# from rvai.types.types.rose_sample import RoseSample
# from rvai.types.types.sample3d import Sample3D
# from rvai.types.types.sample3d2d import Sample3D2D
from rvai.types.types.shape import Shape
# from rvai.types.types.sorter_sample import SorterSample
from rvai.types.types.sphere import Sphere
from rvai.types.types.string import String
from rvai.types.types.timestamp import Timestamp
from rvai.types.types.tracklet import Tracklet
# from rvai.types.types.tulip_sample import TulipSample
from rvai.types.types.url import URL
from rvai.types.types.vector import Vector
# from rvai.types.types.voxel_carving_reconstruction import (
#     VoxelCarvingReconstruction,
# )
from rvai.types.types.working_volume_geometry import WorkingVolumeGeometry
from rvai.types.types.working_volume_parameters import WorkingVolumeParameters
from rvai.types.utils import LUT
from rvai.types.validation import ValidationError

if TYPE_CHECKING:
    from dataclasses import (
        dataclass as primitive,
        dataclass as record,
        dataclass as with_attributes,
    )
else:
    from rvai.types.attributes import with_attributes
    from rvai.types.base_type import primitive, record


# legacy
Type = BaseType
TypeRegistry = lambda type_name: LUT[type_name]

deserialize = BaseType.deserialize

__all__ = [
    # globals
    "_types",
    # bases
    "Type",
    "TypeRegistry",
    "BaseType",
    "primitive",
    "record",
    "with_attributes",
    # methods
    "deserialize",
    # validation
    "ValidationError",
    # types
    "AnchoredVector3D",
    "Attribute",
    "Blob",
    "Boolean",
    "BoundingBox",
    "Bytes",
    "CameraArrayParameters",
    "CameraParameters",
    "Class",
    "ClassParameters",
    "Classes",
    "Coco17Skeleton",
    "Coco18Skeleton",
    "Color",
    "ConfusionMatrix",
    "DICOM",
    "DICOMAnnotation",
    "Dict",
    "DirectionVector",
    "DisjointMasks",
    "Duration",
    "Enum",
    "Event",
    "Example",
    "FeatureImage",
    "FeatureImageParameters",
    "FeaturePoint",
    "Feed",
    "FieldDefinition",
    "Fields",
    "Float",
    "FloatRange",
    "Image",
    "ImageSet",
    "Inputs",
    "Integer",
    "IntegerRange",
    "JSON",
    "Label",
    "List",
    "LocalizedString",
    "LUT",
    "Mask",
    "Masks",
    "Measurement",
    "MeasurementDefinition",
    "MPIISkeleton",
    "MultiLabel",
    "MultiViewImageSet",
    "NDArray",
    "Optional",
    "Outputs",
    "Parameter",
    "Parameters",
    "Plane",
    "PlantSamplerSample",
    "Point",
    "Point3D",
    "PointCloud",
    "PointCloudMask",
    "Polygon",
    "PolyLineMask",
    "Port",
    "Pose",
    "Range",
    "RigidTransformation3D",
    "ROI",
    "RoseSample",
    "Sample3D",
    "Sample3D2D",
    "Shape",
    "Skeleton",
    "SorterSample",
    "Sphere",
    "String",
    "TagDefinition",
    "Tags",
    "Timestamp",
    "Tracklet",
    "TulipSample",
    "URL",
    "Vector",
    "VoxelCarvingReconstruction",
    "WorkingVolumeGeometry",
    "WorkingVolumeParameters",
]
