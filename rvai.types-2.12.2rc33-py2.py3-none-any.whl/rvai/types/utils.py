import re
from typing import (
    TYPE_CHECKING,
    Any,
    List as TypingList,
    Sequence,
    Tuple,
    Union,
)

import rvai.types
from rvai.types.globals import _aliases  # isort: skip
from rvai.types.globals import _types
from rvai.types.inspect import (
    get_args,
    get_generic_bases,
    get_origin,
    get_parameters,
    is_generic_type,
)

if TYPE_CHECKING:
    from rvai.types import Boolean, Float, Integer, String


class hybridmethod(classmethod):
    def __get__(self, instance, type_):
        descr_get = (
            super().__get__ if instance is None else self.__func__.__get__
        )
        return descr_get(instance, type_)


class LookupTable:
    def _create_type(self, typename):
        root = parse_typename(typename)
        type_ = build_type(root)
        _types[typename] = type_
        return type_

    def values(self):
        return _types.values()

    def keys(self):
        return _types.keys()

    def items(self):
        return _types.items()

    def __getitem__(self, typename):
        global _types
        return _types.get(typename, self._create_type(typename))


LUT = LookupTable()


class TypeFactory:
    def __init__(self, full_type_name: str):
        self.full_type_name = full_type_name

    def __call__(self, *args, **kwargs):
        return LUT[self.full_type_name](*args, **kwargs)


def parse_typename(typename, left=r"[\[]", right=r"[\]]", sep=r", *"):
    """ https://stackoverflow.com/a/17141899/190597 (falsetru) """

    pat = r"({}|{}|{})".format(left, right, sep)
    tokens = re.split(pat, typename)

    # convert to s-expressions format
    for i, t in enumerate(tokens):
        if re.match(left, t):
            tokens[i] = tokens[i - 1]
            tokens[i - 1] = "["
            tokens.insert(i + 1, ", ")

    stack = [[]]
    for x in tokens:
        if not x or re.match(sep, x):
            continue
        if re.match(left, x):
            # Nest a new list inside the current list
            current = []
            stack[-1].append(current)
            stack.append(current)
        elif re.match(right, x):
            stack.pop()
            if not stack:
                raise ValueError("Error: opening bracket is missing")
        else:
            stack[-1].append(x)
    if len(stack) > 1:
        raise ValueError("Error: closing bracket is missing")
    return stack.pop().pop()


def _make_list(value: Union[str, TypingList[str]]) -> TypingList[str]:
    if isinstance(value, str):
        return [value]
    else:
        return value


def _parse_expression(expression):
    global _types
    global _aliases

    head, *tail = expression
    name, *aliases = head.split(":")
    alias = aliases[0] if len(aliases) > 0 else None

    original_type = _types[name]
    alias_tuple = _aliases.get(alias)
    alias = alias_tuple[0] if alias_tuple is not None else None

    return original_type, alias, tail


def build_type(expression: TypingList[str]):

    expression = _make_list(expression)
    original_type, alias_type, tail = _parse_expression(expression)
    T = alias_type if alias_type is not None else original_type
    has_parameters = (
        len(get_parameters(T)) > 0 if get_parameters(T) is not None else False
    )

    if len(tail) == 0 or not has_parameters:
        return T
    else:
        return T[  # type: ignore
            tuple(
                build_type(_make_list(subexpression)) for subexpression in tail
            )
        ]


def _recursive_map(seq, func):
    for item in seq:
        if isinstance(item, Sequence):
            yield list(_recursive_map(item, func))
        else:
            yield func(item)


class Aliased:
    def __init__(self, original, alias):
        self.original = original
        self.alias = alias


def _get_original_type(T):

    # alias created with @with_attributes
    if hasattr(T, "__base_type__"):
        fts = _get_full_type_struct(T.__base_type__)
        fts[0] = Aliased(original=fts[0], alias=T)
        return fts
    else:
        return T


def _get_args(T):

    raw_args = get_args(T)
    args = list(map(_get_original_type, raw_args))

    return args


def _to_string(T):
    if T is None or T is type(None):
        return "None"
    else:
        if isinstance(T, Aliased):
            return f"{str(T.original)}:{str(T.alias)}"

        return str(T)


def _get_full_type_struct(T):
    full_type_struct = [get_origin(T), *_get_args(T)]  # type: ignore
    return full_type_struct


def _get_full_type(obj):
    if hasattr(obj, "__orig_class__") and is_generic_type(obj.__orig_class__):  # type: ignore
        T = obj.__orig_class__
        full_type_struct = _get_full_type_struct(T)
        return list(_recursive_map(full_type_struct, _to_string))
    else:
        return None


def _build_full_type(expression):
    if expression is None:
        return None

    built_type = build_type(expression)
    return built_type


def _get_parameter_types(cls):
    # get the arguments to this generic type's parameter `T`
    args = getattr(cls, "__args__", [])

    # if this is a subclass where the type parameters have been
    # completely bound (e.g. List[Boolean] subclass), we need to access
    # it from the first parent type
    if args is None:
        bases = get_generic_bases(cls)
        args = tuple(_get_parameter_types(base) for base in bases)[0]

    return args


def as_primitive(value: "Union[Integer, Float, String, Boolean]"):
    if isinstance(value, rvai.types.Integer):
        return int(value)
    elif isinstance(value, rvai.types.Float):
        return float(value)
    elif isinstance(value, rvai.types.String):
        return str(value)
    elif isinstance(value, rvai.types.Boolean):
        return bool(value)

    raise ValueError(f"No primitive defined for {value.type_name()}")


# https://github.com/python/typing/issues/684
ELLIPSIS = Any


def as_numpy_slice(slice_string: str) -> Union[slice, int]:
    """Convert slice string notation to actual slice.

    Examples:

        "1"     -> 1
        "1:1"   -> slice(1, 1, None)
        "1:1:1" -> slice(1, 1, 1)


    :return: slice
    :rtype: Union[slice, int]
    """

    parts = slice_string.split(":")

    if len(parts) > 1:
        return slice(
            *(int(part) if part.strip() != "" else None for part in parts)
        )
    else:
        return int(slice_string)


def as_numpy_index(
    index: Union[str, int],
) -> Tuple[Union[ELLIPSIS, slice, int], ...]:

    """Creates a numpy ndarray index based on a string representation
    of that index.

    For example:
        "1:2, 1" becomes (slice(start=1, end=2, step=None), slice(start=None, stop=1, step=None))

    For string values numpy conventions are followed:
    https://numpy.org/doc/1.19/reference/arrays.indexing.html

    Integer values are assumed to be indexing the last dimension.

    :raises ValueError: On receiving an invalid index string
    :return: the index
    :rtype: Tuple[slice]
    """

    try:

        # if only one integer is provided, we assume it's for the last dimension
        # THIS IS DIFFERENT FROM THE NUMPY CONVENTION!
        if isinstance(index, (int, float)):
            return tuple((..., index))
        else:
            return tuple(
                (
                    as_numpy_slice(slice_string)
                    for slice_string in index.split(",")
                )
            )

    except:
        raise ValueError(f"Invalid index string.")
