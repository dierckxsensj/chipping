import json
import shutil
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import (
    Dict,
    Generic,
    KeysView,
    List,
    Optional,
    Tuple,
    Type,
    TypeVar,
    Union,
    ValuesView,
)

from rvai.types import BaseType
from rvai.types.serialization.artifacts import deserialize

S = TypeVar("S", bound=BaseType)
T = TypeVar("T", bound="JSONDatasetItem")


class SyncStrategy(str, Enum):
    """Enum with possible sync strategies for JSONDataset
    """

    # Keep everything on disk in sync with the dataset in memory
    ALWAYS = "ALWAYS"
    # Only update the disk contents when `flush` is called or the dataset is
    # closed.
    LAZY = "LAZY"


@dataclass
class JSONDatasetItem(Generic[S]):
    """Item in a JSONDataset

    :param input_sample: The input sample, can be any rvai type
    :param annotations: An optional list of annotations, the annotations can
        be any rvai type. Note that there is a difference between an empty
        list as annotations and `None`. With an empty list the input sample
        will show up in RVAI as annotated with no annotations, with `None` the
        input sample will be shown as not annotated. The former behaviour can
        be desired in for example an object detector where the object is not
        visible in the input sample.
    """

    input_sample: S
    annotations: Optional[List[BaseType]] = None

    def _serialize(self, output_dir: Path) -> Dict:
        if self.annotations is not None:
            return {
                "inputSample": _save_artifacts(self.input_sample, output_dir),
                "annotations": [
                    _save_artifacts(annotation, output_dir)
                    for annotation in self.annotations
                ],
            }

        else:
            return {
                "inputSample": _save_artifacts(self.input_sample, output_dir),
            }

    @classmethod
    def _deserialize(cls: Type[T], metadata: Dict, artifact_dir: Path) -> T:
        sample_metadata = metadata.get("inputSample")
        assert sample_metadata is not None, "Corrupted sample metadata"
        annotations_metadata = metadata.get("annotations")

        # read sample
        sample: S = deserialize(
            sample_metadata, _load_artifacts(sample_metadata, artifact_dir),
        )

        # read annotations
        if annotations_metadata is None:
            return cls(sample, None)
        else:
            annotations = []
            for annotation_metadata in annotations_metadata:
                annotation = deserialize(
                    annotation_metadata,
                    _load_artifacts(annotation_metadata, artifact_dir),
                )
                annotations.append(annotation)
            return cls(sample, annotations)


def _load_artifacts(metadata: Dict, artifact_dir: Path) -> Dict:
    resources: Optional[dict] = metadata.get("resources")
    assert resources is not None
    artifacts = {}
    for key, file_name in resources.items():
        file_path = artifact_dir / file_name

        with file_path.open("rb") as f:
            artifacts[key] = f.read()
    return artifacts


def _save_artifacts(to_save: BaseType, output_dir: Path) -> Dict:
    metadata, artifacts = to_save.to_artifacts()
    resources = {}
    for key, artifact in artifacts.items():
        ext = (
            f".{artifact.extension}"
            if artifact.extension is not None
            and artifact.extension != "json"  # FIXME: RA-1381 Workaround
            else ""
        )

        file_name = f"{key}{ext}"
        file_path = output_dir / file_name

        with file_path.open("wb") as f:
            f.write(artifact)

        resource_key = metadata["resources"][key][2:-1]
        resources[resource_key] = file_name
    metadata_file = metadata.render(resources)
    return json.loads(metadata_file.encode())


class JSONDatasetIterator(Generic[S]):
    """Iterator over a JSONDataset"""

    def __init__(self, items: List[Tuple[Path, Dict]]):
        self.items = items

    def __getitem__(
        self, index: Union[int, slice]
    ) -> Union[JSONDatasetItem, List[JSONDatasetItem]]:
        if isinstance(index, slice):
            return [
                JSONDatasetItem._deserialize(
                    self.items[i][1], self.items[i][0]
                )
                for i in range(len(self))[index]
            ]

        return JSONDatasetItem._deserialize(
            self.items[index][1], self.items[index][0]
        )

    def __iter__(self) -> "JSONDatasetIterator":
        self.n = 0
        return self

    def __next__(self) -> JSONDatasetItem:
        if self.n < len(self.items):
            result = self[self.n]
            self.n += 1
            assert isinstance(result, JSONDatasetItem)
            return result
        else:
            raise StopIteration

    def __len__(self) -> int:
        return len(self.items)


class JSONDataset(Generic[S]):
    """A Dataset to save and load samples in the json dataset format."""

    def __init__(
        self,
        output_dir: Path,
        sync_strategy: SyncStrategy = SyncStrategy.ALWAYS,
    ):
        """
        :param output_dir: A path to a directory where the data will be saved
            or that contains a valid json dataset
        :param sync_strategy: The strategy used to sync the dataset in memory
            and the dataset on disk
        """
        self.output_dir = output_dir
        self.items: List[Dict] = []
        self.sub_datasets: Dict[str, JSONDataset[S]] = {}
        self.sync_strategy = sync_strategy
        self.open = True
        self.dirty = False
        self.output_dir.mkdir(exist_ok=True, parents=True)
        self._load()

    def __repr__(self) -> str:
        return (
            f"JSONDataset(output_dir={repr(self.output_dir)}, "
            f"sync_strategy={repr(self.sync_strategy)})"
        )

    def __len__(self) -> int:
        return len(self.items) + sum(
            [len(ds) for ds in self.sub_datasets.values()]
        )

    def __contains__(self, dataset_name: str) -> bool:
        return dataset_name in self.sub_datasets

    def __getitem__(self, dataset_name: str) -> "JSONDataset[S]":
        if dataset_name in self:
            return self.sub_datasets[dataset_name]
        else:
            return self.add_subdataset(dataset_name)

    def __delitem__(self, dataset_name: str) -> None:
        self[dataset_name].close()
        shutil.rmtree(self[dataset_name].output_dir)
        del self.sub_datasets[dataset_name]

    def __enter__(self) -> "JSONDataset[S]":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.close()

    def _load(self) -> None:
        subdirectories = [
            el for el in self.output_dir.iterdir() if el.is_dir()
        ]
        for directory in subdirectories:
            self.sub_datasets[directory.stem] = JSONDataset(
                directory, sync_strategy=self.sync_strategy
            )
        data_json = self.output_dir / "data.json"
        if data_json.exists():
            with data_json.open("r") as data:
                self.items = json.load(data)

    def _validate_dataset_name(self, dataset_name: str) -> None:
        if dataset_name in self.sub_datasets:
            raise ValueError(
                "Subdataset already exists. If you want to overwrite it call "
                "`remove_dataset()` first."
            )
        try:
            dataset_path = self.output_dir / dataset_name
            dataset_path.mkdir(exist_ok=True, parents=True)
        except Exception:
            raise ValueError(
                "Illegal dataset name, keep in mind a directory needs to be "
                "created with this name."
            )

    def iterator(self) -> JSONDatasetIterator:
        """Return an iterator

        :return: An iterator over all the items in this dataset and subdatasets
        :rtype: JSONDatasetIterator
        """
        allitems = [(self.output_dir, item) for item in self.items]
        for ds in self.sub_datasets.values():
            allitems += ds.iterator().items
        return JSONDatasetIterator(allitems)

    def flush(self) -> None:
        """Flush the metadata to the json files on disk
        """
        for dataset in self.sub_datasets.values():
            dataset.flush()
        if self.dirty:
            with (self.output_dir / "data.json").open("w") as data_json:
                data_json.write(json.dumps(self.items))
            self.dirty = False

    def close(self) -> None:
        """Closes the saver and writes the link json file. If you use the
        saver outside of a `with` statement you should manually call this
        method.
        """
        self.flush()
        self.open = False

    def save_item(self, item: JSONDatasetItem[S]) -> int:
        """Save a sample and its annotations.

        :param item: The item to save
        :type item: JSONDatasetItem[S]
        :raises ValueError: If the dataset has been closed
        :return: The index of the saved sample in this dataset, can be used to
            retrieve the item via `load_item()`
        :rtype: int
        """
        if not self.open:
            raise ValueError(
                "Can't save samples: this dataset has been closed"
            )
        self.items.append(item._serialize(self.output_dir))
        self.dirty = True
        if self.sync_strategy == SyncStrategy.ALWAYS:
            self.flush()
        return len(self.items) - 1

    def load_item(self, index: int) -> JSONDatasetItem[S]:
        """Load an item from the dataset. It is generally discouraged to use
        this method. It is better to use the `iterator()` to get an iterator
        over the full dataset

        :param index: The index of the item
        :type index: int
        :raises ValueError: If the dataset has been closed
        :return: The loaded item
        :rtype: JSONDatasetItem[S]
        """
        if not self.open:
            raise ValueError(
                "Can't load samples: this dataset has been closed"
            )
        return JSONDatasetItem._deserialize(self.items[index], self.output_dir)

    def add_subdataset(self, dataset_name: str) -> "JSONDataset[S]":
        """Add a subdataset to this dataset

        :param dataset_name: The name of the subdataset
        :type dataset_name: str
        :return: The add subdataset
        :rtype: JSONDataset[S]
        """
        self._validate_dataset_name(dataset_name)
        self.sub_datasets[dataset_name] = JSONDataset(
            self.output_dir / dataset_name, self.sync_strategy
        )
        return self[dataset_name]

    def remove_subdataset(self, dataset_name: str) -> None:
        """Remove a subdataset of this dataset

        :param dataset_name: The name of the subdataset
        :type dataset_name: str
        """
        del self[dataset_name]

    def get_subdataset(self, dataset_name: str) -> "JSONDataset[S]":
        """Get a subdataset of this dataset, if the dataset with this name
        does not exist, it returns a KeyError.

        :return: The JSONDataset object of the subdataset
        :rtype: JSONDataset[S]
        """
        return self.sub_datasets[dataset_name]

    def keys(self) -> KeysView[str]:
        """Return all subdataset names

        :return: An iterable with the subdataset names
        :rtype: KeysView[str]
        """
        return self.sub_datasets.keys()

    def values(self) -> "ValuesView[JSONDataset[S]]":
        """Return all subdatasets

        :return: An iterable with subdatasets
        :rtype: ValuesView[JSONDataset[S]]
        """
        return self.sub_datasets.values()
