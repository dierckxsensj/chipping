import os
import tempfile
import uuid
from enum import Enum
from typing import Dict, Type as _Type, Union

from rvai.types import Optional, Type
from rvai.types.types.optional import Null
from rvai.types.types.placeholder import Placeholder


class Empty:
    pass


class UpdatePolicy(Enum):
    USE_PREVIOUS_IF_NOT_PROVIDED = 1


def get_type_kwargs(T: Type):
    return T.__annotations__


def is_optional(T: Type):

    if (
        hasattr(T, "__origin__")
        and T.__origin__ == Union  # type: ignore
        and type(None in T.__args__)  # type: ignore
    ):
        return True

    elif T == Optional:
        return True

    return False


def get_none(T):
    if T == Optional:
        return Null
    else:
        return None


def assert_correct_type(value: Type, T: _Type[Type]):
    # TODO: don't pls
    return True


class CacheItem:
    def __init__(
        self, value: Union[_Type[Empty], Type], path: Optional[str] = None
    ):
        self.value = value
        self.path = path


def assert_not_empty(name: str, T: Type, cache_item: CacheItem):
    if cache_item.value is Empty:
        raise ValueError(
            f"No value provided for required attribute with name {name} and type {T}.\n"
            f"Could not use a previous (shared) value either. Cache is empty."
        )


class FilesystemDataset:
    def __init__(self, sample_type, base_path=None):

        self.sample_type = sample_type
        self.sample_type_kwargs = get_type_kwargs(sample_type)

        self.shared_resources_policies: Dict[str, UpdatePolicy] = {}
        self.shared_resource_cache: Dict[str, Optional[CacheItem]] = {}

        self.base_path = (
            base_path
            if base_path is not None
            else tempfile.mkdtemp(prefix="rvai.types_")
        )
        self.samples_directory = "samples"
        self.resources_directory = "resources"

    def mark_as_shared(
        self,
        attribute_name: str,
        update_policy=UpdatePolicy.USE_PREVIOUS_IF_NOT_PROVIDED,
    ):
        self.shared_resources_policies[attribute_name] = update_policy
        self.shared_resource_cache[attribute_name] = CacheItem(  # type: ignore
            Empty
        )
        return self

    def _update_cache_according_to_policy(self, attribute, value, path):

        policy = self.shared_resources_policies.get(attribute, None)
        if policy == UpdatePolicy.USE_PREVIOUS_IF_NOT_PROVIDED:
            self.shared_resource_cache[attribute].value = value
            self.shared_resource_cache[attribute].path = path

        elif policy is None:
            return

        else:
            raise ValueError(
                f"Unknown update policy for attribute {attribute} of type {self.sample_type}"
            )

    def _create_sample_from_kwargs(self, **provided):

        obj = {}
        for attribute, T in self.sample_type_kwargs.items():
            # attribute is provided
            if attribute in provided:
                value = provided.get(attribute)
                assert_correct_type(value, T)
                path = self._write_to_disk(value)
                self._update_cache_according_to_policy(attribute, value, path)
                obj[attribute] = value
                continue
            # attribute is missing
            else:
                # it's is optional: everything is fine
                if is_optional(T):
                    obj[attribute] = get_none(T)
                    continue

                # it's required: check if in cache
                else:
                    cached_value = self.shared_resource_cache.get(
                        attribute, Empty
                    )
                    assert_not_empty(attribute, T, cached_value)
                    obj[attribute] = Placeholder(location=cached_value.path)
                    continue

        return self.sample_type(**obj)

    def _write_to_disk(self, obj):

        path = os.path.join(self.base_path, f"{uuid.uuid4()}.msgpack")
        with open(path, "wb") as f:
            f.write(obj.to_msgpack())
        return path

    def write_sample(self, *_, **kwargs):

        obj = self._create_sample_from_kwargs(**kwargs)
        metadata, artifacts = obj.to_artifacts()

        return metadata

    def flush(self):
        pass
