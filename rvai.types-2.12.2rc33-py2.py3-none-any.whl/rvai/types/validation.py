from typing import Union

from typing_extensions import Literal

from rvai.types.types.placeholder import Placeholder

ERROR_MSG = lambda attribute, expected_type, value: (
    f"Wrong type for argument <{attribute}>.\n"
    f"Expected type {expected_type}, but got type {type(value)}."
)


class ValidationError(ValueError):
    pass


def try_cast_attribute(obj, attribute, value, expected_type):

    # If it is a generic type, just typecheck the origin for now.
    # TODO: better type checking
    if (
        hasattr(expected_type, "__origin__")
        and expected_type.__origin__ is not None
    ):
        expected_type = expected_type.__origin__

    if (
        isinstance(expected_type, type(Literal))
        and value in expected_type.__values__
    ):
        return

    if isinstance(value, Placeholder):
        return

    if isinstance(value, expected_type):
        return

    try:
        setattr(obj, attribute, expected_type(value))
    except Exception:
        raise TypeError(ERROR_MSG(attribute, expected_type, value))


def validate(obj):
    if hasattr(obj, "__annotations__"):
        for attribute, expected_type in obj.__annotations__.items():
            value = getattr(obj, attribute, None)
            origin = getattr(expected_type, "__origin__", None)

            if origin is None:
                try_cast_attribute(obj, attribute, value, expected_type)

            if origin is Union:
                if value is None and type(None) in expected_type.__args__:
                    return

                for expected_inner_type in expected_type.__args__:
                    try:

                        if hasattr(expected_inner_type, "__constraints__"):
                            for (
                                constraint
                            ) in expected_inner_type.__constraints__:
                                try_cast_attribute(
                                    obj, attribute, value, constraint
                                )
                                break
                            break
                        else:
                            try_cast_attribute(
                                obj, attribute, value, expected_inner_type
                            )
                            break
                    except TypeError:
                        pass
                else:
                    raise TypeError(
                        ERROR_MSG(
                            attribute,
                            ", ".join(
                                repr(arg) for arg in expected_type.__args__
                            ),
                            value,
                        )
                    )
