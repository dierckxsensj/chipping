import ast
import inspect

import astor

from rvai.types import LUT

FAST = {
    "IMAGE_FAKE_SHAPE": (3, 3, 3),
    "NDARRAY_FAKE_SHAPE": (3, 3, 3),
    "VISIT_TYPE_LIST_AMOUNT": 2,
    "VISIT_TYPE_DICT_AMOUNT": 2,
}


def is_record_type(T):
    return getattr(T, "__rvai_type__", None) == "record"


def is_primitive_type(T):
    return getattr(T, "__rvai_type__", None) == "primitive"


def get_module_and_node(T, source):

    module = ast.parse(source)

    for node in ast.walk(module):
        if not isinstance(node, ast.ClassDef):
            continue
        if node.name == T.type_name():
            return module, node

    raise Exception(f"{T.type_name()} does not exist")


def update_docstring(node, docstring):

    existing_docstring = ast.get_docstring(node)
    if existing_docstring is not None:
        # Assumes the existing docstring is the first node
        # in the function body.
        node.body[0] = docstring
    else:
        node.body.insert(0, docstring)

    return node


def create_docstring(T, node):

    params = []
    for statement in node.body:
        if isinstance(statement, ast.AnnAssign):
            annotation = astor.to_source(statement.annotation).strip()
            value = (
                None
                if statement.value is None
                else astor.to_source(statement.value).strip()
            )
            default = f", defaults to {value}" if value else ""
            ivar = f":ivar {statement.target.id}: a :class:`{annotation}` object{default}"
            itype = f":type {statement.target.id}: {annotation}"
            params.append(ivar)
            params.append(itype)
    params_str = "\n    ".join(params)

    content = f"""{T.type_name()} Data Type

    {params_str}
    """
    return ast.Expr(value=ast.Str(content))


def write_docstrings():

    for T in LUT.values():

        filepath = inspect.getfile(T)
        with open(filepath, "r") as f:
            source = f.read()

        print("=" * 79)
        print(f"Generating docstring for type {T}")
        print(f"file: {filepath}")
        print("=" * 79)

        if is_record_type(T):

            module, node = get_module_and_node(T, source)
            docstring = create_docstring(T, node)
            update_docstring(node, docstring)

            source = astor.to_source(module)

        elif is_primitive_type(T):
            pass

        with open(filepath, "w") as f:
            f.write(source)


if __name__ == "__main__":
    write_docstrings()
