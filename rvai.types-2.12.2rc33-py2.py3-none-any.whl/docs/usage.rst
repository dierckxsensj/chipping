=====
Usage
=====

To use RVAI SDK in a project::

    import rvai.base
