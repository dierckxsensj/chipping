import logging
from data_exporter import *

BASE_URL = 'https://highstreet.robovision.ai/'
BASE_USER = 'admin'
MINIO_URL = 'https://minio1.highstreet.robovision.ai/'
BASE_PASSWORD = 'bumpyfoot76'

minio_client = MinioClient(minio_server_url=MINIO_URL,
                            minio_access_key='robovision',
                            minio_secret_key='robovision')


dataset_client = DatasetPipelineClient(
        rvai_base_url=BASE_URL,
        rvai_account=BASE_USER,
        rvai_password=BASE_PASSWORD,
        num_threads = 5,
        loglevel = logging.WARNING,
    )

LABEL_SESSION = 'pallet_detection_202102'
SAVE_FOLDER = '/tmp/highstreet'

dataset_client.export_label_session(label_session_name=LABEL_SESSION,
                            folder=SAVE_FOLDER,
                            sample_count=50,
                            include_samples=True,
                            allow_empty_annotations=False)

# 
# DO STUFF WITH data.json
#

LABEL_SESSION = 'tmp'
BUCKET_NAME = 'tmp-20210408'
DATASET_NAME = 'tmp'

dataset_client.import_label_session(label_session_name=LABEL_SESSION,
                            folder=SAVE_FOLDER,
                            minio_client=minio_client,
                            bucket_name=BUCKET_NAME,
                            dataset_name=DATASET_NAME,
                            input_sample_type='Image',
                            json_path='/data.json')