import json
import os
from pathlib import Path
from shutil import copyfile
from typing import List

from pycocotools.coco import COCO
from rvai.types import (
    BaseType,
    BoundingBox,
    Class,
    Image,
    Integer,
    Mask,
    String,
)
from rvai.types.types.point import Point

from data_exporter.helpers import (
    cats_from_json,
    get_resources,
    rvai_obj_to_json,
)

from .coco_helper import create_annotation_info


class COCODataset:
    @classmethod
    def _mask_to_coco(cls, mask, image_id, annotation_id):
        category_id = mask.get_class().class_uuid
        return create_annotation_info(
            annotation_id, image_id, {"id": category_id, "is_crowd": 0}, mask
        )

    @classmethod
    def _bbox_to_coco(cls, bbox, image_id, annotation_id):
        # "bbox" :[x,y,width,height]
        x, y, x2, y2 = bbox.p1.x, bbox.p1.y, bbox.p2.x, bbox.p2.y
        w, h = x2 - x, y2 - y
        coco_bbox = [x, y, w, h]
        area = w * h
        category_id = bbox.get_class().class_uuid

        coco_annotation = {
            "id": annotation_id,
            "bbox": coco_bbox,
            "image_id": image_id,
            "ignore": 0,
            "area": area,
            "iscrowd": 0,
            "category_id": category_id,
        }
        return coco_annotation

    @classmethod
    def _sample_to_coco(
        cls, image_id, last_annotation_id, rvai, base_folder, target_folder
    ):
        input_sample = rvai["inputSample"]

        resources = get_resources(input_sample, base_folder)
        rvai_image = BaseType.from_artifacts(input_sample, resources)

        filename = list(input_sample["resources"].values())[0]

        attributes = rvai_image.get_attributes()
        if attributes is not None:
            if "original_id" in attributes:
                image_id = int(attributes["original_id"])
        coco_image = {
            "id": image_id,
            "height": input_sample["data"]["shape"][0],
            "width": input_sample["data"]["shape"][1],
            "file_name": filename,
        }
        copyfile(
            os.path.join(base_folder, filename),
            os.path.join(target_folder, filename),
        )

        coco_annotations = []
        ann_id = last_annotation_id
        for i, rvai_annotation in enumerate(rvai["annotations"]):
            resources = get_resources(rvai_annotation, base_folder)
            rvai_obj = BaseType.from_artifacts(rvai_annotation, resources)

            ann_id = ann_id + 1

            attributes = rvai_obj.get_attributes()
            if attributes is not None:
                if "original_id" in attributes:
                    ann_id = int(attributes["original_id"])

            if type(rvai_obj) == BoundingBox:
                coco_annotation = cls._bbox_to_coco(rvai_obj, image_id, ann_id)
                coco_annotations.append(coco_annotation)
            elif type(rvai_obj) == Mask:
                coco_annotation = cls._mask_to_coco(rvai_obj, image_id, ann_id)
                coco_annotations.append(coco_annotation)
            else:
                raise Exception(
                    f"annotation type {type(rvai_obj)} is not supported"
                )

        return coco_image, coco_annotations, ann_id

    @classmethod
    def _sample_to_rvai(cls, coco_img, base_folder, target_folder):
        rvai_img = Image.from_file(f"{base_folder}/{coco_img['file_name']}")
        rvai_img.set_attributes(
            original_id=Integer(coco_img["id"]),
            original_filename=String(coco_img["file_name"]),
        )
        input_sample = rvai_obj_to_json(rvai_img, target_folder)
        return input_sample, rvai_img.shape

    @classmethod
    def from_rvai(cls, folder: Path, target_folder: Path) -> COCO:
        """
        Returns a COCO object based on an RVAI Dataset folder

        :param folder: source folder
        :param target_folder: target folder for the coco json

        :return COCO (see https://github.com/cocodataset/cocoapi/blob/master/PythonAPI/pycocotools/coco.py)
        """
        with open(f"{folder}/data.json") as f:
            data = json.load(f)
        categories = cats_from_json(data)
        images = []
        annotations: List = []

        if not os.path.exists(target_folder):
            os.makedirs(target_folder)

        image_id = 1
        last_annotation_id = 0
        for item in data:
            (
                coco_image,
                coco_annotations,
                last_annotation_id,
            ) = cls._sample_to_coco(
                image_id, last_annotation_id, item, folder, target_folder
            )
            images.append(coco_image)
            annotations.extend(coco_annotations)

            image_id = image_id + 1

        coco_data = {
            "images": images,
            "categories": categories,
            "annotations": annotations,
        }

        if not os.path.exists(target_folder):
            os.makedirs(target_folder)
        coco_file = f"{target_folder}/coco.json"
        with open(coco_file, "w+") as f:
            json.dump(coco_data, f)
        return COCO(coco_file)

    @classmethod
    def to_rvai(cls, coco: COCO, base_folder: Path, target_folder: Path):
        """
        Converts a COCO object to an RVAI dataset folder

        :param coco: COCO (see https://github.com/cocodataset/cocoapi/blob/master/PythonAPI/pycocotools/coco.py)
        :param base_folder: base folder with COCO data
        :param target_folder: target folder
        """
        categories = coco.loadCats(coco.getCatIds())
        categories = [
            Class(class_uuid=cat["id"], name=cat["name"]) for cat in categories
        ]

        if not os.path.exists(target_folder):
            os.makedirs(target_folder)
        else:
            raise Exception("target folder already exists")

        final_annotations = []
        for imgId in coco.getImgIds():
            coco_img = coco.loadImgs([imgId])[0]
            input_sample, (width, height, _) = cls._sample_to_rvai(
                coco_img, base_folder, target_folder
            )

            rvai_annotations = []
            for annId in coco.getAnnIds(imgIds=[imgId]):
                coco_ann = coco.loadAnns([annId])[0]
                cat_id = coco_ann["category_id"]
                cat = [
                    cat for cat in categories if cat.class_uuid == str(cat_id)
                ][0]
                if "segmentation" in coco_ann:
                    # This is a hack to deal with a bug on pycocotools
                    # https://github.com/cocodataset/cocoapi/issues/139
                    segmentations = []
                    for seg in coco_ann["segmentation"]:
                        if len(seg) == 4:
                            seg.append(seg[-1])
                        segmentations.append(seg)
                    coco_ann["segmentation"] = segmentations

                    rvai_mask = Mask(coco.annToMask(coco_ann))
                    rvai_mask.set_attributes(
                        original_id=String(annId),
                        original_image_id=String(imgId),
                    )
                    rvai_mask.set_class(cat)
                    rvai_annotations.append(
                        rvai_obj_to_json(rvai_mask, target_folder)
                    )
                elif "bbox" in coco_ann:
                    x, y, width, height = coco_ann["bbox"]
                    bb = BoundingBox(Point(x, y), Point(x + width, y + height))
                    bb.set_attributes(
                        original_id=String(annId),
                        original_image_id=String(imgId),
                    )
                    bb.set_class(cat)
                    rvai_annotations.append(
                        rvai_obj_to_json(bb, target_folder)
                    )
                else:
                    raise Exception("annotation type not supported")

            final_annotations.append(
                {"inputSample": input_sample, "annotations": rvai_annotations}
            )

        with open(f"{target_folder}/data.json", "w+") as rvai_file:
            json.dump(final_annotations, rvai_file)

        return final_annotations
