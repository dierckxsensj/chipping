import logging
import time
from typing import Optional, Tuple
from urllib.parse import urlsplit

import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import HTTPError
from urllib3.util.retry import Retry

logger = logging.getLogger(__name__)


def append_api_path(url: str, api_path: str = "api/v1/") -> str:
    """Appends to given url given or default api_path."""
    if not url.endswith("/"):
        url = f"{url}/"
    if api_path.startswith("/"):
        api_path = api_path[1:]
    if not api_path.endswith("/"):
        api_path = f"{api_path}/"
    if api_path not in url:
        url = f"{url}{api_path}"
    return url


def split_http_url(url: str) -> Tuple[str, str]:
    """Splits given http url in two parts: scheme and rest of url."""
    scheme, *_ = urlsplit(url)

    if scheme not in ("http", "https"):
        raise Exception(f"URL [{url}] must start with 'http' or 'https'")

    return scheme, url[len(scheme) + 3 :]


_default_config = {
    "timeout": 120,
    "ssl_verify": True,
    "retry_params": {
        "total": 5,
        "connect": 3,
        "read": 3,
        "status": 3,
        "backoff_factor": 0.5,
        "status_forcelist": (500, 502, 503, 504),
    },
}


class RequestHelper:
    def __init__(self, api_url: str) -> None:
        """
        HTTP Client with retry mechanism.

        :param api_url: e.g.: http://localhost:8080/api/v1/
        """
        self._api_url = api_url if api_url.endswith("/") else f"{api_url}/"

        config = _default_config
        self._timeout: int = config.get("timeout")  # type: ignore
        self._ssl_verify: bool = config.get("ssl_verify")  # type: ignore
        retry_params: dict = config.get("retry_params", {})  # type: ignore
        self._session: requests.Session = self._get_retry_session(retry_params)
        self._auth_header: dict = {}
        self._user_token: Optional[str] = None

    @staticmethod
    def _get_retry_session(retry_params: dict) -> requests.Session:
        """Creates a session with retries."""
        if retry_params:
            retry = Retry(**retry_params)
            adapter = HTTPAdapter(max_retries=retry)
        else:
            adapter = HTTPAdapter()
        session = requests.Session()
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    def wait_until_task_completes(
        self, task_id: str, query_interval: int = 1
    ) -> None:
        """
        Queries RVAI for the supplied task status and exits once it's done.

        :param task_id: id of a task
        :param query_interval: how often query RVAI for task status, in seconds
        """
        while True:
            task_status = self.get(f"background-tasks/{task_id}")
            logger.info(task_status)

            if task_status.get("status") == "FAILURE":
                exception_message = task_status.get("result")
                raise Exception(exception_message)

            if task_status.get("done"):
                break
            else:
                time.sleep(query_interval)

    def _request(
        self,
        method: str,
        url: str,
        json: dict = None,
        params: dict = None,
        **kwargs,
    ) -> dict:
        """
        Performs http requests and handles errors.

        :param method: 'GET', 'POST', etc.
        :param url: request url
        :param json: request payload
        :param params: query string parameters
        :param kwargs: additional keyword parameters
        """
        url = url if not url.startswith("/") else url[1:]
        headers = {**self._auth_header, **kwargs.get("headers", {})}
        timeout = kwargs.pop("timeout", self._timeout)
        verify = kwargs.pop("verify", self._ssl_verify)

        url = f"{self._api_url}{url}"
        logger.debug(f"Call {url} with method {method}")
        response = self._session.request(
            method=method,
            url=url,
            json=json,
            params=params,
            headers=headers,
            timeout=timeout,
            verify=verify,
            **kwargs,
        )
        try:
            response.raise_for_status()
            response_json: dict = response.json()
            logger.debug(response_json)
            if "taskId" in response_json.keys():
                taskId = response_json["taskId"]
                logger.info(f"Waiting on task {taskId}")
                self.wait_until_task_completes(taskId)
            return response_json
        except HTTPError:
            raise Exception(
                f"Request failed with status_code {response.status_code} and content {response.json()}"
            )
        except Exception as e:
            logger.error(e)
            raise Exception("Failed to un-jsonify response from url")

    def request(self, *args, **kwargs) -> dict:
        return self._request(*args, **kwargs)

    def set_authorization_header(self, user_token: str) -> None:
        self._user_token = user_token
        if user_token is None:
            self._auth_header = {}
        else:
            self._auth_header = {"Authorization": f"Bearer {user_token}"}

    def post(self, url_path: str, json: dict, **kwargs) -> dict:
        return self._request(method="POST", url=url_path, json=json, **kwargs)

    def get(self, url_path: str, **kwargs) -> dict:
        return self._request(method="GET", url=url_path, **kwargs)

    def delete(self, url_path: str, **kwargs) -> dict:
        return self._request(method="DELETE", url=url_path, **kwargs)

    def patch(self, url_path: str, json: dict, **kwargs) -> dict:
        return self._request(method="PATCH", url=url_path, json=json, **kwargs)

    def put(self, url_path: str, json: dict, **kwargs) -> dict:
        return self._request(method="PUT", url=url_path, json=json, **kwargs)
