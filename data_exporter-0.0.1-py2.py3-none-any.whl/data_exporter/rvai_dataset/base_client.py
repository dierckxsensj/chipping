import glob
import logging
import os
import shutil
import tempfile
from typing import List

from rvai.types import (
    BaseType,
    BoundingBox,
    Class,
    Image,
    Integer,
    Mask,
    String,
    Type,
)

from data_exporter.helpers import (
    cats_from_json,
    get_minio_relative_path,
    get_resources,
    recursively_copy,
    replace_extension,
    rvai_obj_to_json,
)

from .api_client import APIClient

logger = logging.getLogger(__name__)


class DatasetClient:
    def __init__(
        self,
        rvai_base_url: str,
        rvai_account: str = "admin",
        rvai_password: str = "admin",
        num_threads: int = 5,
        loglevel: int = logging.WARNING,
    ):
        """
        RVAI API Client.

        :param rvai_base_url:
            e.g.: http://localhost:8080 or
                  https://rel302.rvai.robovision.ai

        :param rvai_account: 'admin'

        :param rvai_password: 'admin'
        :param num_threads: the amount of threads to use in case of multithreading
        """
        self._client = APIClient(rvai_base_url, rvai_account, rvai_password)
        self.num_threads = num_threads
        self.user_name = rvai_account
        self.labeler_collection_ids: List[int] = list()

        logging.basicConfig(level=loglevel)

    def delete_storage_folder(self, bucket_name: str,) -> None:
        response = self._client.get_s3_subresource(bucket_name)
        if response is not None:
            storage_id = response["id"]
            self._client.delete_s3_subresource(storage_id)

    # private methods
    def _shared_task(self, sample, annotations, folder, user_id_to_name):
        """
        Save artifacts to disk and returns a JSON with all metadata
        """
        # construct sample json and save artifacts.  use temp dir due to threading overlap
        sample_json = {}
        tmpdir = tempfile.mkdtemp()

        if sample is not None:
            data = rvai_obj_to_json(sample, tmpdir)

            # rename sample
            if (
                "server_filename" in sample.get_attributes().keys()
                and type(sample) == Image
            ):
                try:
                    filename = sample.get_attributes()["server_filename"]

                    filename = replace_extension(
                        file_name=get_minio_relative_path(filename), ext="png",
                    )

                    for k, v in data["resources"].items():
                        if ".png" in v:
                            try:
                                os.makedirs(
                                    os.path.dirname(
                                        os.path.join(tmpdir, filename)
                                    )
                                )
                            except:
                                pass

                            src = os.path.join(tmpdir, v)
                            dst = os.path.join(tmpdir, filename)
                            logger.info(
                                "transfering from %s to %s" % (src, dst)
                            )
                            shutil.move(src, dst)
                            data["resources"][k] = filename
                except Exception as e:
                    logger.error(e)
                    logger.error(sample.get_attributes()["server_filename"])

            sample_json["inputSample"] = data

        final_annotations = dict()
        for labeler_id, v in annotations.items():
            annotations_for_user = []
            for annotation in v:
                # corrupt annotations with Class.name = None
                # even though class_uuid is valid
                # they can't be used, so should be excluded ...
                # still leaves the issue that there will be a lot of images without
                # annotations, which may cause training problems

                if annotation.get_class() is None:
                    logger.warning("found an annotation without class")
                    continue

                if annotation.get_class().name is None:
                    class_uuid = annotation.get_class().class_uuid

                    cat = Class(class_uuid=class_uuid, name=class_uuid,)
                    annotation.set_class(cat)

                data = rvai_obj_to_json(annotation, tmpdir)
                annotations_for_user.append(data)

            logger.info("labeler id %s" % labeler_id)
            if labeler_id in user_id_to_name:
                user_name = user_id_to_name[labeler_id]
            else:
                user_name = "admin"

            final_annotations[user_name] = annotations_for_user

        sample_json["annotations"] = final_annotations

        # copy all files to the target directory
        for filename in glob.glob(os.path.join(tmpdir, "*.*")):
            if os.path.isfile(filename):
                shutil.copy(filename, folder)
        recursively_copy(
            root_src_dir=tmpdir, root_target_dir=str(folder),
        )

        return sample_json
