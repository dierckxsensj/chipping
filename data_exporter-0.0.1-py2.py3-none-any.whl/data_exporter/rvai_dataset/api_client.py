import logging
from typing import Any, Dict, Iterable, List, Optional, Tuple, Union
from uuid import UUID

import requests
from rvai.types import BaseType, String, Type

from .api_helpers import RequestHelper, append_api_path, split_http_url
from .tcp_modes import CurrentMode

logger = logging.getLogger(__name__)


class APIClient:
    def __init__(
        self,
        rvai_base_url: str,
        rvai_account: str = "admin",
        rvai_password: str = "admin",
    ):
        """
        RVAI API Client.

        :param rvai_base_url:
            e.g.: http://localhost:8080 or
                  https://rel302.rvai.robovision.ai

        :param rvai_account: 'admin'

        :param rvai_password: 'admin'
        """

        rvai_schema, rvai_url = split_http_url(rvai_base_url)

        self.requests = RequestHelper(append_api_path(rvai_base_url))
        self._login(rvai_account, rvai_password)

    # GET functions
    def get_users(self) -> List[Dict]:
        """Get all existing users."""
        response = self.requests.get("users")
        return response["manage"]

    def get_label_session_info_from_name(
        self, label_session_name: str
    ) -> Dict:
        """pyt
        Get the label session info, based on the name.

        :param label_session_name: label session name to fetch info for
        :return: label session info if the request succeeded
        """
        response = self.requests.get(
            f"label-sessions?name={label_session_name}"
        )
        return response["data"][0]

    def get_pipeline_layouts(self) -> dict:
        """
        Returns an overview of all pipeline layouts or types in the deployment.

        :return: result[layout name] = layout_id
        """
        response = self.requests.get("pipeline-layouts")

        result = {
            layout["name"]: layout["id"]
            for layout in response["pipelineLayouts"]
        }
        return result

    def get_input_samples(
        self,
        tcp_id: int,
        enabled_for_labeling: Optional[Union[bool, int]] = True,
    ) -> List[dict]:
        """
        get all the input samples for a tcp_id

        :param int tcp_id: the ID of the TCP
        :param bool enabled_for_labeling:
            if True, only those enabled for labeling are returned
        """
        response = self.requests.get(
            f"trainable-cell-project/{tcp_id}/input-samples?enabled_for_labeling={enabled_for_labeling}"
        )
        return response["inputSamples"]

    def get_labeler_collection(self, labeler_collection_id: str):
        return self.requests.get(
            f"labeler-collections/{labeler_collection_id}"
        )

    def get_tcp_info_from_name(self, tcp_name: str) -> list:
        """
        Get the trainable cell project (TCP) info, based on the project name.

        :param tcp_name:
            e.g.: test_pipeline
        """
        response = self.requests.get(
            "pipeline-instances?name={}".format(tcp_name)
        )
        return response["instances"]

    def get_tcp_info_from_id(self, trainable_cell_project_id) -> dict:
        """
        get the trainable cell project (TCP) info, based on the project id.
        :param int trainable_cell_project_id: the project id to fetch info for
        :return: TCP info if the request succeeded
        """
        response = self.requests.get(
            "trainable-cell-project/{}".format(trainable_cell_project_id)
        )
        return response

    def get_s3_subresource(self, resource_name: str) -> Optional[dict]:
        """
        Get the S3 subresource with the specified name.

        :param resource_name:
            e.g.: test_resource
        """
        s3_resources = self.get_list_of_s3_subresources()
        s3_subresources = [
            resource
            for resource in s3_resources
            if resource["bucket"] == resource_name
        ]
        if len(s3_subresources) > 0:
            return s3_subresources[0]
        else:
            return None

    def get_list_of_s3_subresources(self) -> List[Dict]:
        """
        A subresource: A bucket/parent folder combo owned by an S3 account.

        :return: a list of available subresources.
        """
        response = self.requests.get("s3-subresources")
        return response["s3_subresources"]

    def get_s3_annotation_subresource(
        self, resource_name: str = "annotations"
    ) -> Dict:
        """
        Get the S3 annotation subresource based on the bucket name

        :param resource_name: annotations is the default
        """
        s3_resources = self.get_list_of_s3_subresources()
        s3_annotation_subresource = [
            resource
            for resource in s3_resources
            if resource["bucket"] == resource_name
            and resource["storage_content"] == 4
        ]
        return s3_annotation_subresource[0]

    def get_input_sample_indices(
        self,
        tcp_id: int,
        enabled_for_labeling: Optional[Union[bool, int]] = True,
    ) -> List[int]:
        """
        Unwraps the response of 'get_input_samples' to a list of indices.
        :param int tcp_id: the ID of the TCP
        :param bool enabled_for_labeling:
            controls the sample id's to be returned: the samples that are
            enabled (True) or the ones that are disable (False) for labeling.
        :return: the indices of all input samples enabled/disabled for labeling.
        """
        samples = self.get_input_samples(tcp_id, enabled_for_labeling)
        return [s["index"] for s in samples]

    def get_input_sample_info(
        self, tcp_id: int, input_sample_index: int
    ) -> dict:
        """
        get info about the input sample
        :param int tcp_id: the ID of the TCP
        :param int input_sample_index: the ID of the input sample
        :return: input sample info if the request succeeded.
        """
        response = self.requests.get(
            "trainable-cell-project/{}/"
            "input-sample/{}".format(tcp_id, input_sample_index)
        )
        return response

    def get_label_session_input_samples(
        self, session_id: str, annotated: bool = True
    ) -> Optional[Dict]:
        """
        Get all input samples

        :param session_id: id of the session
        :param annotated: if true, only collect annotated samples
        """
        if annotated:
            annotated_query = "?annotated=1"
        else:
            annotated_query = ""

        return self.requests.get(
            f"label-sessions/{session_id}/input-samples{annotated_query}"
        )

    def get_sample_and_annotations(
        self,
        session_id: str,
        input_sample_id: str,
        include_samples: bool = True,
    ) -> Tuple[Any, Any]:
        """
        Get sample and annotations for a specified input_sample_id

        :param session_id: id of the session
        :param input_sample_id: id of the sample to fetch
        :param include_samples: if False do not get samples
        """
        clean_sample: Optional[BaseType]
        if include_samples:
            sample = self.requests.get(
                f"label-sessions/{session_id}/input-samples/{input_sample_id}"
            )
            clean_sample = self.__get_sample_from_response(sample)
        else:
            clean_sample = None

        annotations = self.requests.get(
            f"label-sessions/{session_id}/input-samples/{input_sample_id}/annotations"
        )
        clean_annnotations = self.__get_annotations_from_response(annotations)
        return clean_sample, clean_annnotations

    def get_sample_and_annotations_old(
        self, tcp_id: str, input_sample_id: str, include_samples: bool = True
    ) -> Tuple[Any, Dict[int, List[BaseType]], int]:
        """
        Get sample and annotations for a specified input_sample_id

        :param session_id: id of the session
        :param input_sample_id: id of the sample to fetch
        :param include_samples: if False do not get samples
        """
        clean_sample: Optional[BaseType]
        if include_samples:
            sample = self.requests.get(
                "trainable-cell-project/{}/"
                "input-sample/{}".format(tcp_id, input_sample_id)
            )
            sample_id = sample["inputSampleId"]
            # could download the actual image using sample["labelerData"]["resources"]
            clean_sample = self.__get_sample_from_response(sample)
        else:
            clean_sample, sample_id = None, None

        annotations = self.requests.get(
            f"annotations-v3/all?trainable_cell_project_id={tcp_id}"
            f"&input_sample_index={input_sample_id}"
        )
        clean_annnotations = self.__get_annotations_from_response(annotations)
        return clean_sample, clean_annnotations, sample_id

    def get_class_configurations(self, tcp_id: int) -> dict:
        """
        Returns the class configurations defined in the tcp.
        """
        response = self.requests.get(
            f"trainable-cell-projects/{tcp_id}/class-configurations"
        )
        return response

    # CREATE functions
    def create_dataset(
        self,
        s3_annotation_subresource_id: str,
        s3_subresource_id: str,
        dataset_name: str,
        inputSampleType: str,
    ) -> str:
        # create the dataset
        json = {
            "annotationS3SubresourceId": s3_annotation_subresource_id,
            "inputSamplesS3SubresourceId": s3_subresource_id,
            "inputSampleType": inputSampleType,
            "name": dataset_name,
        }
        response = self.requests.post("datasets", json)
        return response["data"]["id"]

    def create_label_session(
        self,
        dataset_id: str,
        s3_subresource_id: str,
        class_strategy: str,
        json_path: str,
    ):
        # create the label session
        json = {
            "classStrategy": class_strategy,
            "inputS3SubresourceId": s3_subresource_id,
            "json": [json_path],
        }
        response = self.requests.post(
            f"datasets/{dataset_id}/ingest-input-samples2", json
        )
        logger.info("Done ingesting input samples")

    def create_training_pipeline(
        self, project_name: str, layout_id: int
    ) -> Tuple[int, int]:
        """
        creates a training pipeline for the given project
        :param project_name:
        :param layout_id:
        :return: pipeline_instance_id, tcp_id
        """
        create_pipeline_request_json = dict(
            name=project_name,
            pipelineLayoutId=layout_id,
            # visible=True        # comment for newest version of 3.1
        )
        response = self.requests.post(
            "pipeline-instances", create_pipeline_request_json
        )
        pipeline_instance_id = response["pipelineInstanceId"]
        tcp_id = response["generatedTrainableCellProjects"][0]["id"]
        return pipeline_instance_id, tcp_id

    def create_labeler_collection(
        self, name: str, annotation_s3_subresource_id: int = 2,
    ) -> int:
        """
        Creates a new labeler collection.

        :param name: labeler collection name
        :param annotation_s3_subresource_id: default 2,
            the 'annotations' bucket on Minio2
        :return: the id of the new labeler collection
        """
        request_json = dict(
            name=name, annotationS3SubresourceId=annotation_s3_subresource_id
        )
        response = self.requests.post("labeler-collections", json=request_json)
        labeler_collection_id = response["labeler_collection_id"]
        logger.info(
            f"Labeler collection '{name}' has been "
            f"created with id {labeler_collection_id}"
        )
        return labeler_collection_id

    def create_s3_subresource_for_bucket(self, bucket_name: str):
        """
        Create a S3 subresource for the bucket

        :param bucket_name: name of the bucket
        """

        if self.get_s3_subresource(resource_name=bucket_name) is not None:
            logger.info(f"Subresource already exists {bucket_name}")
        else:
            request_json = dict(
                accessible_for_all_users=True,
                bucket=bucket_name,
                parent_folder="",
                s3_account=1,  #  1=minio_user, 2=models_minio_user
                storage_content=2,  # StorageContentType.INPUT_SAMPLES
                region="",
            )

            self.requests.post("s3-subresources", json=request_json)

    # DELETE functions
    def delete_dataset(self, dataset_name: str):
        """
        Delete a dataset.  Blocks until task is finished

        :param dataset_name
        """
        datasets = self.requests.get("datasets")
        for dataset in datasets["data"]:
            if dataset["name"] == dataset_name:
                response = self.requests.delete(f"datasets/{dataset['id']}")
                return response

    def delete_label_session(self, label_session_name: str):
        """
        Delete a label session.  Blocks until task is finished

        :param label_session_name
        """
        sessions = self.requests.get("label-sessions")
        for session in sessions["data"]:
            if session["name"] == label_session_name:
                response = self.requests.delete(
                    f"label-sessions/{session['id']}"
                )
                return response

    def delete_training_pipeline(self, pipeline_instance_id: int) -> dict:
        """
        Deletes the training pipeline with the given id.
        Blocks until task is finished
        :param pipeline_instance_id:
        :return:
        """
        response = self.requests.delete(
            "pipeline-instance/{}".format(pipeline_instance_id)
        )
        return response

    def delete_s3_subresource(self, subresource_id: int) -> dict:
        """
        Deletes the S3 subresource pipeline with the given id.
        :param subresource_id:
        :return:
        """
        response = self.requests.delete(
            "s3-subresources/{}".format(subresource_id)
        )
        return response

    # OTHER functions
    def add_labeler_collection_to_tcp(
        self, tcp_id: int, labeler_collection_ids: List[int]
    ) -> None:
        """
        Add a new labeler collections to the trainable cell project
        :param tcp_id: the tcp id
        :param labeler_collection_ids: the/a list of labeler collection id(s)
        :return:
        """
        request_json = dict(labelerCollections=labeler_collection_ids)
        self.requests.put(
            f"trainable-cell-projects/{tcp_id}/labeler-collections",
            json=request_json,
        )
        logger.info(
            f"Labeler collection(s) {labeler_collection_ids} "
            f"have been added to tcp {tcp_id}"
        )

    def patch_mode(self, tcp_id: int, mode: CurrentMode) -> None:
        """
        Change the current mode of the given trainable cell project.
        :param tcp_id:
        :param mode:
        """
        assert type(mode) == CurrentMode

        request_json = dict(currentMode=mode.name)

        response = self.requests.patch(
            "trainable-cell-project/{}/" "mode".format(tcp_id),
            json=request_json,
        )

    def add_tcp_class_configuration(
        self,
        tcp_id: int,
        name: str,
        color: str,
        shape: str,
        supported_item_names: str = "",
        keywords: List = None,
    ) -> Dict:
        """
        Add a new class configuration item to the given tcp.

        :param tcp_id: ID of the trainable cell project.
        :param name: name of the new class configuration item.
        :param color: color of the new class configuration item. Example: "#ff0000"
        :param shape: shape of the new class configuration item. Example: "BoundingBox, "Class", "Mask"
        :param supported_item_names:
        :param keywords:
        :return: the UUID of the class configuration
        """
        keywords = keywords if keywords is not None else []

        self.get_tcp_info_from_id(tcp_id)
        # assert shape in tcp_info["allowedShapes"]

        class_definition = {
            "keywords": keywords,
            "name": name,
            "defaultColor": color,
        }

        new_config_item = {
            "classDefinition": class_definition,
            "color": color,
            "shape": shape,
            "supportedItemNames": supported_item_names != "",
        }

        response = self.requests.post(
            f"trainable-cell-projects/{tcp_id}/class-configurations",
            new_config_item,
        )
        return response["data"]

    def assign_users_or_groups_to_tcp(
        self,
        tcp_id: int,
        users: Optional[List[int]] = None,
        groups: Optional[List[int]] = None,
    ):
        """
        Assign labeler accounts or groups of labeler accounts to this pipeline.

        :param tcp_id:
        :param users: list of user ids
        :param groups: list of group ids
        :return:
        """
        users = [] if users is None else users
        groups = [] if groups is None else groups

        request_json = dict(users=users, groups=groups)
        response = self.requests.put(
            f"trainable-cell-project/{tcp_id}/assignments", request_json
        )
        return response

    def ingest_input_samples(
        self,
        labeler_collection_id: int,
        s3_subresource_id: int,
        tcp_id: int,
        input_samples_list: List[dict],
        check_resources: Optional[bool] = False,
    ) -> dict:
        """
        Ingest input samples in a labeler collection.

        :param labeler_collection_id: id of the labeler collection
        :param s3_subresource_id: id of the bucket/parent_folder combo
        :param tcp_id: id of the trainable cell project
        :param input_samples_list: list of input samples
        :param check_resources: optional flag to check whether
            there are enough resources available
        :return: a task id (string)
        """
        request_json = dict(
            inputS3SubresourceId=s3_subresource_id,
            inputSamples=input_samples_list,
            tcp=tcp_id,
            checkResources=check_resources,
        )
        logger.info("Started ingesting input samples")
        response = self.requests.post(
            f"labeler-collections/{labeler_collection_id}/ingest-input-samples",
            json=request_json,
        )
        logger.info("Done ingesting input samples")
        return response

    def upload_annotations(
        self,
        tcp_id: int,
        input_sample_id: int,
        annotations: List[Type],
        labeler_ui: Optional[str] = "LABELER_V3",
        user_id: Optional[str] = None,
    ) -> None:
        """
        Upload the given annotations and link them to the given sample.

        Accepts a list of rvai.types as annotations. Example: List[BoundingBox].
        Performs both the create- and update API calls, just like the UI.
        Also stores the annotation on the minio in case of Mask annotations.
        """
        if user_id is not None:
            try:
                UUID(user_id)
            except ValueError:
                raise Exception(
                    f"Invalid string supplied for 'user_id': "
                    f"'{user_id}'. Must be a UUID string."
                )
        else:
            user_id = self.user_id

        annotations_with_resources = []
        for annotation in annotations:
            meta, resources = annotation.to_artifacts()
            if len(resources) > 0:
                annotations_with_resources.append(annotation)

        annotations_dict: Dict[int, Any] = dict()
        references: List[int] = []
        if len(annotations_with_resources) > 0:
            resource_refs, references = self._upload_annotation_resources(
                tcp_id=tcp_id,
                input_sample_index=input_sample_id,
                annotations=annotations_with_resources,
                labeler_ui=labeler_ui,
                user_id=user_id,
            )
        annotation_with_resource_idx = 0
        for i, annotation in enumerate(annotations):
            if annotation in annotations_with_resources:
                # handle annotations with resources
                metadata, artifacts = annotation.to_artifacts()
                for k, key in enumerate(artifacts.keys()):
                    metadata["resources"][key] = resource_refs[
                        annotation_with_resource_idx
                    ][k]
                annotation_with_resource_idx += 1
                annotations_dict[i] = metadata
            else:
                # handle annotations without resources
                references = []
                annotations_dict[i + 1] = annotation.to_json_struct()

        self._update_annotation(
            tcp_id=tcp_id,
            input_sample_id=input_sample_id,
            annotations=annotations_dict,
            labeler_ui=labeler_ui,
            user_id=user_id,
            references=references,
        )

    def _update_annotation(
        self,
        tcp_id: int,
        input_sample_id: int,
        annotations: Optional[dict] = None,
        labeler_ui: Optional[str] = "LABELER_V3",
        user_id: Optional[str] = "1",
        references: Optional[List[int]] = None,
    ) -> None:
        """
        Links the annotation to the input sample index.

        for masks: "annotations": {"1": {"type": "Mask",
                        "properties": {"classId": 0, "data": {"$ref": ref}}}},
        :param tcp_id:
        :param input_sample_id:
        :param annotations:
        :param user_id:
        :param references: a list of resource_ids
        :return:
        """
        annotations = {} if annotations is None else annotations
        references = [] if references is None else references

        request_json = dict(
            trainableCellProjectId=tcp_id,
            inputSampleIndex=input_sample_id,
            userId=user_id,
            labelerUi=labeler_ui,
            annotations=annotations,
            references=references,
        )

        response = self.requests.put("annotations-v3", json=request_json)

    def _upload_annotation_resources(
        self,
        tcp_id: int,
        input_sample_index: int,
        annotations: List[Type],
        labeler_ui: Optional[str] = "LABELER_V3",
        user_id: str = "1",
        content_type: Optional[str] = "image/png",
    ) -> Tuple[List[List[str]], List[int]]:
        """
        Upload the resources of the given annotations to S3 and create an RVAI database entry for it,
        linking these resources to the given input sample index.

        :param content_type: currently we set the default value to "image/png",
                            but this could be subject of change
        :param tcp_id:
        :param input_sample_index:
        :param annotations:
        :return:
        """

        # for each annotation, collect all resources
        all_resources: List[List[Tuple[Type, bytes]]] = [
            [] for _ in annotations
        ]
        n_resources = 0
        for i, annotation in enumerate(annotations):
            _, resources = annotation.to_artifacts()
            for resource in resources.values():
                all_resources[i].append((annotation, resource))
            n_resources += len(resources)

        # request resources
        request_json = dict(
            trainableCellProjectId=tcp_id,
            inputSampleIndex=input_sample_index,
            userId=user_id,
            labelerUi=labeler_ui,
            resources=n_resources,
            contentType=content_type,
        )
        response = self.requests.post(
            "annotations-v3/resources", json=request_json
        )

        # upload resources
        references: List[List[str]] = [[] for _ in annotations]
        resource_ids = []

        resource_idx = 0
        for annotation_idx, annotation in enumerate(annotations):
            for resource in all_resources[annotation_idx]:
                resource_descriptor = response["resources"][resource_idx]
                resource_id = resource_descriptor["id"]
                url = resource_descriptor["presignedUrl"]
                ref = resource_descriptor["ref"]
                header = dict()
                header["Content-Type"] = "image/png"
                rsp = requests.put(url, data=resource[1], headers=header)
                assert rsp.status_code == requests.codes.ok, rsp.text
                references[annotation_idx].append(ref)
                resource_ids.append(resource_id)
                resource_idx += 1
        return references, resource_ids

    def _upload_annotation_resources_for_label_session(
        self,
        label_session_id: int,
        input_sample_id: int,
        annotations: List[Type],
        labeler_ui: Optional[str] = "LABELER_V3",
        user_id: str = "1",
    ) -> Tuple[List[List[str]], List[int]]:
        """
        Get references, presigned urls and ids of resources that we can use to upload resources
        linking to given annotations and given input samples
        """

        # for each annotation, collect all resources
        all_resources: List[List[Tuple[Type, bytes]]] = [
            [] for _ in annotations
        ]
        n_resources = 0
        for i, annotation in enumerate(annotations):
            _, resources = annotation.to_artifacts()
            for resource in resources.values():
                all_resources[i].append((annotation, resource))
            n_resources += len(resources)

        content_type = "image/png"
        if type(annotations[0]) == "Mask":
            content_type = "application/x-msgpack"

        # request resources
        request_json = dict(
            userId=user_id,
            labelerUi=labeler_ui,
            resources=n_resources,
            contentType=content_type,
        )
        response = self.requests.post(
            "/label-sessions/%s/input-samples/%s/annotations/resources"
            % (label_session_id, input_sample_id),
            json=request_json,
        )

        # upload resources
        references: List[List[str]] = [[] for _ in annotations]
        resource_ids = []

        resource_idx = 0
        for annotation_idx, annotation in enumerate(annotations):
            for resource in all_resources[annotation_idx]:
                resource_descriptor = response["data"][resource_idx]
                resource_id = resource_descriptor["id"]
                url = resource_descriptor["presignedUrl"]
                ref = resource_descriptor["ref"]
                header = dict()
                header["Content-Type"] = "image/png"
                rsp = requests.put(url, data=resource[1], headers=header)
                assert rsp.status_code == requests.codes.ok, rsp.text
                references[annotation_idx].append(ref)
                resource_ids.append(resource_id)
                resource_idx += 1
        return references, resource_ids

    def __get_sample_from_response(self, response: Dict) -> BaseType:
        """
        Gets the sample from a response
        Converts to RVAI type
        Also fetches the resources
        """
        input_sample_data: Dict
        if "data" in response.keys():
            input_sample_data = response["data"]["labelerData"]
        else:
            input_sample_data = response["labelerData"]

        resources_dict = input_sample_data["resources"]

        resources_context = self.__create_sample_context(resources_dict)

        # validate attrs ...
        attrs = input_sample_data.get("$attributes", None)

        def fix_attr(attr):
            try:
                BaseType.from_json_struct(attr)
                return attr
            except:
                logger.error("Invalid attribute")
                if type(attr["value"]) == str:
                    attr["value"] = String(attr["value"]).to_json_struct()
                    return attr
                else:
                    raise f'Invalid attr with type {type(attr["value"])}.  Conversion not yet implemented'

        if attrs is not None:
            valid_attrs = {k: fix_attr(v) for k, v in attrs["entries"].items()}
            input_sample_data["$attributes"]["entries"] = valid_attrs

        sample = BaseType.from_artifacts(input_sample_data, resources_context)

        # set original name on server as attribute
        server_filename = list(input_sample_data["resources"].values())[0]
        sample.set_attributes({"server_filename": String(server_filename)})

        return sample

    def __get_annotations_from_response(
        self, response: Dict
    ) -> Dict[int, List[BaseType]]:
        """
        Gets all the annotations from a response
        Converts to RVAI type
        Also fetches the resources
        """
        result = dict()  # labeler_id -> list of annotations

        for annotations_per_labeler in response["annotations"]:
            labeler_id = annotations_per_labeler["userId"]
            annotations_dict: Dict = annotations_per_labeler["annotations"]
            resources_list = annotations_per_labeler[
                "resources"
            ]  # is empty without mask
            resources_context = self.__create_annotation_context(
                resources_list, annotations_dict.values()
            )

            labels = [
                BaseType.from_artifacts(v, resources_context)
                for v in annotations_dict.values()
            ]
            result[labeler_id] = labels
        return result

    def _download_resource(self, url) -> bytes:
        """
        Download resource content
        """
        assert url is not None
        resource_response = requests.get(url)
        assert (
            resource_response.status_code == requests.codes.ok
        ), resource_response.text
        return resource_response.content

    def __create_annotation_context(
        self, resources: List[Dict], annotations: Iterable[Dict]
    ) -> dict:
        """
        Fetch the resources for an annotation
        """
        ref_1_to_resource = dict()
        for resource in resources:
            url = resource["presignedUrl"]
            if url is None:
                logger.warning("found an annotation resource with None url")
                continue
            ref_1_to_resource[resource["ref"]] = self._download_resource(url)

        ref_2_to_resource: Dict[str, bytes] = dict()
        for value in annotations:
            if "resources" not in value:
                continue
            ref_2_to_ref_1_mapping = value["resources"]
            for ref_2, ref_1 in ref_2_to_ref_1_mapping.items():
                if ref_1 not in ref_1_to_resource:
                    continue
                ref_2_to_resource[ref_2] = ref_1_to_resource[ref_1]

        return ref_2_to_resource

    def __create_sample_context(self, resources: Dict) -> dict:
        """
        Fetch the resources for a sample
        """
        ref_1_to_resource = dict()
        for resource_ref, url in resources.items():
            if url is None:
                logger.warning("found a sample resource with None url")
                continue
            ref_1_to_resource[resource_ref] = self._download_resource(url)
        return ref_1_to_resource

    def _login(
        self, account: str, password: str, remember: bool = True
    ) -> None:
        """Logs in to RVAI3 deployment with given credentials."""
        body = dict(account=account, password=password, remember=remember)
        response = self.requests.post("login", json=body)
        self.user_token = response["access_token"]
        self.user_id = response["id"]
        self.requests.set_authorization_header(self.user_token)
