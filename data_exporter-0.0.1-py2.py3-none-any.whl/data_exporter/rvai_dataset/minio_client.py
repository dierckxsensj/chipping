import logging
import os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import List

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


def _key_existing_size__head(
    client: boto3.session.Session.client, bucket: str, key: str
):
    """return the key's size if it exist, else None"""
    try:
        obj = client.head_object(Bucket=bucket, Key=key)
        return obj["ContentLength"]
    except ClientError as exc:
        if exc.response["Error"]["Code"] != "404":
            raise


class MinioClient:
    def __init__(
        self,
        minio_server_url: str = "",
        minio_access_key: str = "robovision",
        minio_secret_key: str = "robovision",
        num_threads: int = 5,
    ):
        self.s3_connection = boto3.resource(
            "s3",
            endpoint_url=minio_server_url,
            aws_access_key_id=minio_access_key,
            aws_secret_access_key=minio_secret_key,
        )

        self.s3_client = boto3.client(
            "s3",
            endpoint_url=minio_server_url,
            aws_access_key_id=minio_access_key,
            aws_secret_access_key=minio_secret_key,
        )
        self.num_threads = num_threads

    def _upload_to_bucket(
        self,
        local_file_path: str,
        bucket_file_path: str,
        bucket_name: str,
        force_upload: bool = False,
    ):
        # upload the file only if it does not exist on the bucket
        if (
            _key_existing_size__head(
                self.s3_client, bucket_name, bucket_file_path
            )
            is None
            or force_upload
        ):
            logger.debug(f"uploading {bucket_file_path} now")
            bucket = self.s3_connection.Bucket(bucket_name)
            bucket.upload_file(local_file_path, bucket_file_path)
        else:
            logger.debug(
                f"not uploading {bucket_file_path}, since it already exists in the bucket"
            )

    def create_bucket_and_upload(
        self, bucket_name: str, folder: Path, exclude_exts: List[str] = []
    ):
        """
        Create a bucket and upload data to it

        :param bucket_name: name of the bucket
        :param folder: all files in this folder will be loaded to the bucket
        :param exlude_exts: optional list of extensions to ignore during upload
        """
        if not isinstance(folder, Path):
            folder = Path(folder)

        bucket = self.s3_connection.Bucket(bucket_name)

        if bucket.creation_date is not None:
            logger.info('A bucket named "%s" already exists' % bucket_name)
        else:
            # create bucket
            logger.info("Creating bucket")
            # TODO Why are bucket permission being set as `read only` despite
            # providing `read-write` ACL here?
            self.s3_connection.create_bucket(
                ACL="public-read-write", Bucket=bucket_name
            )
            bucket = self.s3_connection.Bucket(bucket_name)

        # upload to bucket
        logger.info("Upload to bucket")
        local_to_bucket_filepath = dict()
        for src_dir, dirs, files in os.walk(folder):

            for file_ in files:
                # only upload files with relevant extensions like png
                if not check_if_ext_accepted(file_, exclude_exts):
                    continue
                local_file_path = os.path.join(src_dir, file_)

                # Remove the folder.  Don't use lstrip !!
                removal_string = str(folder) + "\\"
                bucket_file_path = local_file_path.replace(removal_string, "")

                local_to_bucket_filepath[local_file_path] = bucket_file_path

        with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
            futures = [
                executor.submit(
                    self._upload_to_bucket,
                    local_file_path=local_file_path,
                    bucket_file_path=bucket_file_path,
                    bucket_name=bucket_name,
                    force_upload=(
                        ".json" in bucket_file_path
                    ),  # always replace jsons
                )
                for local_file_path, bucket_file_path in local_to_bucket_filepath.items()
            ]

        logger.info("Done uploading")

    def delete_bucket(self, bucket_name: str):
        """
        Delete a bucket and everything in it

        :param bucket_name: name of the bucket
        """
        self.s3_connection.Bucket(bucket_name).objects.all().delete()
        self.s3_client.delete_bucket(Bucket=bucket_name)
        logger.info(f"Bucket {bucket_name} deleted")


def check_if_ext_accepted(filename: str, exclude_exts: List[str]) -> bool:
    for ext in exclude_exts:
        if filename.endswith(ext):
            return False

    return True
