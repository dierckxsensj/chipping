import json
import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import List, Optional, Tuple

from rvai.types import (
    BaseType,
    BoundingBox,
    Class,
    Image,
    Integer,
    Mask,
    String,
    Type,
)

from data_exporter.helpers import (
    cats_from_json,
    get_minio_relative_path,
    get_resources,
    replace_extension,
)

from .base_client import DatasetClient
from .minio_client import MinioClient
from .tcp_modes import CurrentMode

logger = logging.getLogger(__name__)


class LegacyPipelineClient(DatasetClient):
    # public methods
    def delete_pipeline(self, pipeline_name: str) -> None:
        """
        deletes the training pipeline with the given pipeline name.
        :param pipeline_name:
        :return:
        """
        tcp_info = self._client.get_tcp_info_from_name(pipeline_name)
        if tcp_info == []:
            logger.info(
                "pipeline with name {} does not exist".format(pipeline_name)
            )
        else:
            if tcp_info is not None:
                tcp0 = tcp_info[0]  # type: ignore
                if tcp0 is not None:
                    tcp_id = tcp0.get("pipelineInstanceId")
                    self._client.delete_training_pipeline(tcp_id)

    def export_pipeline(
        self,
        pipeline_name: str,
        folder: Path,
        sample_count: int = None,
        include_samples: bool = True,
    ) -> None:
        """
        Exports all annotated data from an old style pipeline to a folder.
        The folder is formatted in the format expected by new style datasets.

        :param pipeline_name: name of the pipeline
        :param folder: target folder
        :param sample_count: if not None, specify how many samples to download
        :param include_samples: if False, do not download samples for performance reasons
        """
        if not isinstance(folder, Path):
            folder = Path(folder)

        try:
            os.mkdir(folder)
        except FileExistsError:
            raise Exception(
                f"folder {folder} already exists, please choose a new name"
            )

        user_id_to_name = dict()
        users_list = self._client.get_users()
        for user_item in users_list:
            user_id_to_name[user_item["id"]] = user_item["account"]

        pipelines = self._client.get_tcp_info_from_name(pipeline_name)

        # NOTE There could not be two pipelines with same name.
        # so `pipelines` would always contain one element
        if pipelines == []:
            raise Exception(f"pipeline {pipeline_name} not found")

        pipeline = pipelines[0]
        # TODO There could be more than one generated tcps, so structure
        # the exported folder accordingly. Main folder could contain
        # folders for each tcps and those tcp folders could contain input samples,
        # annotations and labeler collection infos.
        generated_tcps = pipeline["generatedTrainableCellProjects"]
        for generated_tcp in generated_tcps:
            tcp_id = generated_tcp["id"]

            # TODO Should we also be exporting input samples for which
            # label is disabled?
            sample_ids = self._client.get_input_sample_indices(
                tcp_id=tcp_id, enabled_for_labeling=True
            )

            if sample_count is not None:
                sample_ids = sample_ids[:sample_count]
                logger.info(f"only exporting {sample_count} samples ")

            export = []
            with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
                futures = [
                    executor.submit(
                        self._old_export_task,
                        tcp_id=tcp_id,
                        sample=sample_id,
                        folder=folder,
                        include_samples=include_samples,
                        user_id_to_name=user_id_to_name,
                    )
                    for sample_id in sample_ids
                ]
                for fut in as_completed(futures):
                    data, sample_id = fut.result()
                    export.append((data, sample_id))

            # one big JSON
            export_json = [data for (data, sample_id) in export]
            with open(os.path.join(folder, "data.json"), "w") as outfile:
                json.dump(export_json, outfile)

            # Add files for labeller collection infos
            labeler_collections = {}
            for labeler_collection_id in generated_tcp.get(
                "labelerCollections"
            ):
                labeler_collection = self._client.get_labeler_collection(
                    labeler_collection_id
                )
                labeler_collection_samples = [
                    v["id"] for v in labeler_collection["inputSamples"]
                ]
                labeler_collection_name = labeler_collection["info"]["name"]
                labeler_collection_json_path = os.path.join(
                    folder, f"{labeler_collection_name}.json"
                )

                # json per labeler_collection
                export_json_single_collection = [
                    data
                    for (data, sample_id) in export
                    if sample_id in labeler_collection_samples
                ]
                labeler_collections[
                    labeler_collection_name
                ] = labeler_collection_json_path
                with open(labeler_collection_json_path, "w") as outfile:
                    json.dump(export_json_single_collection, outfile)

            with open(
                os.path.join(folder, "labeler_collections.json"), "w"
            ) as outfile:
                json.dump(labeler_collections, outfile)

        return None

    def import_pipeline(
        self,
        folder: Path,
        minio_client: MinioClient,
        pipeline_name: str,
        bucket_name: str,
        pipeline_layout: str,
        users: Optional[List[int]] = None,
        groups: Optional[List[int]] = None,
    ) -> Tuple[int, dict]:
        """
        Import all annotated data and images from a folder to an old style pipeline.
        """
        if not isinstance(folder, Path):
            folder = Path(folder)

        # ----------------------DATA SETUP---------------------------------#
        # TODO Make sure edit policy of minio bucket is read and write
        # Create a pipeline with the right layout
        # try using enums for pipeline layouts
        tcp_id = self._create_pipeline(pipeline_name, pipeline_layout)

        labeler_collection_name_to_id = dict()

        # Let Minio do the work
        # Exclude msgpack.zlib files, since there are annotations, which we handle later on for 6-step pipelines
        # Should be a solid speed-up
        minio_client.create_bucket_and_upload(
            bucket_name=bucket_name,
            folder=folder,
            exclude_exts=[".msgpack.zlib"],
        )
        # Create the subresource
        self._client.create_s3_subresource_for_bucket(bucket_name=bucket_name)

        with open(f"{folder}/data.json") as f:
            data_json = json.load(f)

        try:
            with open(f"{folder}/labeler_collections.json") as f:
                labeler_collections = json.load(f)
        except FileNotFoundError:
            # no labeler_collections.json, use data.json
            labeler_collections = {pipeline_name: f"{folder}/data.json"}

        for labeler_collection_name, json_path in labeler_collections.items():
            with open(json_path) as f:
                labeler_collection_json = json.load(f)

            input_samples_for_this_label_collection = [
                v["inputSample"] for v in labeler_collection_json
            ]

            # Create a label collection and add all samples to it from S3
            labeler_collection_id = self._create_labeler_collection(
                tcp_id=tcp_id,
                bucket_name=bucket_name,
                labeler_collection_name=labeler_collection_name,
                input_samples=input_samples_for_this_label_collection,
                im_ext="png",
            )

            labeler_collection_name_to_id[
                labeler_collection_name
            ] = labeler_collection_id

        # ---------------------USER SETUP---------------------------------#
        # assign users or groups to tcp
        self._client.assign_users_or_groups_to_tcp(tcp_id, users, groups)

        # ---------------------------Labelling Setup-------------------------------------#
        # Add classes to the pipeline based on what is in the data.json
        categories = cats_from_json(data_json)

        existing_classes = self._client.get_class_configurations(tcp_id)[
            "data"
        ]
        category_name_to_class_id = dict()
        for existing_class in existing_classes:
            category_name_to_class_id[
                existing_class["classDefinition"]["name"]
            ] = existing_class["classDefinition"]["id"]

        for category in categories:
            if category["name"] in category_name_to_class_id:
                continue

            response = self._client.add_tcp_class_configuration(
                tcp_id,
                name=category["name"],
                color="#444444",
                shape=category["shape"],
            )

            category_name_to_class_id[category["name"]] = response[
                "classDefinition"
            ]["id"]

        self._client.patch_mode(
            tcp_id=tcp_id, mode=CurrentMode.LABELING_STARTED
        )

        image_name_to_input_sample = dict()
        for item in data_json:
            resources = item["inputSample"]["resources"]
            image_name = [resources[r] for r in resources][0]
            # remove extension
            image_name = replace_extension(image_name, "png")
            image_name_to_input_sample[image_name] = item

        input_sample_indices = self._client.get_input_sample_indices(
            tcp_id, enabled_for_labeling=True
        )

        self._annotate_pipeline(
            folder=folder,
            tcp_id=tcp_id,
            input_sample_indices=input_sample_indices,
            image_name_to_input_sample=image_name_to_input_sample,
            category_name_to_class_id=category_name_to_class_id,
        )

        return tcp_id, labeler_collection_name_to_id

    # private methods

    def _old_export_task(
        self,
        tcp_id,
        sample,
        folder,
        include_samples=True,
        user_id_to_name=dict(),
    ):
        """
        Task to fetch sample from a pipeline
        """
        (
            sample,
            annotations,
            sample_id,
        ) = self._client.get_sample_and_annotations_old(
            tcp_id, sample, include_samples
        )
        return (
            self._shared_task(sample, annotations, folder, user_id_to_name),
            sample_id,
        )

    def _annotate_pipeline(
        self,
        folder: Path,
        tcp_id,
        input_sample_indices,
        image_name_to_input_sample,
        category_name_to_class_id,
    ) -> None:
        with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
            futures = [
                executor.submit(
                    self._task_upload_annotations_for_sample,
                    tcp_id=tcp_id,
                    index=index,
                    folder=folder,
                    image_name_to_input_sample=image_name_to_input_sample,
                    category_name_to_class_id=category_name_to_class_id,
                )
                for index in input_sample_indices
            ]

    def _task_upload_annotations_for_sample(
        self,
        tcp_id,
        index,
        folder,
        image_name_to_input_sample,
        category_name_to_class_id,
    ):
        list_of_users = self._client.get_users()
        input_sample_info = self._client.get_input_sample_info(tcp_id, index)

        image_name = self._get_image_name_from_info(input_sample_info)
        input_sample_json = image_name_to_input_sample[image_name]
        # We need to check if there are actually users defined in the JSON
        # If not, upload as admin user
        if type(input_sample_json["annotations"]) == list:
            annotations_per_user = {}
            annotations_per_user = {"admin": input_sample_json["annotations"]}
        elif type(input_sample_json["annotations"]) == dict:
            annotations_per_user = input_sample_json["annotations"]

        for account, annotations in annotations_per_user.items():
            annotations: List[Type] = [
                self._convert_annotation_temp(
                    rvai_annotation, folder, category_name_to_class_id
                )
                for rvai_annotation in annotations
            ]
            user_id = [
                user["id"]
                for user in list_of_users
                if user["account"] == account
            ][0]
            self._annotate_for_user(tcp_id, index, annotations, user_id)

    def _get_image_name_from_info(self, input_sample_info):
        try:
            image_path = input_sample_info["labelerData"]["$attributes"][
                "entries"
            ]["server_filename"]["value"]["value"]
            logger.debug(
                'Using ["labelerData"]["$attributes"].  Is this not deprecated?'
            )
        except:
            # Get the image path
            labeler_data = input_sample_info["labelerData"]
            resource_key = labeler_data["data"]["$ref"].split("/")
            # small check
            assert resource_key[0] == "#"
            image_path = labeler_data[resource_key[1]][resource_key[2]]

        image_name = replace_extension(
            get_minio_relative_path(image_path), "png"
        )
        return image_name

    def _convert_annotation_temp(
        self, rvai_annotation, folder, category_name_to_class_id
    ):
        class_name = rvai_annotation["$class"]["name"]

        resources = get_resources(rvai_annotation, folder)
        annotation = BaseType.from_artifacts(rvai_annotation, resources)
        cat = Class(
            class_uuid=category_name_to_class_id[class_name], name=class_name,
        )
        annotation.set_class(cat)
        return annotation

    def _annotate_for_user(self, tcp_id, index, annotations, user_id):
        logger.info("%d index sample" % index)
        self._client.upload_annotations(
            tcp_id=tcp_id,
            input_sample_id=index,
            annotations=annotations,
            user_id=user_id,
        )

    def _create_labeler_collection(
        self,
        tcp_id,
        bucket_name,
        labeler_collection_name,
        input_samples,
        im_ext,
    ) -> int:

        subres_list = self._client.get_list_of_s3_subresources()

        bucket = next(
            item for item in subres_list if item["bucket"] == bucket_name
        )
        bucket_id = bucket.get("id")
        subresource_id = int(str(bucket_id))
        logger.info("s3_subresource_id: {}".format(subresource_id))

        # Create a labeler collection
        logger.info(
            "Creating labeler collection of s3_subresource_id: {}".format(
                subresource_id
            )
        )
        labeler_collection_id = self._client.create_labeler_collection(
            name=labeler_collection_name,
            annotation_s3_subresource_id=self._client.get_s3_annotation_subresource()[
                "id"
            ],  # subresource_id,
        )
        self.labeler_collection_ids.append(labeler_collection_id)
        logger.info("labeler_collection_id: {}".format(labeler_collection_id))

        # ... and import all samples from the S3 subresource in it
        logger.info("Ingesting samples...")
        self._client.ingest_input_samples(
            labeler_collection_id=labeler_collection_id,
            s3_subresource_id=subresource_id,
            tcp_id=tcp_id,
            input_samples_list=input_samples,
        )

        logger.info("Ingesting samples done")

        # Add the labeler collection to the trainable cell project
        self._client.add_labeler_collection_to_tcp(
            tcp_id=tcp_id, labeler_collection_ids=[labeler_collection_id]
        )

        return labeler_collection_id

    # TODO A pipeline could have multiple trainable cell projects, thus it
    # should return multiple tcp_ids
    def _create_pipeline(self, pipeline_name: str, pipeline_layout: str):
        # Request the available pipeline layouts from the server
        pipeline_layouts = self._client.get_pipeline_layouts()
        if pipeline_layout not in pipeline_layouts:
            raise ValueError(
                "%s is not a supported pipeline layout" % pipeline_layout
            )
            return

        layout_id = pipeline_layouts[pipeline_layout]

        tcp_info = self._client.get_tcp_info_from_name(pipeline_name)
        if tcp_info == []:
            # Create a training pipeline
            project_name = pipeline_name
            pipeline_id, tcp_id = self._client.create_training_pipeline(
                project_name=project_name, layout_id=layout_id
            )

            logger.info(
                "pipeline_id, tcp_id: {}, {}".format(pipeline_id, tcp_id)
            )
            return tcp_id
        else:
            logger.info("Pipeline already exists")
            if tcp_info is not None:
                tcp0 = tcp_info[0]
                if tcp0 is not None:
                    tcp_id = tcp0.get("generatedTrainableCellProjects")[0].get(
                        "id"
                    )
                    return tcp_id
