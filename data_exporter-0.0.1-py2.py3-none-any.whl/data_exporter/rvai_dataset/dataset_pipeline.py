import json
import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, List

from rvai.types import (
    BaseType,
    BoundingBox,
    Class,
    Image,
    Integer,
    Mask,
    String,
    Type,
)

from .base_client import DatasetClient
from .minio_client import MinioClient

logger = logging.getLogger(__name__)


def flatten_annotations_if_needed(folder: Path, json_path: str) -> str:
    with open(f"{folder}{json_path}") as f:
        data = json.load(f)

    # check if there are dict() annotations
    dict_anns = [v for v in data if type(v["annotations"]) == dict]
    if len(dict_anns) == 0:
        return json_path
    else:
        logger.warning(
            f"Found {len(dict_anns)} items with dict annotations.  \
You probably exported a 6-step pipeline, which includes \
labeler information.  The annotations will be flattened \
since import_label_session does not support this.  Information \
on the labeler will be lost."
        )
        for v in data:
            if type(v["annotations"]) == dict:
                # dict annotations can be an empty dict!
                # if so, we should exclude the annotations key
                # than 2-step pipelines will not label this
                if v["annotations"] == {}:
                    v.pop("annotations")
                    continue

                flat_annotations: List[Any] = []
                for _, anns in v["annotations"].items():
                    for a in anns:
                        flat_annotations.append(a)
                v["annotations"] = flat_annotations

        with open(f"{folder}/flat_data.json", "w") as f:
            json.dump(data, f)
        return "/flat_data.json"


class DatasetPipelineClient(DatasetClient):
    # public methods
    def export_label_session(
        self,
        label_session_name: str,
        folder: Path,
        sample_count: int = None,
        include_samples: bool = True,
        allow_empty_annotations: bool = False,
    ) -> None:
        if not isinstance(folder, Path):
            folder = Path(folder)

        """
        Exports all annotated data from a label session to a folder.
        The folder is formatted in the format expected by new style datasets.

        :param label_session_name: name of the label_session
        :param folder: target folder
        :param sample_count: if not None, specify how many samples to download
        :param include_samples: if False, do not download samples for performance reasons
        :param allow_empty_annotations: if True, include samples that are not annotated
        """
        try:
            os.mkdir(folder)
        except FileExistsError:
            raise Exception(
                f"folder {folder} already exists, please choose a new name"
            )

        user_id_to_name = dict()
        users_list = self._client.get_users()
        for user_item in users_list:
            user_id_to_name[user_item["id"]] = user_item["account"]

        label_session = self._client.get_label_session_info_from_name(
            label_session_name
        )

        try:
            label_session_id = label_session["id"]
        except:
            raise Exception(f"label-session {label_session_name} not found")

        samples = self._client.get_label_session_input_samples(
            label_session_id, annotated=not allow_empty_annotations,
        )
        if samples is not None:
            sample_ids = samples["ids"]
        else:
            raise Exception(f"no sample_ids found for {label_session_name}")

        if sample_count is not None:
            sample_ids = sample_ids[:sample_count]
            logger.info(f"only exporting {sample_count} samples ")

        export_json = []
        with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
            futures = [
                executor.submit(
                    self._export_task,
                    label_session_id,
                    sample,
                    folder,
                    include_samples,
                    user_id_to_name,
                )
                for sample in sample_ids
            ]

            for fut in as_completed(futures):
                export_json.append(fut.result())
        with open(os.path.join(folder, "data.json"), "w") as outfile:
            json.dump(export_json, outfile)
        return None

    def import_label_session(
        self,
        label_session_name: str,
        folder: Path,
        minio_client: MinioClient,
        bucket_name: str,
        dataset_name: str,
        input_sample_type: str = "Image",
        json_path: str = "/data.json",
    ) -> None:
        if not isinstance(folder, Path):
            folder = Path(folder)

        """
        Imports data and annotations from a folder.
        The folder should be formatted in the format expected by new style datasets.

        :param label_session_name: name of the label_session to create
        :param folder: source folder
        :param minio_client: an instance of MinioClient for the boto3 actions
        :param bucket_name: bucket where the data will be stored
        :param dataset_name: name of the dataset to create
        :param input_sample_type: specify input_sample_type if other than Image, eg. MultiViewImage
        :param json_path: override this if your data json is named differently or saved elsewhere
        """
        json_path = flatten_annotations_if_needed(folder, json_path)

        # Let Minio do the work
        minio_client.create_bucket_and_upload(
            bucket_name=bucket_name, folder=folder,
        )
        # Create the subresource
        self._client.create_s3_subresource_for_bucket(bucket_name=bucket_name)

        s3_subresource = self._client.get_s3_subresource(
            resource_name=bucket_name
        )
        if s3_subresource is not None:
            s3_subresource_id = s3_subresource["id"]

        s3_annotation_subresource = self._client.get_s3_annotation_subresource(
            resource_name="annotations"
        )  # default
        if s3_annotation_subresource is not None:
            s3_annotation_subresource_id = s3_annotation_subresource["id"]

        # create the dataset
        dataset_id = self._client.create_dataset(
            s3_annotation_subresource_id=s3_annotation_subresource_id,
            s3_subresource_id=s3_subresource_id,
            dataset_name=dataset_name,
            inputSampleType=input_sample_type,
        )

        # create the label session
        self._client.create_label_session(
            dataset_id=dataset_id,
            s3_subresource_id=s3_subresource_id,
            class_strategy="existingOrNew",  # do not think we have to expose this?
            json_path=json_path,
        )

    def delete_label_session(
        self,
        label_session_name: str,
        bucket_name: str,
        dataset_name: str,
        minio_client: MinioClient,
    ) -> None:
        """
        Deletes a label session and associated data.
        Mostly provided for unit test cleanup.

        :param label_session_name: name of the label_session to delete
        :param bucket_name: bucket to remove
        :param dataset_name: name of the dataset to delete:
        :param minio_client: an instance of MinioClient for the boto3 actions
        """
        self._client.delete_dataset(dataset_name)
        self._client.delete_label_session(label_session_name)
        self.delete_storage_folder(bucket_name)
        minio_client.delete_bucket(bucket_name)

    # private methods
    def _export_task(
        self,
        label_session_id,
        sample,
        folder,
        include_samples=True,
        user_id_to_name=dict(),
    ):
        """
        Task to fetch sample from a label_session
        """
        sample, annotations = self._client.get_sample_and_annotations(
            label_session_id, sample, include_samples
        )
        return self._shared_task(sample, annotations, folder, user_id_to_name)
