import json
import os
from pathlib import Path
from typing import List

from rvai.types import Image, String


class UnsupDataset:
    @classmethod
    def _sample_to_rvai(cls, img_path, target_folder):
        rvai_img = Image.from_file(img_path)
        rvai_img.set_attributes(original_filename=String(img_path),)

        input_sample = rvai_obj_to_json(rvai_img, target_folder)
        return input_sample

    @classmethod
    def to_rvai(cls, files: List[String], target_folder: Path):
        """
        Converts a folder dataset to an RVAI dataset folder

        :param base_folder: base folder with classifcation data
        :param target_folder: target folder
        """
        if not isinstance(target_folder, Path):
            target_folder = Path(target_folder)

        if not os.path.exists(target_folder):
            os.makedirs(target_folder)
        else:
            raise Exception("target folder already exists")

        final_annotations = []
        for img in files:
            input_sample = cls._sample_to_rvai(img, target_folder)
            rvai_annotations: List = []
            final_annotations.append(
                {"inputSample": input_sample, "annotations": rvai_annotations,}
            )

        with open(f"{target_folder}/data.json", "w+") as rvai_file:
            json.dump(final_annotations, rvai_file)

        return final_annotations
