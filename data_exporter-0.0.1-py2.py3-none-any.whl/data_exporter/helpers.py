import os
import shutil
from pathlib import Path
from urllib.parse import unquote, urlparse

from rvai.types.serialization.artifacts import serialize


def _get_resource(resource, base_path):
    with open(f"{base_path}/{resource}", "rb") as f:
        bytes_read = f.read()
    return bytes_read


def get_resources(json, base_path):
    if "resources" not in json:
        return {}
    else:
        return {
            k: _get_resource(v, base_path)
            for (k, v) in json["resources"].items()
        }


def cats_from_json(json):
    categories = []
    for item in json:
        # TODO this is a very bad way of handling this, will definatly cause issues in future
        if type(item["annotations"]) == list:
            # annotations not grouped per user
            annotations = item["annotations"]
        elif type(item["annotations"] == dict):
            # grouped per user
            annotations = []
            for k, v in item["annotations"].items():
                annotations.extend(v)
        else:
            type_issue = type(item["annotations"])
            raise Exception(
                f'Type of item["annotations"] is unexpected: {type_issue}'
            )

        # loop over annotations to get distinct categories
        for annotation in annotations:
            cat = {
                "id": annotation["$class"]["classUuid"],
                "name": annotation["$class"]["name"],
                "shape": annotation["$type"],
            }
            if cat not in categories:
                categories.append(cat)
    return categories


def rvai_json_to_dict(data_json):
    image_name_to_entry = dict()
    for item in data_json:
        resources = item["inputSample"]["resources"]
        image_name = [resources[r] for r in resources][0]
        image_name_to_entry[image_name] = item

    return image_name_to_entry


def rvai_obj_to_json(obj, path, config=None):
    """
    This is like BaseType.save_artifacts(), but the JSON
    gets returned instead of saved to file.  
    The code is copy paste from rvai.types
    """
    if isinstance(path, str):
        path = Path(path)
    path.mkdir(exist_ok=True, parents=True)

    metadata, artifacts = serialize(obj, config=config)

    resources = {}
    for key, artifact in artifacts.items():
        ext = (
            f".{artifact.extension}" if artifact.extension is not None else ""
        )
        file_name = f"{key}{ext}"
        file_path = path / file_name

        with file_path.open("wb") as f:
            f.write(artifact)

        resource_key = metadata["resources"][key][2:-1]
        resources[resource_key] = file_name

    return metadata.render_struct(resources)


def replace_extension(file_name, ext):
    splits = file_name.split(".")
    splits[-1] = ext
    return ".".join(splits)


def get_minio_relative_path(server_image_path: str):
    """
    Gets file path relative to its minio bucket given its server file path.
    """
    image_path = urlparse(unquote(server_image_path)).path
    # first entry in the path name is the bucket name, remove it
    image_path = image_path.split(sep="/", maxsplit=2)[-1]
    return image_path


def recursively_copy(root_src_dir, root_target_dir):
    for src_dir, dirs, files in os.walk(root_src_dir):
        dst_dir = src_dir.replace(root_src_dir, root_target_dir)

        os.makedirs(dst_dir, exist_ok=True)

        for file_ in files:
            src_file = os.path.join(src_dir, file_)
            dst_file = os.path.join(dst_dir, file_)

            if os.path.exists(dst_file):
                os.remove(dst_file)

            shutil.copy(src_file, dst_dir)
