import glob
import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from rvai.types import (
    BaseType,
    BoundingBox,
    Class,
    Image,
    Integer,
    Label,
    Mask,
    String,
)

from data_exporter.helpers import get_resources, rvai_obj_to_json


class FolderDataset:
    @classmethod
    def _sample_to_rvai(cls, img_path, target_folder):
        rvai_img = Image.from_file(img_path)
        rvai_img.set_attributes(original_filename=String(img_path),)

        input_sample = rvai_obj_to_json(rvai_img, target_folder)
        return input_sample

    @classmethod
    def _sample_from_rvai(cls, rvai_img, target_folder):
        input_sample = rvai_obj_to_json(rvai_img, target_folder)
        return input_sample

    @classmethod
    def _labels_from_json(cls, json):
        labels = []
        for item in json:
            for a in item["annotations"]:
                if a["$type"] != "Label":
                    raise Exception(
                        "{} not supported by the FolderDataset".format(
                            a["$type"]
                        )
                    )
                else:
                    label = a["$class"]["name"]

                if label not in labels:
                    labels.append(label)
        return labels

    @classmethod
    def from_rvai(cls, folder: Path, target_folder: Path) -> None:
        """
        Returns a COCO object based on an RVAI Dataset folder

        :param folder: source folder
        :param target_folder: target folder for the coco json

        :return COCO (see https://github.com/cocodataset/cocoapi/blob/master/PythonAPI/pycocotools/coco.py)
        """
        if not isinstance(target_folder, Path):
            target_folder = Path(target_folder)
        if not isinstance(folder, Path):
            folder = Path(folder)

        if not os.path.exists(target_folder):
            os.makedirs(target_folder)
        else:
            raise Exception("target folder already exists")

        with open(f"{folder}/data.json") as f:
            data = json.load(f)
        labels = cls._labels_from_json(data)
        for label in labels:
            os.mkdir(os.path.join(target_folder, label))

        for item in data:
            input_sample = item["inputSample"]
            annotation = item["annotations"][0]  # one element since label
            label = annotation["$class"]["name"]
            resources = get_resources(input_sample, folder)
            rvai_image = BaseType.from_artifacts(input_sample, resources)
            cls._sample_from_rvai(
                rvai_image, os.path.join(target_folder, label)
            )

    @classmethod
    def _task_to_rvai(cls, img, target_folder, label):
        input_sample = cls._sample_to_rvai(img, target_folder)
        rvai_annotations = [label]
        return {
            "inputSample": input_sample,
            "annotations": rvai_annotations,
        }

    @classmethod
    def to_rvai(cls, base_folder: Path, target_folder: Path, num_threads=5):
        """
        Converts a folder dataset to an RVAI dataset folder

        :param base_folder: base folder with classifcation data
        :param target_folder: target folder
        """
        if not isinstance(target_folder, Path):
            target_folder = Path(target_folder)

        if not os.path.exists(target_folder):
            os.makedirs(target_folder)
        else:
            raise Exception("target folder already exists")

        folders = [
            o
            for o in os.listdir(base_folder)
            if os.path.isdir(os.path.join(base_folder, o))
        ]
        final_annotations = []

        for folder in folders:
            label = Label(Class(class_uuid=folder, name=folder))
            label = rvai_obj_to_json(label, target_folder)

            imgs = glob.glob(os.path.join(base_folder, folder) + "/*")
            with ThreadPoolExecutor(max_workers=num_threads) as executor:
                futures = [
                    executor.submit(
                        cls._task_to_rvai,
                        img=img,
                        target_folder=target_folder,
                        label=label,
                    )
                    for img in imgs
                ]

            for fut in as_completed(futures):
                final_annotations.append(fut.result())

        with open(f"{target_folder}/data.json", "w+") as rvai_file:
            json.dump(final_annotations, rvai_file)

        return final_annotations
