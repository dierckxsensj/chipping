from .coco_dataset.coco_dataset import COCODataset  # noqa
from .folder_dataset.folder_dataset import FolderDataset  # noqa
from .rvai_dataset.dataset_pipeline import DatasetPipelineClient  # noqa
from .rvai_dataset.legacy_pipeline import LegacyPipelineClient  # noqa
from .rvai_dataset.minio_client import MinioClient  # noqa
from .unsup_dataset.unsup_dataset import UnsupDataset  # noqa


class DatasetClient(DatasetPipelineClient, LegacyPipelineClient):
    pass
